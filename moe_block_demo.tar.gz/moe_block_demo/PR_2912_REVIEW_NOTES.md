# PR #2912 Review Triage

Comments collected from
https://github.com/NVIDIA/TransformerEngine/pull/2912 (snapshot
2026-05-06). Two reviewers so far:

- `greptile-apps[bot]` — 1 substantive (P1) comment + a generated
  summary diagram.
- `jberchtold-nvidia` — 8 review comments (mix of nits, refactor
  asks, and one correctness question).

Each item below has: **location**, **what they said**, **my read**,
**proposed action**, **priority**.

---

## 1. greptile P1: aux loss `tokens_per_expert` is wrong under DeepSeek-style routing

**Location**: `transformer_engine/jax/flax/moe.py` —
`_compute_aux_loss`, lines ~427-457.

**What they said**: When `num_groups > 0` and `group_topk > 0`, the
`fused_topk_with_score_function(..., compute_aux_scores=True)` call
intentionally **ignores** those parameters and runs a clean
top-k. So the returned `aux_routing_map` reflects different expert
selections than the actual `routing_map` produced by
`_route_topk`, and `aux_tokens_per_expert = sum(aux_routing_map,
axis=0)` is inconsistent with the real routing decisions. Anyone
combining `num_groups>0 + group_topk>0 + aux_loss_coeff>0` silently
trains with a wrong auxiliary objective.

**My read**: **Valid.** Confirmed by reading
`router.py:131-136`:

```python
if compute_aux_scores:
    expert_bias = jnp.empty((0,), dtype=logits.dtype)
    use_pre_softmax = False
    num_groups = -1
    group_topk = -1
    scaling_factor = 1.0
```

The `compute_aux_scores=True` path is meant to give the **scores**
that feed the aux-loss formula (raw post-score-function, no
grouping bias applied to scoring), which is correct. But the
`tokens_per_expert` count should reflect the **actual** routing
that happened in the forward pass — i.e. `_route_topk`'s
`routing_map`.

**Proposed action**:

1. Pass the real `routing_map` from `_route_topk` into
   `_compute_aux_loss`, and use it for `aux_tokens_per_expert`.
   Keep the `compute_aux_scores=True` call for the scores only.
2. Add a test in `tests/jax/test_moe_block.py` that sets
   `num_groups>0, group_topk>0, aux_loss_coeff>0` and verifies the
   aux loss against a hand-rolled reference using the real
   routing_map. This is the regression guard greptile noted is
   missing.

**Priority**: P1 — silent-correctness bug under a well-supported
config.

---

## 2. jberchtold: aux loss + grouped quant + grouped GEMM live outside `shard_map`

**Location**: `transformer_engine/jax/flax/moe.py`, the
no-EP path in `__call__` where `_compute_aux_loss`, `_route_topk`,
`_global_permute`, etc. all execute outside the EP `shard_map`
(when `expert_parallelism_axis is None`).

**What they said**: "Since the grouped quant and grouped GEMM do
not have custom partitioning rules, I think this being outside of
shard_map will either raise an error about missing partitioning
rules or silently replicate."

**My read**: **Worth investigating but probably already handled.**
In the no-EP path the call site is the user's `jax.jit`/SPMD
context — the grouped quant + grouped GEMM are just regular ops
running on logically-replicated data (or whatever the user's
sharding rules dictate). The fact that we have a passing
`test_distributed_moe_block.py` (with FSDP active and no EP) is
weak evidence that it's not "silently replicating" the wgrad in a
way that breaks training. But greptile/jberchtold's worry is
legitimate: the contract is implicit.

**Proposed action**:

1. Add a comment near the no-EP `__call__` branch explicitly
   stating the contract: "When `expert_parallelism_axis is None`,
   we rely on the caller's sharding context. The grouped GEMMs
   inherit FSDP/TP sharding from the kernel's `NamedSharding`."
2. Add a single-process FSDP test (no EP) that asserts the wgrad
   for `wi_0`/`wi_1`/`wo` is correctly partitioned (via HLO
   inspection — assert there's a `reduce-scatter` over fsdp axis
   on the wgrad).
3. If (2) fails, that's a real bug to fix; if it passes, the
   comment makes the contract explicit.

**Priority**: P2 — needs a test to confirm/refute.

---

## 3. jberchtold: `tests/jax/test_distributed_moe_block.py` should `jax.jit` the loss fn

**Location**: `tests/jax/test_distributed_moe_block.py`, around
the `value_and_grad(loss_fn)(sharded_variables, inputs)` call.

**What they said**: "Do we want to `jax.jit` this function before
calling it?"

**My read**: **Valid nit.** Without jit, JAX runs the
value_and_grad eagerly op-by-op, which (a) is slower and (b) can
mask sharding/tracing-only bugs. We should wrap with `jax.jit` to
match how the function would actually be called in production.

**Proposed action**: Wrap as
`jax.jit(jax.value_and_grad(loss_fn, has_aux=True),
in_shardings=...)`. Keep `has_aux=True` for `(loss, (output,
aux_loss))`. Verify both `pure_jax` and `triton` test variants
still pass.

**Priority**: P2 — easy, makes the test more representative.

---

## 4. jberchtold: rename `test_backward_grad`

**Location**: `tests/jax/test_moe_block.py`, the
`test_backward_grad` method.

**What they said**: nit SR — rename to
`test_backward_grad_is_finite_and_nonzero` (or similar) to
indicate the test does not compare against a reference impl.

**My read**: **Valid nit.** Current name implies a numerical
match.

**Proposed action**: Rename to
`test_backward_grad_is_finite_and_nonzero`.

**Priority**: P3 — pure cosmetic.

---

## 5. jberchtold: `1e-1` tolerance is high for jax/triton equivalence

**Location**: `tests/jax/test_moe_block.py`, the test that compares
`pure_jax` vs `triton` permutation backends with `atol=1e-1,
rtol=1e-1`.

**What they said**: 1e-1 is high; what error do we typically see;
is the gap expected between backends?

**My read**: **Valid question.** 1e-1 is too loose. The backends
should be doing the same math up to bf16 accumulation order. If
we're seeing 1e-1 it means there's a real numerical difference
(maybe a different reduction order in the Triton kernel, maybe a
difference in how routing_map/probs are masked).

**Proposed action**:

1. First, locally measure the actual atol/rtol gap (print
   `jnp.max(jnp.abs(g_pj - g_tr))` and the corresponding rtol).
2. Tighten to whatever multiple-of-eps that test reliably hits
   (e.g. `atol=5e-3, rtol=5e-3`). bf16 grads at this scale should
   match within a few units of bf16 eps.
3. If 1e-1 is genuinely needed, document why in a comment (with
   the measured value) so the reviewer's concern is recorded.

**Priority**: P2 — possible silent bug, definitely needs
investigation.

---

## 6. jberchtold: V2 grouped GEMM supports `sum(group_sizes) < M`

**Location**: `tests/jax/test_moe_block.py`, the `xfail` block on
the `align_size>0` tests.

**What they said**: The `m == sum_group_sizes` assertion is V1
grouped GEMM only. V2 supports `sum < m`. Try:

1. `NVTE_JAX_ENFORCE_V2_GROUPED_GEMM=1`.
2. Remove `functools.cache` on
   `_should_enforce_v2_grouped_gemm`.
3. Wrap the test in try/except — if V2 isn't supported on the
   hardware, `pytest.skip("V2 grouped gemm is not supported")`.

**My read**: **Valid and actionable.** This is exactly what we
want: enable `align_size>0` for hardware that supports V2 grouped
GEMM, skip on hardware that doesn't. Removes the xfail entirely
on supported hardware.

**Proposed action**:

1. Remove `@functools.cache` from `_should_enforce_v2_grouped_gemm`
   (test-only side effect — verify nothing else assumes it
   stays cached for performance).
2. Replace the `@pytest.mark.xfail` with a `try`/`except
   RuntimeError` that:
   - sets `NVTE_JAX_ENFORCE_V2_GROUPED_GEMM=1` via
     `monkeypatch.setenv`,
   - runs the body,
   - if the body raises with "V2 grouped gemm is not supported"
     (exact string from `gemm.cpp`), does
     `pytest.skip(...)`.
3. Re-run on our 4-GPU box to confirm V2 path passes.

**Priority**: P2 — removes a known-good xfail and broadens
coverage.

---

## 7. jberchtold: rename "unfused" → "pure_jax"

**Location**: `transformer_engine/jax/permutation.py`, the module
docstring and the `unfused_token_dispatch` / `unfused_token_combine`
function names.

**What they said**: "unfused" implies slower, but in practice (at
least in MaxText) this approach is faster than the Triton fused
kernel. Suggest renaming to "pure_jax" / "triton" matching the
test parametrization.

**My read**: **Valid.** Naming convention should track the
backend (pure_jax vs triton), not the implementation strategy
(fused vs unfused). The MaxText evidence that pure_jax is faster
makes "unfused" actively misleading.

**Proposed action**: Rename:

- `unfused_token_dispatch` → `pure_jax_token_dispatch` (or
  `jax_token_dispatch`)
- `unfused_token_combine` → `pure_jax_token_combine`
- `UnfusedPermState` → `PureJaxPermState`
- Module docstring updated to say "pure-JAX backend (typically
  faster than the Triton fused backend in current testing)"

Keep the old names as deprecated aliases for one release to avoid
breaking direct callers.

**Priority**: P2 — public API rename; do early before the API
cements.

---

## 8. jberchtold: drop the `_make_params` dict, use `nn.compact` inline

**Location**: `transformer_engine/jax/flax/moe.py:279-336`.

**What they said**: "Do we need this 'params' dictionary? With
`nn.compact` we can define each param right before its usage
inline and nn.compact will handle collecting all params. Most of
our other modules in module.py define params inline."

**My read**: **Valid.** The current pattern centralizes
`self.param` calls but then plumbs the dict through `_route_topk`,
`_global_permute`, `_expert_ffn`, `_global_combine`. With
`@nn.compact` (which `MoEBlock` already uses), each
`self.param(...)` call returns the value at the call site, so
inlining is mechanical.

**Proposed action**: Inline:

- `gate_kernel` defined inside `_gate`.
- `wi_0`, `wi_1`, `wi_*_bias` defined inside `_expert_ffn`
  before the corresponding GEMMs.
- `wo`, `wo_bias` defined inside `_expert_ffn` before the wo GEMM.
- `expert_bias` defined inside the path that consumes it.

Drop the `params` dict and update all call sites to take only the
args they actually need.

**Constraint**: under `_forward_a2a_ep`, params have to be passed
through the `shard_map` boundary explicitly (via `in_specs`). So
the EP path may still need to gather kernels into a small pytree
that gets passed into the `shard_map` body. Keep that minimal —
just the EP-resharded params, not the whole dict.

**Priority**: P2 — moderate refactor but improves code
locality and matches house style.

---

## 9. jberchtold: should the gate proj GEMM be quantized?

**Location**: `transformer_engine/jax/flax/moe.py`, `_gate`.

**What they said**: "Is this gating proj GEMM something we should
quantize?"

**My read**: **Question, not a defect.** In Maxtext / DeepSeek
the gating GEMM stays in higher precision (bf16 / f32) because
it's tiny (`H × E`, where `E` is small) and feeds a softmax that
is sensitive to numerical noise. Quantizing it would save ~0.01%
of total compute and add a quantize/dequantize round-trip, with
risk of degrading routing decisions. So: **no by default**, but
worth noting in the docstring.

**Proposed action**: Add a brief note in `_gate`'s docstring:
"The gating projection is intentionally kept in `self.dtype`
(typically bf16) and not autocast to FP8. The GEMM is tiny
relative to the expert FFNs and the top-k softmax is sensitive to
quantization noise. To override, wrap the call site in your own
`autocast` with the desired recipe." Reply on the PR with this
rationale.

**Priority**: P3 — documentation only.

---

## 10. jberchtold: replace `_global_permute`'s dict return with a dataclass

**Location**: `transformer_engine/jax/flax/moe.py`,
`_global_permute(...) -> dict`.

**What they said**: "Can you replace the dict with a dataclass with
the same fields."

**My read**: **Valid.** Typed dataclass is better than a free-form
dict for an internal API (catches typos, gives IDE completion,
makes the contract self-documenting).

**Proposed action**: Define a `@flax.struct.dataclass` (so it's a
pytree leaf compatible with `shard_map` / `jit`) with the current
dict's fields. Probably:

```python
@flax.struct.dataclass
class GlobalPermuteResult:
    sorted_inputs: jnp.ndarray
    sorted_probs: jnp.ndarray
    routing_map: jnp.ndarray
    group_sizes: jnp.ndarray
    sort_map: jnp.ndarray
    # ...whatever else _global_permute returns today
```

Update `_expert_ffn`, `_global_combine`, and the `_a2a_fn` body
inside `_forward_a2a_ep` to take this dataclass instead of a
dict. Inside `_forward_a2a_ep`, the dataclass needs to be
unpacked before `shard_map` (since `in_specs` is a pytree of
PartitionSpecs, not field-keyed).

**Priority**: P2 — clean refactor.

---

## 11. jberchtold: hoist `_a2a_fn` out of `_forward_a2a_ep`

**Location**: `transformer_engine/jax/flax/moe.py`, the `_a2a_fn`
nested function inside `_forward_a2a_ep`.

**What they said**: "This is a fairly large function inside another
big function. Can we move this to an outer scope or is this
required to capture something?"

**My read**: **Mostly valid.** `_a2a_fn` captures `self`, the
`mesh`, `ep_axis`, the per-shard sizes, and the `kernel_fsdp_info`
plumbing. None of those strictly require closure — they could be
passed explicitly as arguments. The function is large (~80 lines)
and benefits from being its own method.

**Proposed action**: Hoist `_a2a_fn` to a module-level function (or
a `@staticmethod` / `@classmethod` on `MoEBlock`) that takes the
captured state as arguments. The `shard_map(_a2a_fn, ...)` call
in `_forward_a2a_ep` then becomes `shard_map(partial(_a2a_fn,
self=self, mesh=mesh, ...), ...)`.

Caveat: `shard_map` argument-position conventions matter — the
manually-sharded args have to be the positional in_args, and the
captured config goes in `partial`.

**Priority**: P2 — readability, not correctness.

---

## Suggested ordering for the next push

1. **#1 (P1, correctness)** — fix aux-loss `tokens_per_expert` +
   add the `num_groups+group_topk+aux_loss_coeff` test.
2. **#7 (rename "unfused")** — touches public API, do before more
   call sites cement.
3. **#5 (tighten the 1e-1 tolerance)** — could be hiding a bug;
   measure first, then tighten.
4. **#3, #4, #9** — quick nits/doc replies.
5. **#10 (dataclass), #8 (drop _make_params), #11 (hoist
   _a2a_fn)** — bigger refactors; bundle in one commit each.
6. **#6 (V2 grouped GEMM)** — needs hardware verification on our
   4-GPU box.
7. **#2 (no-EP no-shard_map contract)** — needs a test to
   confirm; lowest priority since current behavior may already be
   correct.

These can land as a stack of small commits on the PR branch. Each
greptile/jberchtold thread should get a "Resolved in <commit>" or
"Replied" comment so the review gets cleared.
