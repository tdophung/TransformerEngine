#!/usr/bin/env bash
# Run the realistic MoEBlock demo multiple times for both FSDP axes
# (or in a user-chosen interleaving order) so we can quantify run-to-run
# kernel-time variance and check for ordering effects.
#
# Each run produces its own output dir
#   moe_block_demo/output/<RUN_NAME>/fsdp_<axis>/...
# so the traces accumulate instead of overwriting one another.
#
# Usage:
#
#   bash moe_block_demo/run_variance.sh                 # 3 runs/axis, embed-then-mlp
#   N=5 bash moe_block_demo/run_variance.sh             # 5 runs per axis
#   ORDER=interleave bash moe_block_demo/run_variance.sh
#       # runs e1, m1, e2, m2, ... to expose any ordering effect
#   ORDER=mlp_first bash moe_block_demo/run_variance.sh # m1..mN, e1..eN
#   PRESET=dsv3_var bash moe_block_demo/run_variance.sh # custom run-name prefix
#
# After:
#
#   python3 moe_block_demo/compare_variance.py --prefix dsv3_var
#
# which loads every trace under output/dsv3_var_<axis>_<i>/ and prints
# per-kernel mean +/- stddev across the N runs, plus a between-axis
# diff sized against the within-axis variance.

set -euo pipefail

N="${N:-3}"
ORDER="${ORDER:-embed_first}"
PRESET="${PRESET:-dsv3_var}"

DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------------
# Inherit the realistic preset's dims unless the caller already set them.
# Mirrors run_realistic.sh defaults so a single command produces directly
# comparable variance numbers.
# ---------------------------------------------------------------------
export DEMO_BATCH_SIZE="${DEMO_BATCH_SIZE:-8}"
export DEMO_SEQUENCE_LENGTH="${DEMO_SEQUENCE_LENGTH:-4096}"
export DEMO_HIDDEN_SIZE="${DEMO_HIDDEN_SIZE:-2048}"
export DEMO_INTERMEDIATE_SIZE="${DEMO_INTERMEDIATE_SIZE:-2048}"
export DEMO_NUM_EXPERTS="${DEMO_NUM_EXPERTS:-64}"
export DEMO_NUM_EXPERTS_PER_TOK="${DEMO_NUM_EXPERTS_PER_TOK:-8}"
export DEMO_EP_SIZE="${DEMO_EP_SIZE:-2}"
export DEMO_FSDP_SIZE="${DEMO_FSDP_SIZE:-2}"
export DEMO_NUM_PROFILE_ITERS="${DEMO_NUM_PROFILE_ITERS:-5}"

echo "================================================================="
echo "Variance sweep"
echo "  preset=${PRESET}, N=${N}, order=${ORDER}"
echo "  dims: B=${DEMO_BATCH_SIZE} S=${DEMO_SEQUENCE_LENGTH}"
echo "        H=${DEMO_HIDDEN_SIZE} I=${DEMO_INTERMEDIATE_SIZE}"
echo "        E=${DEMO_NUM_EXPERTS} K=${DEMO_NUM_EXPERTS_PER_TOK}"
echo "        ep=${DEMO_EP_SIZE} fsdp=${DEMO_FSDP_SIZE}"
echo "        profile_iters=${DEMO_NUM_PROFILE_ITERS}"
echo "================================================================="

run_one() {
    local axis="$1" idx="$2"
    local run_name="${PRESET}_${axis}_${idx}"
    echo
    echo "----- run ${run_name} -----"
    DEMO_RUN_NAME="$run_name" \
    FSDP_LOGICAL_AXIS="$axis" \
        bash "$DEMO_DIR/run.sh"
}

case "$ORDER" in
    embed_first)
        for i in $(seq 1 "$N"); do run_one embed "$i"; done
        for i in $(seq 1 "$N"); do run_one mlp   "$i"; done
        ;;
    mlp_first)
        for i in $(seq 1 "$N"); do run_one mlp   "$i"; done
        for i in $(seq 1 "$N"); do run_one embed "$i"; done
        ;;
    interleave)
        for i in $(seq 1 "$N"); do
            run_one embed "$i"
            run_one mlp   "$i"
        done
        ;;
    *)
        echo "Unknown ORDER=$ORDER (expected embed_first|mlp_first|interleave)" >&2
        exit 2
        ;;
esac

echo
echo "================================================================="
echo "Variance sweep complete. Aggregate with:"
echo "  python3 ${DEMO_DIR}/compare_variance.py --prefix ${PRESET}"
echo "================================================================="
