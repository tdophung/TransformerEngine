# Experiment 1 — Quantize Before FSDP All-Gather

Living plan and current state for Exp 1. Resume here if the work is
paused.

---

## Goal

Today, `MoEBlock`'s 3 `grouped_dense` calls receive a per-shard
fsdp-sliced kernel at the `shard_map` boundary, where JAX inserts an
implicit AG of the **bf16** weight before `tex.grouped_quantize`
sees the full kernel. Each fsdp peer redundantly quantizes the
**full** gathered tensor.

Goal: each peer quantizes only its **1/num_fsdp** slice locally with a
consistent (FSDP-reduced) amax, then explicit AG of the **FP8**
(or generic ScaledTensor) data + scales.

**Wins**:

- Fwd AG bandwidth halves (FP8 vs bf16) on the 3 weight kernels.
- Quantize compute drops by `1/num_fsdp` per peer (2x at fsdp=2,
  4x at fsdp=4, 8x at fsdp=8).

---

## Knob design (already agreed)

- `MoEBlock.quantize_before_fsdp_ag: bool = False` (new field).
- Repurpose `dense.grouped_dense`'s existing
  `kernel_fsdp_info: Tuple[str, int] = (None, -1)` parameter (was a
  legacy no-op from the grouped_gemm v1 era; non-default values
  currently asserted off). MoEBlock derives the value from
  `wi_kernel_axes`/`wo_kernel_axes` + the active `nn.logical_axis_rules`
  table at trace time.
- **TODO**: clarify with TE team whether `kernel_fsdp_info` is the
  long-term wire format or whether to migrate to a different API.
  Concern: direct `grouped_dense` users (not via MoEBlock) get a
  clunky API where they pass `kernel_fsdp_info` while the same info
  may already be conveyed via the kernel's NamedSharding. For Exp 1
  we land with the existing knob; the API question can be revisited
  in a follow-up.

## scale_inv handling (CORRECTED v2 — symmetric, no per-axis branch)

**Earlier note about per-row block scaling was wrong.** Tensor-scaling
`tex.grouped_quantize(kernel, flatten_axis=-1)` does NOT compute one
scale per row -- it computes one scale per **expert / group**, by
maxing over every dim except dim 0:

```python
row_amax    = jnp.max(jnp.abs(x), axis=range(1, x.ndim))   # (E_local,)
grouped_amax = jax.ops.segment_max(row_amax, segment_ids,
                                   num_segments=n_groups)  # (n_groups,)
```

For per-shard kernel `(E_local, H, I)` (or `(E_local, H/fsdp, I)`
under `embed`-FSDP, or `(E_local, H, I/fsdp)` under `mlp`-FSDP),
`row_amax` is `max over (H, I)` (or whichever sliced subset of
`(H, I)` lives on this peer) per expert. Each peer's local
`grouped_amax[e]` only sees `1/fsdp` of expert `e`'s elements.

**Therefore amax-AR (`pmax` across FSDP) is unconditionally needed
for tensor-scaling -- regardless of which kernel dim FSDP slices.**

| Convention | Per-shard kernel | What `grouped_amax[e]` sees | amax AR needed? | scale_inv shape | scale_inv AG needed? |
|---|---|---|---|---|---|
| `embed` (FSDP shards H, dim 1) | `(E_local, H/fsdp, I)` | local `(H/fsdp, I)` slice per expert | **Yes** -- pmax over fsdp | `(E_local,)` (per-expert) | **No** -- pmax already made it identical across peers |
| `mlp` (FSDP shards I, dim 2) | `(E_local, H, I/fsdp)` | local `(H, I/fsdp)` slice per expert | **Yes** -- pmax over fsdp | `(E_local,)` (per-expert) | **No** -- same reason |

The only collective Stage 3 needs (besides what Stage 2 already added
inside `grouped_quantize`) is `jax.lax.all_gather` of the FP8 `data`
along FSDP. `scale_inv` is identical across peers post-pmax, so
`grouped_dense` can just keep the local copy.

For **block scaling** (MXFP8): per-block amax is local-correct
because each block lives entirely on one peer (provided per-shard
size on the FSDP axis is a multiple of the block size). Both K-side
and M-side FSDP placements are supported under the SAME per-shard
mult-of-128 guard:

| Layout | block_x | alignment_x | block_y | alignment_y | block_x*alignment_x | block_y*alignment_y |
|---|---|---|---|---|---|---|
| Rowwise (default) | 1 | 128 | 32 | 4 | 128 | 128 |
| Colwise (transpose) | 32 | 4 | 1 | 128 | 128 | 128 |

Both products equal 128, so a single ``per-shard size on the FSDP
axis is a multiple of 128`` guard covers all four (M-side / K-side)
× (rowwise / colwise) combinations. Under that guard:

* No MXFP8 block straddles peer boundaries (per-shard size is mult
  of ``block_x`` on M-side or ``block_y`` on K-side), so per-block
  amax is local-correct.
* Per-shard ``n_block_x`` and ``n_block_y`` carry no alignment
  padding (per-shard size is also mult of ``alignment_x`` or
  ``alignment_y``), so the per-shard scale layout is exact and
  scale_inv concatenates cleanly under AG.

Implementation:

1. Per-shard quantize via the same ``grouped_quantize`` call (no
   pmax needed for amax; per-block amax is already local-correct).
2. AG the FP8 ``data`` along the FSDP axis via
   ``_all_gather_grouped_scaled_tensor_1x``.
3. AG the per-block ``scale_inv``:
   * **K-side**: reshape to ``(padded_n_block_x, n_block_y_per_shard)``,
     AG axis 1, reflatten.
   * **M-side**: reshape to ``(G, M_per_shard/block_x, n_block_y)``,
     AG axis 1 (the per-group M sub-axis), reflatten. Restricted to
     the single-non-G-M-dim layout ``(G, M, K_dims...)`` (the
     MoEBlock kernel layout); multi-M-dim layouts need a non-trivial
     reshape and currently raise ``NotImplementedError``.

MoEBlock enforces the per-shard mult-of-128 constraint up front
(``_assert_kernel_fsdp_alignment``) so misconfigurations surface
before the FFI dispatch, regardless of which scaling recipe is
active at runtime.

---

## Stages

| Stage | What | Files | Verification | Status |
|---|---|---|---|---|
| **0** | FP8 baseline knob in demo (`DEMO_USE_FP8`, `Float8CurrentScaling`); separate output dir `_fp8_cs/` | `moe_block_demo/run_demo.py`, `run.sh`, `run_realistic.sh`, `build_diagram.py`, `README.md` | bf16 unchanged ✓; FP8 compile dumps HLO ✓; FP8 fwd+grad runs cleanly end-to-end after fixing two TE C++ bugs (`multi_stream.cpp` device-bound CUDA resources + `GroupedQuantizeFFI`/`gemm.cpp` strict `m == sum(group_sizes)` assertion); both single-device and 4-GPU distributed `MoEBlock` tests pass under FP8. See "Stage 0a" below. | **DONE** |
| **0a** | Make FP8 + MoEBlock baseline run end-to-end | `moe_block_demo/*`, `multi_stream.cpp`, `quantization.cpp`, `gemm.cpp` | FP8 fwd+grad completes; HLO dumped; all `tests/jax/test_moe_block.py` + `tests/jax/test_distributed_moe_block.py` cases pass | **DONE** |
| **1** | MoEBlock plumbing: `quantize_before_fsdp_ag` knob, derive `kernel_fsdp_info` from rules+kernel_axes, change `in_specs` for `wi_*`/`wo` to keep fsdp sharded inside shard_map, pass `kernel_fsdp_info` through to the 3 grouped_dense calls | `transformer_engine/jax/flax/moe.py` | bf16 hits the assert in `_grouped_dense_fwd_rule` (expected; Stage 3 lifts it) | **DONE** -- knob=False unchanged (legacy in_specs + `kernel_fsdp_info=(None,-1)`); knob=True derives `(physical_axis, dim_idx)` per kernel from `flax.linen.get_logical_axis_rules() ∩ data_parallelism_axes` and threads through `__call__ → _forward_{no_ep, a2a_ep} → _expert_ffn → grouped_dense`; helpers `_derive_kernel_fsdp_info` + `_build_kernel_in_spec` are unit-traceable on CPU. Verification pending (run distributed tests + DEMO_QUANTIZE_BEFORE_FSDP_AG=1 once demo knob lands in Stage 6). |
| **2** | Add `amax_scope: AmaxScope = LOCAL` param to `grouped_quantize`. When `FSDP`, do `jax.lax.pmax(amax, fsdp_axis)` so all peers compute the same scale. Land as **separate commit** (useful even outside Exp 1). | `transformer_engine/jax/cpp_extensions/quantization.py` | Single-device tests unchanged; multi-device under FSDP shows consistent scales across peers | **DONE** -- default `LOCAL` preserves legacy. `FSDP` path branches on scaling mode: (a) `CURRENT_TENSOR_SCALING` pmaxes `grouped_amax` along `global_mesh_resource().fsdp_resource` *before* `compute_scale_from_amax`, so all peers derive identical scales; (b) `DELAYED_TENSOR_SCALING` pmaxes the FFI-returned `updated_amax` *before* `quantizer_i.update(...)`, so next step's stored scale is consistent (this step still uses whatever was previously stored — convergence after one step); (c) **MXFP8 + `FSDP` is a no-op** (not an error): per-block amax is already peer-correct because each MXFP8 block fits within a single FSDP slice (block boundaries must be FSDP-aligned), so AG of per-shard FP8 data + per-block scale_inv just concatenates correct values — no cross-peer reduction is needed. Caller can pass `amax_scope=FSDP` uniformly regardless of mode. When the active mesh has no `fsdp_resource`, the call silently degrades to `LOCAL` — matches `calculate_amax`'s partition-rule behavior. Verification pending Stage 5 (FSDP distributed test). |
| **3** | In `_grouped_dense_fwd_rule`: remove the `kernel_fsdp_info == (None,-1)` assert; allow bf16, tensor scaling, and MXFP8. **bf16 path**: when the active recipe has no kernel quantizer, just `jax.lax.all_gather` the bf16 kernel up front so the rest of the rule follows the legacy path (semantically identical to AG-outside-shard_map). **FP8 / MXFP8 path**: (a) call `tex.grouped_quantize(..., amax_scope=AmaxScope.FSDP)` so per-shard tensor-scaling amax is FSDP-pmax'd (per-block MXFP8 amax is already local-correct under the alignment guard); (b) `_all_gather_grouped_scaled_tensor_1x` on the RHS scaled tensor (rowwise for tensor scaling, colwise for MXFP8 since `casted_kernel.get_tensor(usage=RHS)` returns colwise under MXFP8): AG `data` for all modes; for tensor scaling reuse per-shard `scale_inv`; for MXFP8 AG `scale_inv` via the K-side path (`reshape (padded_n_block_x, n_block_y_per_shard) → AG axis=1`) or M-side path (`reshape (G, M_per_shard/block_x, n_block_y) → AG axis=1`) under the same per-shard mult-of-128 guard. (c) Pass the gathered tensor to `tex.grouped_gemm`. `ctx_kernel` is saved per-shard for Stage 4. MoEBlock adds an upfront `_assert_kernel_fsdp_alignment` check (per-shard size mult of 128 on FSDP axis) so misconfigs surface before the FFI dispatch. | `transformer_engine/jax/dense.py`, `transformer_engine/jax/flax/moe.py` | Verified end-to-end via Stage 4's full fwd+bwd test (no separate Stage 3 fwd-only test was retained — the Stage 4 path subsumes it). | **DONE** (M-side MXFP8 covered for the single-non-G-M-dim MoEBlock layout; multi-M-dim deferred). |
| **4** | In `_grouped_dense_bwd_rule`: lift the `kernel_fsdp_info == (None,-1)` assert. AG the per-shard ctx_kernel (RHS_TRANS) inside the bwd body via the same `_all_gather_grouped_scaled_tensor_1x` helper so the dgrad GEMM sees the full kernel and produces a full-K dgrad (matching x's full-K spec). After the wgrad GEMM (which produces a full kernel-shape `(G, K, N)` because it used `ctx_x` at full K), `lax.psum_scatter` along `kernel_fsdp_axis_idx` with `tiled=True`: this is the autodiff transpose of the fwd `all_gather` — it sums per-FSDP-peer partial wgrads (different peers contribute different ctx_x batch slices) and scatters the K dim back to per-shard, so the bwd output matches the per-shard kernel input. Tensor scaling and MXFP8 K-side are both supported via the helper's `is_colwise` branch; M-side MXFP8 inherits the same `NotImplementedError` from Stage 3. | `transformer_engine/jax/dense.py`, `transformer_engine/jax/flax/moe.py` (docstring only) | `tests/jax/test_distributed_moe_block.py::TestDistributedMoEBlock::test_quantize_before_fsdp_ag_matches_single_device` (parametrized over `bf16` + `Float8CurrentScaling`; uses H=I=256 to clear the per-shard mult-of-128 check; full `value_and_grad` with grad-match against single-device reference). MXFP8 K-side full coverage: `DEMO_QUANTIZE_BEFORE_FSDP_AG=1 DEMO_QUANT_RECIPE=mxfp8 bash moe_block_demo/run_realistic.sh` with default `embed -> fsdp` (this puts FSDP on K-side of `wi` axis 1; K-side check passes at H=2048/2=1024). HLO collective summary should show extra `f8e4m3fn` (data) + `f8e8m0fnu` (per-block scale_inv) all-gathers + a `psum-scatter` per kernel. | **DONE** |
| **5** | FP8 distributed test in `test_distributed_moe_block.py` (folded into Stage 4's `test_quantize_before_fsdp_ag_matches_single_device`): (a) bf16 knob=True ≈ single-device numerically, (b) FP8 (`Float8CurrentScaling`) knob=True ≈ single-device numerically. MXFP8 verification stays in the demo because toy distributed shapes don't satisfy MXFP8's strict end-to-end buffer alignment. | `tests/jax/test_distributed_moe_block.py` | Test passes on 4-GPU box. | **DONE** (folded into Stage 4 test) |
| **6** | `DEMO_QUANTIZE_BEFORE_FSDP_AG` env knob in `run_demo.py`; extend `compare_hlo.py` with a third lane (knob=True vs knob=False); update `WIP_analysis.md` Exp 1 section | `moe_block_demo/*` + `WIP_analysis.md` | knob=True FP8 HLO has FP8 AG operands; xprof shows quantize kernel time drops by ~num_fsdp factor | TODO |

---

## Stage 0a: FP8 baseline hang — TWO ROOT CAUSES, BOTH FIXED ✓

The FP8 + MoEBlock baseline hit *two* distinct C++ bugs in TE that masked
each other (the second only surfaced after the first was fixed). Both are
documented below in the order they were found.

**Final verification (4-GPU box):**
- `DEMO_USE_FP8=1 bash moe_block_demo/run.sh` runs cleanly end-to-end.
- `tests/jax/test_moe_block.py` — all cases pass.
- `tests/jax/test_distributed_moe_block.py` — all cases pass.

### Layout invariant that justifies Bug #2's relaxation

The `<=` relaxation in `quantization.cpp` and `gemm.cpp` is safe because
the buffer that feeds `GroupedQuantizeFFI` always satisfies:

- Rows `[0, sum_group_sizes)` = valid tokens packed contiguously in
  expert-major order (group 0 | group 1 | ... | group N-1).
- Rows `[sum_group_sizes, m)` = unused / garbage tail.

This invariant is enforced by:

1. **EP path** (both `pure_jax` and `triton` permutation backends share
   this — see Stage 0a "Permutation backends" note below):
   `local_permute_after_a2a` calls Triton's `_make_chunk_sort_map_kernel`,
   which explicitly identity-fills the trailing slack rows of the worst-
   case-sized A2A recv buffer:

   ```cpp
   total_valid_tokens = tl.sum(input_split_sizes)
   ...
   // For tokens beyond the valid range (pid >= total_valid_tokens),
   // use identity mapping to avoid corrupting valid data
   dst_row = tl.where(pid < total_valid_tokens, dst_row, pid)
   ```

2. **Non-EP path with `align_size > 0`**:
   - Triton (`permute_with_mask_map_and_pad`): `group_sizes[i] =
     ceil(actual_i / align) * align`. Intra-group zero rows are *inside*
     each group's slice and counted in `group_sizes[i]`, so
     `sum_group_sizes == buffer_size` exactly.
   - Pure-JAX (`pure_jax_token_dispatch` align branch): overflow placeholder
     tokens are assigned `selected_experts = num_experts - 1` and sort to
     the very end of the buffer, *after* expert E-1's real+pad region.
     `group_sizes[i]` only counts real+pad, so
     `sum_group_sizes < buffer_size` with garbage tail at end.

In all cases the per-group quantize/GEMM loop walks `dim_list_host[i]`
rows per group, advancing input/output pointers linearly, and only
touches the first `sum_group_sizes` rows. The strict `==` assertion was
the only thing blocking the worst-case-sized buffer; the kernel logic
was already correct.

### Permutation backends and the post-A2A local permute (note)

`MoEBlock`'s `permutation_backend` knob switches only the *global*
routing dispatch (`pure_jax_token_dispatch` ↔ Triton `token_dispatch`).
The post-A2A reorder (`local_permute_after_a2a`) is currently
Triton-only — it operates on `num_shards × local_experts` contiguous
chunks (not individual tokens) and has no pure-JAX alternative. This is
documented inline in `permutation.py` lines 1212-1217. Adding a pure-JAX
local permute is a possible future follow-up if the Triton dependency
becomes a maintenance issue.

### Bug #1 (rendezvous-masked): device-bound CUDA resources — FIXED

#### Symptom

`DEMO_USE_FP8=1 bash moe_block_demo/run.sh` hung during
`fwd_and_grad (compile + run)`. Compile succeeded (HLO dumped to
`output/fsdp_mlp_fp8_cs/hlo/`); runtime aborted after a 40s
``FirstCallRendezvous`` timeout on a `kAllGather` collective with
1 of 4 ranks arrived. The bf16 path was fine.

#### Root cause

`transformer_engine/common/util/multi_stream.cpp` lazily allocates
a process-global vector of CUDA streams + events using
``std::call_once``:

```cpp
static std::vector<cudaStream_t> streams(num_streams);
static std::once_flag stream_init_flag;
auto init = [&]() {
  for (size_t i = 0; i < num_streams; i++) {
    NVTE_CHECK_CUDA(cudaStreamCreateWithPriority(
        &streams[i], cudaStreamNonBlocking, -1));
  }
};
std::call_once(stream_init_flag, init);
return streams[idx];
```

CUDA streams and events are *device-bound*: a stream / event
created on device A cannot be recorded into / waited on from
device B (CUDA returns ``cudaErrorInvalidResourceHandle``,
error 400). In single-process *multi*-device JAX, multiple
worker threads call into TE on different devices — whichever
thread wins the ``call_once`` creates the streams/events on its
device; subsequent calls from other devices receive those same
handles and fail at ``cudaEventRecord(stream_event[0], stream)``.

Confirmed by surfacing the actual error via
``DEMO_WARMUP_FWD_ONLY=1`` (which moves the failing
``nvte_multi_tensor_quantize`` call out of the
``FirstCallRendezvous`` window so the underlying CUDA error is
no longer masked by the rendezvous timeout):

```
XLA FFI call failed: .../cast.cu:112 in function
nvte_multi_tensor_quantize: CUDA Error: invalid resource handle
[executable_name='jit_fwd_only']
```

Same infra is also used by ``cublaslt_gemm.cu`` (FP8 grouped
GEMM) — so the FP8 grouped_dense path was broken in
single-process multi-device end-to-end, not just inside MoEBlock.

#### Fix

`transformer_engine/common/util/multi_stream.cpp`: cache streams
and events *per CUDA device*, keyed on ``cudaGetDevice`` — each
device lazily gets its own pool of ``num_compute_streams``
streams and events on first use. The ``std::call_once`` flag is
replaced with a guarded ``std::unordered_map<int, vector<...>>``.
Single-device behavior is unchanged (one entry in the map).

This is shared TE C++ infra (not JAX-specific), so it also
unblocks single-process multi-device PyTorch usage of FP8 grouped
GEMM as a side effect. A C++ rebuild is required to pick up the
fix.

### Bug #2 (post-rebuild): strict ragged-tile assertion incompatible with worst-case recv buffer — FIXED

#### Symptom

After rebuilding TE with the `multi_stream.cpp` fix,
`DEMO_USE_FP8=1 bash moe_block_demo/run.sh` no longer hangs but
fails immediately with:

```
XLA FFI call failed:
  transformer_engine/jax/csrc/extensions/quantization.cpp:386
  in function GroupedQuantizeFFI:
  Assertion failed: m == sum_group_sizes ||
                    input_dims[0] == sum_group_sizes.
  Unexpected group_sizes! Got 118 (M=256, input_dims[0]=256)
[executable_name='jit_fwd_and_grad']
```

#### Root cause

`GroupedQuantizeFFI` (and the analogous check in `gemm.cpp:1161`
for non-ragged-rhs grouped GEMM) hard-asserts that the input row
count exactly equals `sum(group_sizes)`. This is true for the
canonical "permute-then-grouped-FFN" flow (no padding), but
**not** for our ragged-A2A flow where the recv buffer is sized to
the worst case (all tokens going to one shard) and only the first
`sum(group_sizes)` rows are populated; the trailing slack rows are
intentionally unused.

The per-group quantize loop already handles the slack correctly:
it walks `dim_list_host[i]` rows per group and advances
`input_ptr` / `output_ptr` accordingly, so only the first
`sum(group_sizes)` rows are ever read or written. The strict `==`
assertion was the only thing blocking the path.

#### V1 vs V2 codepath note (reviewer feedback)

This assertion lives in the **V1** `te_grouped_quantize_ffi`
codepath (and the corresponding V1 grouped GEMM), not the V2
cuBLASLt-bound path. The V2 path (`te_grouped_quantize_v2_ffi` /
V2 grouped GEMM) already supports `sum(group_sizes) <= k` and has
been tested thoroughly with that pattern.

We hit V1 here because our demo runs `Float8CurrentScaling`
(`CURRENT_TENSOR_SCALING`). V2 quantize is gated to
`MXFP8_1D_SCALING` only (see
`GroupedQuantizePrimitive._use_v2_kernel` line 1037: it returns
`False` for any non-MXFP8 mode). Tensor-scaled FP8 (current and
delayed) therefore always falls through to V1, which is where the
strict assertion was. Our `<=` relaxation has no effect on the V2
path; it only unblocks tensor-scaling FP8 with worst-case-sized
ragged-A2A buffers. The reviewer noted that, while V1 is
untested with this relaxation in production, the per-group loop
logic is the same as V2's, so the change is expected to be safe.

#### Fix

Relaxed both assertions from `==` to `<=`:

- `transformer_engine/jax/csrc/extensions/quantization.cpp:386`:
  ```cpp
  NVTE_CHECK(sum_group_sizes <= input_dims[0], ...);
  ```
- `transformer_engine/jax/csrc/extensions/gemm.cpp:1161,1164`:
  ```cpp
  if (!is_rhs_ragged) {
    NVTE_CHECK(sum_group_sizes <= m, ...);
  } else {
    NVTE_CHECK(sum_group_sizes <= k, ...);
  }
  ```

Behavior is unchanged for the strict-tile case (the canonical
permute-then-FFN flow still satisfies the relaxed check).
Single-device tests should be unaffected.

A second TE C++ rebuild is required to validate.

### TE-side limitations surfaced while wiring recipe parametrization (followup)

Two recipes that we'd otherwise want covered in the MoE test suite are
currently blocked on TE-internal issues; we documented them in the
parametrization comments and added narrower coverage instead:

1. **`DelayedScaling` is unsupported by `GroupedQuantizer`.** The
   factory call ``QuantizerFactory.create(n_groups=8,
   scaling_mode=DelayedScaling, q_dtype=..., q_layout=...,
   margin=0, amax_history=..., amax_compute_algo=MAX)`` forwards
   the DelayedScaling kwargs straight to ``GroupedQuantizer.__init__``
   (``quantizer.py:1116``). ``GroupedQuantizer`` inherits only
   base-``Quantizer`` fields and rejects them with
   ``TypeError: GroupedQuantizer.__init__() got an unexpected
   keyword argument 'margin'``. The non-grouped path
   (``test_distributed_layernorm.py`` etc.) works because layernorm
   uses ``DelayedScaleQuantizer`` directly; only ``GroupedQuantizer``
   has this gap. Two reasonable fixes:
   * (a) Have ``QuantizerFactory.create`` drop DelayedScaling-only
     kwargs when ``n_groups`` is set (and forward them to the
     per-group instances inside ``GroupedQuantizer.__post_init__``).
   * (b) Have ``GroupedQuantizer`` accept and route those kwargs
     itself.
   For now: dropped from MoE test suite + demo; tracked here.

2. **MXFP8 needs end-to-end alignment for the grouped path.**
   MXFP8 + grouped quantize requires the *entire post-permute
   buffer's row count* to be divisible by ``block_x = 32``
   (asserted in
   ``BlockScalingModeMetadataImpl.get_grouped_scale_shape``). Per-
   group alignment via ``align_size = 32`` is *necessary but not
   sufficient*: the pure-JAX dispatch buffer formula is
   ``num_real_tokens + num_experts * (align_size - 1)``, which is
   not 32-aligned for typical toy combinations. E.g. for
   ``(num_real=64, num_experts=8, align_size=32)`` the buffer is
   ``64 + 248 = 312``, and ``312 % 32 = 24`` -- the trailing
   padding region makes the buffer dim non-aligned even when each
   per-group count is. The triton path rounds the buffer down to
   alignment but other intermediate buffers in the pipeline still
   trip on similar gaps. V2 dispatch additionally needs ``H/I %
   128 == 0`` plus 128-aligned group sizes. Engineering toy shapes
   to satisfy every alignment along the critical path is brittle
   (any future buffer-formula change re-breaks it).

   **Decision:** no MXFP8 unit test; MXFP8 covered end-to-end at
   realistic dims by ``DEMO_QUANT_RECIPE=mxfp8 bash
   moe_block_demo/run_realistic.sh`` (H = I = 2048; per-shard
   tokens far exceed 128). The demo is the MXFP8 test.

### What we ruled out before landing the multi_stream fix

- cuBLASLt XLA autotune: ``--xla_gpu_autotune_level=0`` also
  hung (since the issue isn't autotune).
- HLO compile-time divergence per rank.
- The extra `psum` from the P1 aux-loss fix (already removed,
  hang persisted).
- The aux branch entirely (``AUX_LOSS_COEFF=0`` still hung).
- Hypothesis "two consecutive global collectives over the same
  replica group" — the rendezvous is just where the timeout
  *fires*, not where the underlying problem is.

### Verification needed (next session, after C++ rebuild)

1. Rebuild TE: ``cd TransformerEngine && pip install --no-deps
   --no-build-isolation -e .`` (or whatever the local rebuild
   command is for the user's setup).
2. ``DEMO_USE_FP8=1 bash moe_block_demo/run.sh`` completes
   cleanly (with and without ``DEMO_WARMUP_FWD_ONLY=1``).
3. Capture FP8 baseline HLO + timings in
   ``output/fsdp_mlp_fp8_cs/`` and compare against bf16.
4. Re-run ``tests/jax/test_distributed_moe_block.py`` (currently
   bf16; consider adding an FP8 variant).

### Investigation timeline

#### Hypothesis 1 (REJECTED): extra `psum` from greptile-P1 aux-loss fix

The P1 fix had introduced ``jax.lax.psum(local_tokens_per_expert,
axis_name=(ep, dp))`` inside ``_a2a_body``. That lowered to a
4-way ``all-reduce`` over ``{{0,1,2,3}}`` *immediately after*
the existing 4-way ``all-gather`` of logits over the same group.
The earlier bf16 HLO snapshot did not show this psum (it was
dumped before the P1 fix landed) — that asymmetry led me to
suspect "two consecutive global collectives over the same
replica group" was the trigger.

Mitigation landed: replaced the psum with a duplicate
``_route_topk`` on the AG'd ``global_logits_2d`` (P1 correctness
preserved, one collective instead of two). HLO confirms the
``s32[16] all-reduce`` is gone.

**Result**: FP8 still hangs at the same `kAllGather` rendezvous
with the new HLO. So the extra `psum` was not the trigger.

### Open questions / next isolation experiments

The hang is on the FIRST collective rendezvous (a `kAllGather`).
The XLA `FirstCallRendezvous` is *per-process, per-executable*: it
expects all 4 worker threads in the local process to reach the
first collective in the executable. Only 1 of 4 arrives ⇒ the
other 3 worker threads are stuck somewhere upstream in the SAME
executable's thunk sequence.

#### Confirmed via experiments

- bf16 still works after the moe.py change to
  re-route_topk-on-AG'd-logits ⇒ my latest moe.py edit is *not*
  the bug.
- `DEMO_USE_FP8=1 DEMO_AUX_LOSS_COEFF=0` **still hangs** ⇒ the
  aux branch is *not* the trigger. The hang is in the main
  expert FFN path (FP8 quantize / FP8 grouped GEMM FFI), or in
  per-process FP8 first-touch state shared across all 4 worker
  threads.

#### Next experiments (in priority order)

1. **Pre-warm FP8 first-touch state via fwd_only** (added knob
   `DEMO_WARMUP_FWD_ONLY=1`): runs `fwd_only` once before the
   timed `fwd_and_grad`. Any per-process FP8 init (cuBLASLt
   FP8 plugin handle, quantize FFI plugin, Triton kernel JIT)
   is paid in `fwd_only`. If `fwd_only` itself hangs at the
   first AG, FP8 is broken end-to-end on this machine. If
   `fwd_only` succeeds and `fwd_and_grad` also succeeds, the
   bug is "first-touch FP8 init takes longer than the 40 s
   `FirstCallRendezvous` timeout" ⇒ mitigation is below.
   ```bash
   DEMO_USE_FP8=1 DEMO_AUX_LOSS_COEFF=0 DEMO_WARMUP_FWD_ONLY=1 \
     bash moe_block_demo/run.sh
   ```
2. **Bump the `FirstCallRendezvous` timeout via the actual
   correct XLA flags** (the `--xla_gpu_executable_terminate_
   timeout_seconds` flag I suggested earlier was wrong; the
   real flags landed in [openxla/xla#15317](https://github.com/openxla/xla/pull/15317)):
   ```bash
   XLA_FLAGS="$XLA_FLAGS \
     --xla_gpu_first_call_rendezvous_warn_stuck_timeout_seconds=300 \
     --xla_gpu_first_call_rendezvous_terminate_timeout_seconds=600" \
     DEMO_USE_FP8=1 bash moe_block_demo/run.sh
   ```
   If the run completes (slowly), the hang is just a slow first-
   call rendezvous and the warmup knob (#1) is the right user-
   facing fix.
3. **`py-spy dump --pid <PID>` while hung** to see which Python
   frame each of the 4 worker threads is parked on. Run from a
   different shell once the hang has been visible for ~20 s.
4. **Minimal-repro FP8 grouped_dense on the same 4-GPU mesh
   outside MoEBlock**, e.g. via the existing
   `examples/jax/collective_gemm` scripts. If that works,
   MoEBlock's composition is implicated; if that also hangs,
   it's an FP8/JAX/NCCL toolchain issue on this box.

### What we ruled out

- cuBLASLt XLA autotune: ``XLA_FLAGS=--xla_gpu_autotune_level=0``
  also hangs (so XLA-level autotune isn't the trigger).
- HLO compile-time divergence per rank: HLO is identical across
  ranks (SPMD).
- The extra `psum` from the P1 aux-loss fix (already removed,
  hang persisted).
- The aux branch entirely (`AUX_LOSS_COEFF=0` still hangs).
- The flag `--xla_gpu_executable_terminate_timeout_seconds` does
  not exist in current XLA. The right flags are
  `--xla_gpu_first_call_rendezvous_{warn_stuck,terminate}_timeout_seconds`.

---

## Pivot fallback (if Stage 0a takes too long)

If FP8 baseline debugging stalls beyond a session, we can pivot to
**bf16-runtime + FP8-HLO-only verification** for Exp 1:

- Stages 1-4 implemented as planned.
- Stage 5 tests:
  - bf16 numerical correctness of knob=True vs knob=False (full
    runtime).
  - FP8: HLO-only assertion (operand dtype, operand shape) — no
    runtime numerical match.
- Stage 6 demo: bf16 lane fully exercised; FP8 lane is HLO-dump
  only.

This lets Exp 1 land while the FP8-baseline hang is investigated as
separate work. Acknowledged trade-off: no runtime evidence that
"quantize-before-AG produces same numerical result as quantize-
after-AG under FP8". Mitigation: a synthetic single-device FP8
test that emulates sharding manually and compares both paths.

---

## Files to touch (when work resumes)

- `transformer_engine/jax/flax/moe.py` — `MoEBlock`'s
  `quantize_before_fsdp_ag` field, `kernel_fsdp_info` derivation,
  shard_map `in_specs` change.
- `transformer_engine/jax/cpp_extensions/quantization.py` —
  `grouped_quantize`'s `amax_scope` parameter.
- `transformer_engine/jax/dense.py` — `_grouped_dense_fwd_rule` /
  `_grouped_dense_bwd_rule` lift the assert; implement the
  branch-on-fsdp-dim local-quantize-then-AG / AG-then-RS-of-wgrad.
- `tests/jax/test_distributed_moe_block.py` — FP8 tests.
- `moe_block_demo/run_demo.py` — `DEMO_QUANTIZE_BEFORE_FSDP_AG`
  knob.
- `moe_block_demo/compare_hlo.py` — knob-True/False HLO lane.
- `moe_block_demo/WIP_analysis.md` — Exp 1 results.
