"""Run TransformerEngine ``MoEBlock`` end-to-end on a 2x2 mesh.

This is a self-contained dev driver that mirrors the logical setup in
``tests/jax/test_distributed_moe_block.py`` but with a slightly larger
batch (8 instead of 2) and produces three artifacts useful for
analysing the ragged-all-to-all (A2Av) EP strategy:

  1. ``output/sharded_shapes.txt`` -- per-shard tensor shapes and
     ``NamedSharding`` specs of every named MoE input/param/output
     (printed at runtime to stdout AND saved).
  2. ``output/hlo/`` -- HLO dumps for the forward+backward jitted
     function. Use the ``module_*after_optimizations.txt`` file as the
     post-optimisation HLO, which is the one whose collectives match
     what runs at execution time.
  3. ``output/xprof/`` -- a JAX profiler trace dir; open in
     TensorBoard / xprof for an op-level timeline.

Plus a console summary of the unique cross-shard collectives in the
forward+backward HLO (all-gather, ragged-all-to-all, all-reduce,
reduce-scatter, all-to-all), which the diagram script relies on for
cross-checking.

Run with::

    bash moe_block_demo/run.sh

That wrapper sets ``XLA_FLAGS`` so HLO is dumped under ``output/hlo``.
The script itself just needs JAX + TE + 4 visible GPUs.
"""

from __future__ import annotations

import os
import re
import sys
from collections import Counter
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path scrubbing: this workspace contains a ``jax/`` source-tree
# checkout next to the demo dir. If any sys.path entry has that
# checkout as a child, ``import jax`` resolves to the half-loaded
# source tree (no ``jax.Array``, no ``jax.tree_util``) and flax then
# explodes with ``AttributeError: module 'jax' has no attribute
# 'Array'`` at import time. Drop those entries up front so the
# installed ``jax`` package wins.
# ---------------------------------------------------------------------------
def _scrub_sys_path() -> None:
    bad = []
    for p in list(sys.path):
        if not p:
            # Empty string / cwd entry. Drop it -- we run from the
            # repo dir which has a ``jax/`` subdir under it.
            bad.append(p)
            continue
        try:
            if (Path(p) / "jax" / "__init__.py").is_file():
                bad.append(p)
        except OSError:
            pass
    for p in bad:
        try:
            sys.path.remove(p)
        except ValueError:
            pass


_scrub_sys_path()

# Import order matters: jax (and its submodules) must be fully loaded
# before flax imports them via ``jax.Array`` / ``jax.tree_util``.
import jax  # noqa: E402
import jax.numpy as jnp  # noqa: E402
import jax.tree_util  # noqa: E402, F401  (force submodule registration)
import numpy as np  # noqa: E402
from jax.sharding import Mesh, PartitionSpec  # noqa: E402

import flax.linen as nn  # noqa: E402  -- must come after jax submodules

from transformer_engine.common import recipe  # noqa: E402
from transformer_engine.jax import MeshResource, autocast  # noqa: E402
from transformer_engine.jax.flax import MoEBlock  # noqa: E402


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
# All numeric dims and the mesh sizes are env-var-overridable so a wrapper
# script (e.g. ``run_realistic.sh``) can re-use this driver at larger
# dims without forking the file. Defaults match the small "every-dim-
# distinct" config used to validate the plumbing (B != S != H != I != E
# != K so per-shard shapes are unambiguous in the printed log and SVG).
def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    return int(raw) if raw not in (None, "") else default


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    return float(raw) if raw not in (None, "") else default


BATCH_SIZE = _env_int("DEMO_BATCH_SIZE", 8)
SEQUENCE_LENGTH = _env_int("DEMO_SEQUENCE_LENGTH", 32)
HIDDEN_SIZE = _env_int("DEMO_HIDDEN_SIZE", 64)
INTERMEDIATE_SIZE = _env_int("DEMO_INTERMEDIATE_SIZE", 128)
NUM_EXPERTS = _env_int("DEMO_NUM_EXPERTS", 16)
NUM_EXPERTS_PER_TOK = _env_int("DEMO_NUM_EXPERTS_PER_TOK", 2)
NUM_PROFILE_ITERS = _env_int("DEMO_NUM_PROFILE_ITERS", 3)
DTYPE = jnp.bfloat16
# ``DEMO_PERMUTATION_BACKEND`` is overridable. MXFP8 pins to ``triton``
# below because the pure-JAX dispatch buffer formula
# (``num_real + num_experts*(align-1)``) is not align-aligned, while the
# triton path rounds the buffer down to alignment as required by
# block-scaling FFIs. Other recipes default to ``pure_jax`` so the
# legacy bf16 / fp8_cs runs continue to use the same backend they
# always did.
PERMUTATION_BACKEND = os.environ.get("DEMO_PERMUTATION_BACKEND", "").strip().lower() or None
# ``DEMO_AUX_LOSS_COEFF=0`` disables the aux-loss branch (and its
# associated global all-gather / re-route_topk inside _a2a_body) ⇒
# useful for isolating whether bugs/hangs originate from the aux
# branch vs. the main routing path.
AUX_LOSS_COEFF = _env_float("DEMO_AUX_LOSS_COEFF", 1e-2)

# 2x2 mesh -> 4 GPUs (defaults). ``DEMO_EP_SIZE`` / ``DEMO_FSDP_SIZE``
# can override for boxes with more devices.
EP_AXIS = "ep"
FSDP_AXIS = "fsdp"
EP_SIZE = _env_int("DEMO_EP_SIZE", 2)
FSDP_SIZE = _env_int("DEMO_FSDP_SIZE", 2)

# FSDP convention. Two valid choices:
#   "embed" - shard H (the embed dim) for both wi_* and wo. This is
#             what Maxtext does (see moe.py:1837-1839 -- they shard
#             ``embed_tensor_transpose`` for all three). For wi_* it
#             shards the contracting dim; for wo it shards the
#             non-contracting dim. Mixed layout but historically chosen
#             for AG-loop transpose-fusion reasons.
#   "mlp"   - shard I (the mlp/intermediate dim) for both wi_* and wo.
#             For wi_* it shards the non-contracting dim; for wo it
#             shards the contracting dim. Mirror image of the above.
# Either way the total bytes/shard are identical
# (E_local * H * I / fsdp).
FSDP_LOGICAL_AXIS = os.environ.get("FSDP_LOGICAL_AXIS", "mlp")
assert FSDP_LOGICAL_AXIS in ("embed", "mlp")

# Quantization recipe selection. Set ``DEMO_QUANT_RECIPE`` to one of:
#   bf16   (default) - no autocast, bf16 end-to-end.
#   fp8_cs           - ``Float8CurrentScaling`` (per-tensor amax computed
#                      every step). Hits the V1 grouped quant + GEMM
#                      path because the V2 path is gated to MXFP8 only.
#   mxfp8            - ``MXFP8BlockScaling`` (per-32-element block).
#                      Hits the V2 (CUDA-graph-safe, cuBLASLt-bound)
#                      grouped quant + GEMM path on SM100+ when shape
#                      constraints are met (H/I % 128 == 0, M %
#                      align_size == 0 with align_size >= 128 for
#                      true V2). **This is the production target
#                      since we are no longer using V1 in real
#                      workloads.** The realistic preset
#                      (``run_realistic.sh``: H = I = 2048) satisfies
#                      V2; the toy preset (H = 64) silently falls back
#                      to V1.
#
# ``DelayedScaling`` is intentionally not exposed: ``GroupedQuantizer``
# doesn't currently accept the DelayedScaling-specific kwargs
# (``margin``/``amax_history``/``amax_compute_algo``) that
# ``QuantizerFactory.create`` forwards. Pending TE-side fix.
#
# Legacy alias: ``DEMO_USE_FP8=1`` (with no ``DEMO_QUANT_RECIPE`` set)
# is treated as ``DEMO_QUANT_RECIPE=fp8_cs`` for backward compatibility
# with existing scripts and HLO output dirs.
_QUANT_RECIPE_TAG = os.environ.get("DEMO_QUANT_RECIPE", "").strip().lower()
if not _QUANT_RECIPE_TAG:
    _QUANT_RECIPE_TAG = "fp8_cs" if bool(_env_int("DEMO_USE_FP8", 0)) else "bf16"

_RECIPE_TABLE = {
    "bf16": (None, "bf16"),
    "fp8_cs": (recipe.Float8CurrentScaling, "fp8_cs"),
    "mxfp8": (recipe.MXFP8BlockScaling, "mxfp8"),
}
if _QUANT_RECIPE_TAG not in _RECIPE_TABLE:
    raise ValueError(
        f"Unknown DEMO_QUANT_RECIPE={_QUANT_RECIPE_TAG!r}; expected one of"
        f" {sorted(_RECIPE_TABLE)}"
    )
_recipe_cls, QUANT_TAG = _RECIPE_TABLE[_QUANT_RECIPE_TAG]
FP8_RECIPE = _recipe_cls() if _recipe_cls is not None else None
USE_FP8 = FP8_RECIPE is not None

# Recipe-driven defaults for ``align_size`` and ``permutation_backend``.
#
# MXFP8 + grouped quantize requires *each per-group M to be divisible
# by 128* (V2 dispatch dynamic constraint, asserted at runtime by
# ``get_tensor_rows_num``: "First dimension of each tensor in a group
# must be divisible by 128") AND the whole post-permute buffer's row
# count to be divisible by ``block_x = 32``. Achieving both at once
# requires:
#
#   1. ``align_size = 128`` so each per-expert group rounds up to a
#      multiple of 128 (which, since 128 % 32 == 0, also satisfies the
#      block_x=32 check on each group).
#   2. ``permutation_backend = "triton"`` so the *whole buffer* is also
#      align-aligned. The pure-JAX dispatch buffer formula is
#      ``num_real + num_experts*(align-1)``, which is generally NOT
#      align-aligned (the trailing padding region only goes up to
#      align-1 per expert, not full align). The triton path rounds the
#      buffer down to ``floor(... / align) * align`` and is therefore
#      strictly align-aligned.
#
# Both can be overridden with ``DEMO_ALIGN_SIZE`` /
# ``DEMO_PERMUTATION_BACKEND`` for experiments. Other recipes
# (bf16, fp8_cs) keep ``align_size = 0`` + ``permutation_backend =
# "pure_jax"`` -- the legacy defaults that every existing artifact
# under ``output/`` was generated with.
if QUANT_TAG == "mxfp8":
    _default_align_size = 128
    _default_backend = "triton"
else:
    _default_align_size = 0
    _default_backend = "pure_jax"
ALIGN_SIZE = _env_int("DEMO_ALIGN_SIZE", _default_align_size)
if PERMUTATION_BACKEND is None:
    PERMUTATION_BACKEND = _default_backend
assert PERMUTATION_BACKEND in ("pure_jax", "triton"), (
    f"Unknown DEMO_PERMUTATION_BACKEND={PERMUTATION_BACKEND!r};"
    " expected 'pure_jax' or 'triton'"
)

# Experiment-1 knob: when 1, ``MoEBlock`` keeps the FSDP dim of wi_*/wo
# sharded across the EP shard_map boundary so ``grouped_dense`` can
# quantize per-shard BEFORE the FSDP all-gather (FP8 AG payload
# instead of bf16). Requires the matching enablement in
# ``_grouped_dense_fwd_rule``; otherwise traces fail at the
# ``not kernel_fsdp_enabled`` assertion.
QUANTIZE_BEFORE_FSDP_AG = bool(_env_int("DEMO_QUANTIZE_BEFORE_FSDP_AG", 0))

# Each ``FSDP_LOGICAL_AXIS`` run gets its own subdir under ``output/``
# so artefacts from the ``mlp`` and ``embed`` conventions coexist
# without manual renaming. ``DEMO_RUN_NAME`` (e.g. ``dsv3_mini``) adds
# an extra prefix layer so realistic vs tiny runs do not collide.
#
# The quantization tag is appended only when not bf16, so the default
# bf16 layout stays exactly ``output/[<run>/]fsdp_<axis>/`` -- matches
# what every existing helper (compare_hlo.py, analyze_xprof.py,
# build_diagram.py, run_variance.sh, start_xprof.sh) already globs for.
# Non-bf16 artefacts land at ``output/[<run>/]fsdp_<axis>_<tag>/``
# (e.g. ``..._fp8_cs/``, ``..._mxfp8/``) so they coexist without
# clobbering anything.
DEMO_RUN_NAME = os.environ.get("DEMO_RUN_NAME", "")
_run_dir = Path(__file__).resolve().parent / "output"
if DEMO_RUN_NAME:
    _run_dir = _run_dir / DEMO_RUN_NAME
_axis_dir = f"fsdp_{FSDP_LOGICAL_AXIS}"
if QUANT_TAG != "bf16":
    _axis_dir = f"{_axis_dir}_{QUANT_TAG}"
if QUANTIZE_BEFORE_FSDP_AG:
    _axis_dir = f"{_axis_dir}_qb4ag"
OUTPUT_DIR = _run_dir / _axis_dir
HLO_DIR = OUTPUT_DIR / "hlo"
XPROF_DIR = OUTPUT_DIR / "xprof"
SHAPES_TXT = OUTPUT_DIR / "sharded_shapes.txt"
COLLECTIVES_TXT = OUTPUT_DIR / "collective_summary.txt"


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------
def _fmt_sharding(arr: jax.Array) -> str:
    sh = arr.sharding
    if hasattr(sh, "spec"):
        return f"NamedSharding(spec={sh.spec})"
    return repr(sh)


def _print_and_save(lines, path: Path):
    text = "\n".join(lines)
    print(text)
    path.write_text(text + "\n")


def _unwrap(x):
    return x.value if hasattr(x, "value") else x


# ---------------------------------------------------------------------------
# HLO collective scan
# ---------------------------------------------------------------------------
COLLECTIVE_OPS = (
    "all-gather",
    "all-reduce",
    "all-to-all",
    "ragged-all-to-all",
    "reduce-scatter",
    "collective-permute",
)


def scan_hlo_collectives(hlo_dir: Path) -> str:
    """Walk ``hlo_dir`` for the post-optimisation HLO of the most recent
    fwd_and_grad compile and return a formatted summary of unique
    collective ops.

    HLO instruction syntax (post-opt)::

        %name.id = <type-shape> <op>[-start|-done](operands), ..., metadata=...

    The op token always has whitespace before and ``(`` after, so
    matching ``\\s+<op>[-start|-done]?\\s*\\(`` works regardless of the
    type prefix. Async ``-start`` / ``-done`` variants are reported
    separately so logical totals stay clear.
    """
    if not hlo_dir.exists():
        return "(no HLO directory; XLA_FLAGS not set?)"

    # Prefer the fwd_and_grad module so the summary is tied to the
    # actual step HLO (not the small jit_init / threefry modules that
    # XLA also dumps).
    candidates = sorted(
        hlo_dir.glob("module_*jit_fwd_and_grad*after_optimizations.txt")
    )
    if not candidates:
        candidates = sorted(hlo_dir.glob("module_*after_optimizations.txt"))
    if not candidates:
        candidates = sorted(hlo_dir.glob("module_*.txt"))
    if not candidates:
        return "(no HLO dump files in hlo_dir)"

    pick = max(candidates, key=lambda p: p.stat().st_mtime)
    text = pick.read_text(errors="replace")

    op_re = re.compile(
        r"\s+(?P<op>"
        + "|".join(re.escape(o) for o in COLLECTIVE_OPS)
        + r")(?P<phase>-start|-done)?\s*\("
    )
    totals: Counter[str] = Counter()
    sync_async: Counter[tuple] = Counter()
    for line in text.splitlines():
        m = op_re.search(line)
        if not m:
            continue
        op = m.group("op")
        phase = m.group("phase") or ""
        if phase == "-done":
            # Each -start has a paired -done; count only the start so
            # ``totals`` = number of distinct collective invocations.
            continue
        totals[op] += 1
        sync_async[(op, "async" if phase else "sync")] += 1

    lines = [f"HLO file: {pick}"]
    if not totals:
        lines.append("  (no cross-device collectives found)")
        return "\n".join(lines)
    for name in COLLECTIVE_OPS:
        if totals[name]:
            sync = sync_async[(name, "sync")]
            asyn = sync_async[(name, "async")]
            lines.append(
                f"  {name:20s}  total={totals[name]:3d}  sync={sync}  async={asyn}"
            )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> int:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    HLO_DIR.mkdir(parents=True, exist_ok=True)
    XPROF_DIR.mkdir(parents=True, exist_ok=True)

    devices = jax.devices()
    if len(devices) < EP_SIZE * FSDP_SIZE:
        print(
            f"need {EP_SIZE * FSDP_SIZE} devices, got {len(devices)}",
            file=sys.stderr,
        )
        return 2

    mesh_devices = np.asarray(devices[: EP_SIZE * FSDP_SIZE]).reshape(
        EP_SIZE, FSDP_SIZE
    )
    mesh = Mesh(mesh_devices, (EP_AXIS, FSDP_AXIS))

    # ``batch`` is always sharded on FSDP for input parallelism. The
    # weight FSDP axis is configurable: shard either ``embed`` (Maxtext
    # default, also matches the distributed test) or ``mlp``. The same
    # logical axis is used for BOTH wi and wo so they shard the same
    # physical dim across kernels (no resharding between layers); under
    # ``embed -> fsdp`` this puts FSDP on wi axis 1 (M-side of
    # ``flatten_axis=2``) and wo axis 2 (K-side); under ``mlp -> fsdp``
    # vice-versa. The grouped_dense FSDP-AG helper handles both M-side
    # and K-side cases (tensor scaling on either side, MXFP8 with the
    # MoEBlock-level per-shard mult-of-128 alignment guard).
    logical_axis_rules = (
        ("exp", EP_AXIS),
        ("batch", FSDP_AXIS),
        (FSDP_LOGICAL_AXIS, FSDP_AXIS),
    )

    # Experiment 3 (now the official default): batch is sharded over
    # BOTH ``ep`` and ``fsdp`` simultaneously, mirroring Maxtext's
    # ``activation_batch = ('data','fsdp','expert')`` rule. Each device
    # ends up with B/(ep*fsdp) unique tokens (true FSDP), instead of
    # the legacy ZeRO-1 layout where fsdp peers within an ep group held
    # identical activations.
    block = MoEBlock(
        num_experts=NUM_EXPERTS,
        num_experts_per_tok=NUM_EXPERTS_PER_TOK,
        intermediate_size=INTERMEDIATE_SIZE,
        permutation_backend=PERMUTATION_BACKEND,
        align_size=ALIGN_SIZE,
        aux_loss_coeff=AUX_LOSS_COEFF,
        dtype=DTYPE,
        expert_parallelism_axis=EP_AXIS,
        data_parallelism_axes=(FSDP_AXIS,),
        mesh=mesh,
        input_axes=("batch", None, None),
        quantize_before_fsdp_ag=QUANTIZE_BEFORE_FSDP_AG,
    )

    init_key, data_key = jax.random.split(jax.random.PRNGKey(11))
    inputs = jax.random.normal(
        data_key, (BATCH_SIZE, SEQUENCE_LENGTH, HIDDEN_SIZE), dtype=DTYPE
    )

    # ------------------------------------------------------------------
    # Initialise sharded params via the canonical Flax-Linen pattern.
    # ------------------------------------------------------------------
    with mesh, autocast(
        enabled=USE_FP8,
        recipe=FP8_RECIPE,
        mesh_resource=MeshResource(fsdp_resource=FSDP_AXIS),
    ):
        with nn.logical_axis_rules(logical_axis_rules):
            abstract_variables = jax.eval_shape(block.init, init_key, inputs)
            logical_partition_spec = nn.get_partition_spec(abstract_variables)
            out_shardings = nn.logical_to_mesh_sharding(
                logical_partition_spec, mesh, logical_axis_rules
            )
            sharded_variables = jax.jit(
                block.init, out_shardings=out_shardings
            )(init_key, inputs)

            # Materialise inputs with the desired layout too, so the
            # input shows up in HLO as already-sharded over BOTH ep and
            # fsdp -- matching the shard_map's in_specs so XLA emits NO
            # entry/exit collective-permute (the ``P('fsdp')->P('ep')``
            # reshard you see in the legacy demo disappears here).
            inputs_sharding = jax.sharding.NamedSharding(
                mesh, PartitionSpec((EP_AXIS, FSDP_AXIS), None, None)
            )
            inputs_sharded = jax.device_put(inputs, inputs_sharding)

    # ------------------------------------------------------------------
    # Print + save sharding summary for params + inputs.
    # ------------------------------------------------------------------
    lines = [
        f"=== MoEBlock demo: {EP_AXIS}={EP_SIZE} x {FSDP_AXIS}={FSDP_SIZE} mesh ===",
        f"B={BATCH_SIZE}, S={SEQUENCE_LENGTH}, H={HIDDEN_SIZE},"
        f" I={INTERMEDIATE_SIZE}, E={NUM_EXPERTS}, k={NUM_EXPERTS_PER_TOK},"
        f" dtype={DTYPE.dtype}",
        f"permutation_backend={PERMUTATION_BACKEND},"
        f" align_size={ALIGN_SIZE}, aux_loss_coeff={AUX_LOSS_COEFF}",
        f"FSDP shards weight axis: {FSDP_LOGICAL_AXIS!r}"
        f" (rule: {FSDP_LOGICAL_AXIS!r} -> {FSDP_AXIS!r})",
        f"quantization: {QUANT_TAG}"
        + (
            f" (recipe={type(FP8_RECIPE).__name__})"
            if FP8_RECIPE is not None
            else ""
        ),
        f"quantize_before_fsdp_ag={QUANTIZE_BEFORE_FSDP_AG}",
        "",
        "--- input ---",
        f"  inputs : global shape={inputs_sharded.shape},"
        f" sharding={_fmt_sharding(inputs_sharded)}",
        "",
        "--- parameters (sharded after jit-init) ---",
    ]
    for name, val in sharded_variables["params"].items():
        arr = _unwrap(val)
        lines.append(
            f"  {name:14s}: global shape={tuple(arr.shape)},"
            f" sharding={_fmt_sharding(arr)}"
        )
    _print_and_save(lines, SHAPES_TXT)

    # ------------------------------------------------------------------
    # Build forward + value_and_grad; jit it so XLA produces one HLO
    # module per (fwd, bwd) we can scan for collectives.
    # ------------------------------------------------------------------
    def loss_fn(variables, x):
        output, aux_loss = block.apply(variables, x)
        loss = jnp.mean(output.astype(jnp.float32) ** 2)
        if aux_loss is not None:
            loss = loss + aux_loss.astype(jnp.float32)
        return loss, (output, aux_loss)

    @jax.jit
    def fwd_only(variables, x):
        return loss_fn(variables, x)

    @jax.jit
    def fwd_and_grad(variables, x):
        return jax.value_and_grad(loss_fn, has_aux=True)(variables, x)

    # ------------------------------------------------------------------
    # Run once to compile (HLO is dumped during compile by XLA), once
    # under the profiler to capture xprof.
    #
    # ``DEMO_WARMUP_FWD_ONLY=1`` runs ``fwd_only`` once before
    # ``fwd_and_grad``. Useful as an FP8 debugging knob: any FP8
    # quantize / cuBLASLt FP8 first-call init that happens once per
    # process is paid here, *before* the timed ``fwd_and_grad`` ⇒
    # the ``fwd_and_grad`` first-call rendezvous no longer competes
    # with that init for the 40 s timeout. If the ``fwd_only`` step
    # itself hangs, the issue is purely first-touch FP8 (not a
    # rendezvous timing issue).
    if _env_int("DEMO_WARMUP_FWD_ONLY", 0):
        print("\n--- warmup: forward only (compile + run) ---")
        with mesh, autocast(
            enabled=USE_FP8,
            recipe=FP8_RECIPE,
            mesh_resource=MeshResource(fsdp_resource=FSDP_AXIS),
        ):
            with nn.logical_axis_rules(logical_axis_rules):
                wloss, _ = jax.block_until_ready(
                    fwd_only(sharded_variables, inputs_sharded)
                )
        print(f"  warmup fwd_only loss = {float(wloss):.6f}")

    print("\n--- forward+grad (compile + run) ---")
    with mesh, autocast(
        enabled=USE_FP8,
        recipe=FP8_RECIPE,
        mesh_resource=MeshResource(fsdp_resource=FSDP_AXIS),
    ):
        with nn.logical_axis_rules(logical_axis_rules):
            (loss_v, (output_v, aux_v)), grads = jax.block_until_ready(
                fwd_and_grad(sharded_variables, inputs_sharded)
            )

    print(
        f"  loss     : value={float(loss_v):.4f},"
        f" sharding={_fmt_sharding(loss_v)}"
    )
    print(
        f"  output   : shape={tuple(output_v.shape)},"
        f" sharding={_fmt_sharding(output_v)}"
    )
    if aux_v is not None:
        print(
            f"  aux_loss : value={float(aux_v):.4f},"
            f" sharding={_fmt_sharding(aux_v)}"
        )
    for name in ("gate_kernel", "wi_0", "wi_1", "wo"):
        g = _unwrap(grads["params"][name])
        print(
            f"  d{name:13s}: shape={tuple(g.shape)},"
            f" sharding={_fmt_sharding(g)}"
        )

    # --------------------------------------------------------------
    # Profiler trace.
    # --------------------------------------------------------------
    print(f"\n--- profiler trace -> {XPROF_DIR} ---")
    with mesh, autocast(
        enabled=USE_FP8,
        recipe=FP8_RECIPE,
        mesh_resource=MeshResource(fsdp_resource=FSDP_AXIS),
    ):
        with nn.logical_axis_rules(logical_axis_rules):
            with jax.profiler.trace(str(XPROF_DIR), create_perfetto_link=False):
                for _ in range(NUM_PROFILE_ITERS):
                    out = jax.block_until_ready(
                        fwd_and_grad(sharded_variables, inputs_sharded)
                    )
                del out

    # ------------------------------------------------------------------
    # HLO collective summary. XLA already dumped HLO via XLA_FLAGS; we
    # just scan the dump dir.
    # ------------------------------------------------------------------
    print("\n--- HLO collective summary ---")
    summary = scan_hlo_collectives(HLO_DIR)
    print(summary)
    COLLECTIVES_TXT.write_text(summary + "\n")

    print(f"\nArtifacts written under {OUTPUT_DIR}")
    print(f"  shapes      : {SHAPES_TXT}")
    print(f"  collectives : {COLLECTIVES_TXT}")
    print(f"  hlo dir     : {HLO_DIR}")
    print(f"  xprof dir   : {XPROF_DIR}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
