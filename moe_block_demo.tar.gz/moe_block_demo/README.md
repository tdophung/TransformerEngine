# MoEBlock A2A-EP demo

A small dev driver for `transformer_engine.jax.flax.MoEBlock` that
exercises the ragged-all-to-all (A2Av) expert-parallelism path on a
2x2 (`ep` x `fsdp`) mesh and emits artefacts useful for analysing the
strategy.

**Default layout: Experiment 3** (true FSDP). The shard_map's
`in_specs`/`out_specs` are `P(('ep','fsdp'), None, None)`, so each
device owns `B/(ep*fsdp)` UNIQUE batch tokens (no redundant compute
across fsdp peers within an ep group). To switch back to
the legacy ZeRO-1-style layout for comparison, set
`data_parallelism_axes=()` in `run_demo.py`.

```
output/
  sharded_shapes.txt          # per-tensor shapes + NamedSharding spec
  collective_summary.txt      # counts of cross-shard collectives in HLO
  moe_a2a_ep_dataflow.dot     # source DOT for the dataflow diagram
  moe_a2a_ep_dataflow.svg     # rendered SVG (per-shard sizes + comms)
  hlo/                        # XLA HLO dumps
  xprof/                      # JAX profiler trace dir (TensorBoard / xprof)
```

## Two run modes

There are two entry points depending on what you're trying to learn:

| Mode | Script | Dims | What you get |
|------|--------|------|--------------|
| **Toy demo** (default) | `bash moe_block_demo/run.sh` | tiny (every dim distinct so per-shard shapes are unambiguous; HLO is short enough to read end-to-end) | numerical correctness check, readable HLO, hand-built SVG dataflow diagram |
| **Realistic dims** | `bash moe_block_demo/run_realistic.sh` | DeepSeek-V3-mini (mirrors Maxtext's `profile_deepseek_te_4gpu.sh`) | meaningful xprof traces for kernel wall-time analysis, larger HLO that exercises real fusion patterns |

Both modes share the same Python driver (`run_demo.py`) and produce
the same artifact layout — they only differ in the dim env vars they
set, and in the `DEMO_RUN_NAME` prefix they put on the output dir
(`output/fsdp_<axis>/` for toy, `output/dsv3_mini/fsdp_<axis>/` for
realistic) so the two never collide.

### Toy demo dims (default)

Deliberately tiny so the HLO is short enough to read top-to-bottom
and `B != S != H != I != E != K`:

| dim | value |
|-----|-------|
| `B`        | 8 |
| `S`        | 32 |
| `H`        | 64 |
| `I`        | 128 |
| `E`        | 16 |
| `K` (topk) | 2 |
| dtype      | bf16 |
| permutation_backend | `pure_jax` |
| mesh       | `ep=2, fsdp=2` |
| `data_parallelism_axes` | `("fsdp",)` (Experiment 3 default) |

### Realistic-dims preset (`dsv3_mini`)

Mirrors Maxtext's `profile_deepseek_te_4gpu.sh`:

| dim | value |
|-----|-------|
| `B`        | 8   (per_device=2, ep=2, fsdp=2) |
| `S`        | 4096 |
| `H`        | 2048 |
| `I`        | 2048 (matches `base_moe_mlp_dim` scaled down) |
| `E`        | 64 |
| `K` (topk) | 8 |
| `DEMO_RUN_NAME` | `dsv3_mini` |
| `DEMO_NUM_PROFILE_ITERS` | 5 (more iters so xprof gets clean kernel timings) |

Per-device peak memory is roughly 768 MB weights + ~1 GB activations
for this preset — comfortable on H100/80 GB, tight on A100/40 GB.
Reduce `DEMO_BATCH_SIZE` or `DEMO_SEQUENCE_LENGTH` if you OOM.

All numeric dims are individually overridable. To get closer to full
DeepSeek-V3 671B (probably won't fit in 80 GB):

```
DEMO_RUN_NAME=ds671b DEMO_HIDDEN_SIZE=7168 DEMO_NUM_EXPERTS=256 \
    bash moe_block_demo/run_realistic.sh
```

## Running

### Toy demo

```
bash moe_block_demo/run.sh                       # default axis: mlp
FSDP_LOGICAL_AXIS=embed bash moe_block_demo/run.sh
```

### Realistic-dims demo

```
bash moe_block_demo/run_realistic.sh             # both axes (embed, then mlp)
bash moe_block_demo/run_realistic.sh embed       # one axis
DEMO_BATCH_SIZE=4 bash moe_block_demo/run_realistic.sh   # custom override
```

### FP8 / MXFP8 baseline (Experiment 1 prerequisite)

The default demo runs bf16 end-to-end. Set `DEMO_QUANT_RECIPE` to
switch quantization recipes:

| `DEMO_QUANT_RECIPE` | Recipe                  | Grouped-quant + GEMM path                    |
|---------------------|-------------------------|----------------------------------------------|
| `bf16` (default)    | none                    | n/a                                          |
| `fp8_cs`            | `Float8CurrentScaling`  | V1 (CurrentScaling not supported by V2)      |
| `mxfp8`             | `MXFP8BlockScaling`     | V2 (CUDA-graph-safe, cuBLASLt) on SM100+     |

```
DEMO_QUANT_RECIPE=mxfp8  bash moe_block_demo/run.sh             # toy
DEMO_QUANT_RECIPE=mxfp8  bash moe_block_demo/run_realistic.sh   # realistic
DEMO_QUANT_RECIPE=fp8_cs bash moe_block_demo/run_realistic.sh   # tensor scaling
DEMO_USE_FP8=1           bash moe_block_demo/run.sh             # legacy alias
                                                                 # for fp8_cs
```

The `mxfp8` path is the production target since the V1 grouped-quant +
GEMM path is no longer used in real workloads. V2 dispatch requires
`H % 128 == 0` *and* `I % 128 == 0`; the realistic preset (H = I =
2048) satisfies both, while the toy demo (H = 64) silently falls back
to V1.

The demo auto-selects MXFP8-friendly defaults when
`DEMO_QUANT_RECIPE=mxfp8`:

* `align_size = 128` -- so each per-expert group's row count is a
  multiple of 128 (V2 grouped-quant FFI's dynamic constraint
  ``First dimension of each tensor in a group must be divisible by
  128``).
* `permutation_backend = "triton"` -- so the *whole post-permute
  buffer* is also align-aligned. The pure-JAX dispatch buffer formula
  (`num_real + num_experts*(align-1)`) is generally not align-aligned,
  while the triton path rounds the buffer down to a multiple of
  `align_size`.

Both can be overridden via `DEMO_ALIGN_SIZE` and
`DEMO_PERMUTATION_BACKEND` if you want to experiment.

`DelayedScaling` is intentionally not exposed -- `GroupedQuantizer`
doesn't currently accept the DelayedScaling-specific kwargs
(`margin`/`amax_history`/`amax_compute_algo`) that
`QuantizerFactory.create` forwards. Pending TE-side fix.

Per-recipe artefacts land in sibling dirs so they coexist with bf16:

```
output/[<run>/]fsdp_<axis>/         # bf16 (default)
output/[<run>/]fsdp_<axis>_fp8_cs/  # CurrentScaling
output/[<run>/]fsdp_<axis>_mxfp8/   # MXFP8BlockScaling
```

This separation keeps the existing `compare_hlo.py`, `analyze_xprof.py`,
`build_diagram.py`, `run_variance.sh`, and `start_xprof.sh` helpers
working unchanged for the bf16 case. Recipe-specific tooling (added in
later Exp 1 stages) reads the `_<tag>` suffix path explicitly.

FP8 hardware (Hopper / Blackwell / sm_89+) is required at runtime for
any non-bf16 recipe; MXFP8 additionally requires SM100+ for the V2
dispatch. TE will raise on incompatible GPUs.

When the realistic run finishes, view the xprof traces. Two options:

```
# Option A: TensorBoard (single port, switch traces in the UI)
tensorboard --logdir moe_block_demo/output/dsv3_mini/ --port 6006

# Option B: xprof (one viewer per trace dir, each on its own port,
#          opens to the Profile tool by default - faster to compare
#          two axes side by side)
bash moe_block_demo/start_xprof.sh                 # all trace dirs
bash moe_block_demo/start_xprof.sh \
    dsv3_mini/fsdp_embed dsv3_mini/fsdp_mlp        # realistic only
bash moe_block_demo/start_xprof.sh \
    fsdp_embed fsdp_mlp                            # toy only

# The script prints an SSH tunnel command that forwards every
# assigned port in one go.
```

This:
1. Sets `XLA_FLAGS` to dump post-opt HLO under `output/hlo/`.
2. Runs `run_demo.py`:
   * builds `MoEBlock(expert_parallelism_axis="ep", mesh=...)` with the
     dims above;
   * resolves logical -> mesh shardings via the canonical Flax-Linen
     pattern (`jax.eval_shape` -> `nn.get_partition_spec` ->
     `nn.logical_to_mesh_sharding`) and `jax.jit(init,
     out_shardings=...)`;
   * compiles + runs `value_and_grad(loss_fn)` once (HLO gets dumped
     during the compile);
   * captures a JAX profiler trace over a few extra invocations.
3. Scans `output/hlo/module_*after_optimizations.txt` for collective
   ops and prints a summary.
4. Rebuilds the static dataflow SVG via `build_diagram.py`.

## Reading the artefacts

* `sharded_shapes.txt` -- the actual `NamedSharding(spec=...)` for each
  weight + activation. Confirms `wi_0/wi_1: P('ep','fsdp',None)`,
  `wo: P('ep',None,'fsdp')`, output `P('ep',None,None)`, etc.
* `moe_a2a_ep_dataflow.svg` -- per-shard view of the
  `_forward_a2a_ep` body. Each box lists the tensors that cross that
  stage's boundary with their per-shard shape and bf16 byte count.
  Edges colour-coded by collective:
    - red: ragged-all-to-all / all-to-all
    - blue: all-gather
    - green: reduce-scatter
    - purple: all-reduce
* `collective_summary.txt` -- ground truth count of those op types in
  the optimized HLO. Cross-check against the SVG; the SVG is hand-built
  from the source-level structure and the HLO can fuse / dedupe ops, so
  the counts will not match exactly but the *kinds* of collectives
  should.
* `hlo/module_*after_optimizations.txt` -- the full optimised HLO.
  Search for `ragged-all-to-all`, `all-gather`, `reduce-scatter` to
  find the actual lowering of each box-to-box collective.

## Comparing two FSDP-axis runs (Experiment 2)

Toy dims:

```
FSDP_LOGICAL_AXIS=embed bash moe_block_demo/run.sh
FSDP_LOGICAL_AXIS=mlp   bash moe_block_demo/run.sh
python3 moe_block_demo/compare_hlo.py             # embed vs mlp
python3 moe_block_demo/compare_hlo.py --out diff.txt
```

Realistic dims (`run_realistic.sh` runs both axes by default):

```
bash moe_block_demo/run_realistic.sh
python3 moe_block_demo/compare_hlo.py --run-name dsv3_mini \
    --out moe_block_demo/output/dsv3_mini/exp2_diff.txt
```

`compare_hlo.py` parses the post-opt HLO under
`output/fsdp_<axis>/hlo/` for both runs and prints a side-by-side
table of collective op counts, multi-tensor all-gather fusion (operand
count and replica_groups per AG), and every transpose permutation
(inline + inside `%fused_transpose` computations) tallied by pattern.
The "Hypothesis check" footer summarises the count deltas relevant to
Experiment 2.

`analyze_xprof.py` reads the chrome-trace JSON inside each xprof
capture directory and prints:

* a per-kernel summary (count, total / mean GPU stream wall time,
  which devices it ran on);
* a focused breakdown of the FSDP-AG-fixup transpose family
  (`loop_transpose_fusion*`, `input_transpose_fusion*`,
  `wrapped_transpose`) with per-kernel GPU totals + the timestamp of
  each kernel's first GPU event (so you can manually correlate
  fwd/bwd/late phases against the iter timeline);
* a side-by-side embed-vs-mlp diff for the transpose-family wall time
  (the metric Experiment 2 cares about).

```
# default: dsv3_mini, embed vs mlp, transpose family + diff
python3 moe_block_demo/analyze_xprof.py --filter transpose

# show every instance with its timestamp (for manual fwd/bwd splitting)
python3 moe_block_demo/analyze_xprof.py \
    --instances 'loop_transpose|input_transpose|wrapped_transpose'

# toy demo (no run-name prefix)
python3 moe_block_demo/analyze_xprof.py --run-name "" --filter transpose
```

This is the tool to use when xprof's UI is hiding kernels under
deduplicated names or framework scopes -- the trace JSON is
authoritative and contains every event.

### Run-to-run variance and ordering effects

A single embed-vs-mlp comparison from one trace each is not statistically
meaningful (especially for differences smaller than 10%). To check
whether the cross-axis delta is real or just within-axis run-to-run
noise, sweep N runs per axis and aggregate:

```
# 3 runs per axis, embed first then mlp
bash moe_block_demo/run_variance.sh

# 5 runs per axis, interleaved (e1, m1, e2, m2, ...) to expose
# any ordering / GPU-warmup bias
N=5 ORDER=interleave bash moe_block_demo/run_variance.sh

# Reverse order to detect first-run-pays-extra-compile/init effects
ORDER=mlp_first bash moe_block_demo/run_variance.sh

# Aggregate. Reports per-kernel mean+-stddev, cross-axis delta, and
# how many sigmas of separation -- |sigmas| < 1 means the delta is
# dominated by run-to-run noise.
python3 moe_block_demo/compare_variance.py --prefix dsv3_var \
    --filter 'TOTAL|TRANSPOSE_FAMILY|RAGGED_A2A|NCCL_TOTAL'
```

The synthesised buckets in the variance report:

| bucket | what it sums |
|---|---|
| `TOTAL` | every GPU-stream kernel (per-GPU total over the whole trace) |
| `TRANSPOSE_FAMILY` | `loop_transpose_fusion*` + `input_transpose_fusion*` + `wrapped_transpose` (the Experiment 2 metric) |
| `RAGGED_A2A` | `RaggedAllToAllKernelImpl` -- XLA's pure-CUDA implementation of `ragged_all_to_all`. Dominates total time at small B (single-SM busy-wait, NOT NCCL). See "Why is total time so different from Maxtext?" below. |
| `NCCL_TOTAL` | every `ncclDevKernel_*` (AG, RS, AR, A2A) |

### Why is the total iter time so different from Maxtext profiles?

If you run the same dims under Maxtext (`maxtext/profile_deepseek_te_4gpu.sh`),
one decoder-layer step is roughly **45 ms** while one iter of this
demo is roughly **190 ms**. The block does *less* work in our demo
(no attention, no embedding, no LM head), so the discrepancy comes
from a couple of structural differences worth knowing about before
reading any wall-time number out of this demo:

1. **Different EP strategy.** Maxtext's profile presets all set
   `use_ring_of_experts=true`. They never invoke `ragged_all_to_all`;
   instead expert dispatch goes through TE's Triton
   `_permute_kernel`/`_unpermute_kernel` and the cross-shard rotation
   uses NCCL `collective_permute`. This demo (by design) exercises
   the A2Av path, which lowers to XLA's
   `RaggedAllToAllKernelImpl` -- a pure-CUDA `grid:2 block:128`
   busy-wait coordinator, not a NCCL kernel. At dsv3_mini sizes the
   per-call cost (~58 ms each) dominates everything else; at much
   larger E (256+) the asymptotic story flips and A2Av wins, but
   you can't see that here.
2. **No FP8.** Maxtext's `dsv3_te_gmm` uses
   `quantization=te_fp8_currentscaling`; this demo runs bf16
   throughout. That doubles the bytes through every weight AG and
   roughly doubles GEMM wall time.
3. **Python loop dispatch.** Each iter is a separate
   `value_and_grad(loss_fn)(...)` call from a Python `for` loop. The
   first call eats compile time (we run a warm-up before
   `jax.profiler.trace`), but subsequent iters still pay
   PyJaxlib dispatch overhead between them. Maxtext uses a
   long-running training loop that hides all of this with
   pipelining.

So: trust this demo for the **small, structural** wall-time
deltas it's designed to measure (FSDP axis choice, weight layout,
collective fusion patterns). Don't read the absolute per-iter ms as
indicative of production performance.

## Re-running with the Triton permutation backend

Edit `run_demo.py` and set `PERMUTATION_BACKEND = "triton"`, then re-run.
The dataflow diagram is identical structurally; only the kernels
inside `_global_permute` / `_global_combine` change (Triton fused
dispatch/combine instead of pure-JAX argsort + custom-VJP gather).
