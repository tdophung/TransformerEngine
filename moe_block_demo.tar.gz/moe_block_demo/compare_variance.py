"""Aggregate kernel-time stats across multiple runs of the demo to expose
run-to-run variance and check whether the embed-vs-mlp delta is real
or noise.

Pairs with ``run_variance.sh``: that script runs the realistic demo N
times per axis and writes traces to::

    output/<prefix>_<axis>_<i>/fsdp_<axis>/xprof/.../*.trace.json.gz

This script loads every trace, parses it with ``analyze_xprof.parse_trace``,
and reports for each kernel:

* the mean and stddev of total GPU stream wall time across the N runs,
* the cross-axis delta (right minus left) divided by the within-axis
  pooled stddev, i.e. how many sigmas of separation -- if this is < 1
  the difference is dominated by noise.

You can also pass an explicit list of trace files via ``--trace`` for
ad-hoc comparisons.

Examples::

    # default: glob output/dsv3_var_{embed,mlp}_*/fsdp_{embed,mlp}/.../trace.json.gz
    python3 moe_block_demo/compare_variance.py --prefix dsv3_var

    # focus on transpose family + RAA + total
    python3 moe_block_demo/compare_variance.py --prefix dsv3_var \
        --filter 'transpose|RaggedAllToAll|TOTAL'

    # explicit traces (for paired analysis after a one-off rerun)
    python3 moe_block_demo/compare_variance.py \
        --left-traces  output/foo_embed_*/fsdp_embed/.../trace.json.gz \
        --right-traces output/foo_mlp_*/fsdp_mlp/.../trace.json.gz
"""

from __future__ import annotations

import argparse
import math
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

# Local sibling: reuse the parser to avoid drift.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from analyze_xprof import (  # type: ignore
    KernelStat,
    _is_gpu_device,
    _is_transpose_family,
    load_trace,
    parse_trace,
)

DEMO_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = DEMO_DIR / "output"

# Special bucket names; we synthesise these from kernel groups.
SPECIAL = ("TOTAL", "TRANSPOSE_FAMILY", "RAGGED_A2A", "NCCL_TOTAL")


# ---------------------------------------------------------------------------
# trace discovery
# ---------------------------------------------------------------------------


def find_traces_for_axis(prefix: str, axis: str) -> List[Path]:
    """Return every trace file for run dirs ``output/<prefix>_<axis>_<i>``."""
    pat = re.compile(rf"^{re.escape(prefix)}_{re.escape(axis)}_(\d+)$")
    runs: List[Tuple[int, Path]] = []
    if not OUTPUT_DIR.is_dir():
        return []
    for entry in OUTPUT_DIR.iterdir():
        if not entry.is_dir():
            continue
        m = pat.match(entry.name)
        if not m:
            continue
        seq = int(m.group(1))
        for tr in entry.glob(f"fsdp_{axis}/xprof/plugins/profile/*/*.trace.json.gz"):
            runs.append((seq, tr))
    runs.sort(key=lambda x: x[0])
    return [p for _, p in runs]


# ---------------------------------------------------------------------------
# aggregation
# ---------------------------------------------------------------------------


def gpu_total(stat: KernelStat) -> float:
    return sum(d for _, d, dev in stat.instances if _is_gpu_device(dev))


def aggregate_runs(traces: Sequence[Path]) -> Dict[str, List[float]]:
    """Return ``{kernel_name: [run0_total_us, run1_total_us, ...]}``.

    Includes synthesised buckets ``TOTAL`` (sum of every GPU kernel),
    ``TRANSPOSE_FAMILY`` (loop_/input_/wrapped_transpose), ``RAGGED_A2A``
    (any kernel containing "RaggedAllToAll"), ``NCCL_TOTAL`` (any
    "nccl"-prefixed kernel).
    """
    per_kernel: Dict[str, List[float]] = {}
    for run_idx, tr in enumerate(traces):
        stats = parse_trace(load_trace(tr))
        all_gpu = 0.0
        trans_gpu = 0.0
        raa_gpu = 0.0
        nccl_gpu = 0.0
        for ks in stats.values():
            t = gpu_total(ks)
            all_gpu += t
            if _is_transpose_family(ks.name):
                trans_gpu += t
            if "RaggedAllToAll" in ks.name:
                raa_gpu += t
            if "nccl" in ks.name.lower():
                nccl_gpu += t
            per_kernel.setdefault(ks.name, [0.0] * len(traces))
            per_kernel[ks.name][run_idx] = t
        for special, value in (
            ("TOTAL", all_gpu),
            ("TRANSPOSE_FAMILY", trans_gpu),
            ("RAGGED_A2A", raa_gpu),
            ("NCCL_TOTAL", nccl_gpu),
        ):
            per_kernel.setdefault(special, [0.0] * len(traces))
            per_kernel[special][run_idx] = value
    return per_kernel


def _mean_stddev(xs: Sequence[float]) -> Tuple[float, float]:
    n = len(xs)
    if n == 0:
        return float("nan"), float("nan")
    mean = sum(xs) / n
    if n < 2:
        return mean, 0.0
    var = sum((x - mean) ** 2 for x in xs) / (n - 1)
    return mean, math.sqrt(var)


def _fmt_us(us: float) -> str:
    if us != us:
        return "nan"
    if abs(us) < 1.0:
        return f"{us*1000:.1f}ns"
    if abs(us) < 1000.0:
        return f"{us:.2f}us"
    if abs(us) < 1_000_000.0:
        return f"{us/1000:.2f}ms"
    return f"{us/1_000_000:.3f}s"


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------


def render(
    left_label: str,
    left_per_kernel: Dict[str, List[float]],
    right_label: Optional[str],
    right_per_kernel: Optional[Dict[str, List[float]]],
    filter_re: Optional[re.Pattern[str]] = None,
) -> List[str]:
    out: List[str] = []
    n_left = len(next(iter(left_per_kernel.values()))) if left_per_kernel else 0
    n_right = (
        len(next(iter(right_per_kernel.values())))
        if right_per_kernel
        else 0
    )
    out.append(
        f"left  ({left_label}): {n_left} runs"
        + (
            f"   |   right ({right_label}): {n_right} runs"
            if right_per_kernel is not None
            else ""
        )
    )
    out.append("")
    names = set(left_per_kernel)
    if right_per_kernel is not None:
        names |= set(right_per_kernel)
    if filter_re is not None:
        names = {n for n in names if filter_re.search(n)}

    # Order: synthesised buckets first, then by left-mean descending.
    def _sort_key(name: str) -> Tuple[int, float]:
        if name in SPECIAL:
            return 0, -SPECIAL.index(name)
        m, _ = _mean_stddev(left_per_kernel.get(name, [0.0]))
        return 1, -m

    sorted_names = sorted(names, key=_sort_key)

    if right_per_kernel is None:
        out.append(
            f"  {'kernel':<48} {'mean':>10} {'stddev':>10} {'cv%':>6}"
        )
        out.append(f"  {'-'*48} {'-'*10} {'-'*10} {'-'*6}")
        for n in sorted_names:
            ls = left_per_kernel.get(n, [])
            mean, sd = _mean_stddev(ls)
            cv = (sd / mean * 100) if mean > 0 else 0.0
            out.append(
                f"  {n[:48]:<48} {_fmt_us(mean):>10} {_fmt_us(sd):>10} {cv:>5.1f}%"
            )
        return out

    out.append(
        f"  {'kernel':<40} {'left mean+-sd':>22} {'right mean+-sd':>22} "
        f"{'delta':>10} {'sigmas':>7}"
    )
    out.append(
        f"  {'-'*40} {'-'*22} {'-'*22} {'-'*10} {'-'*7}"
    )
    for n in sorted_names:
        # If a kernel name exists in only one axis it ran for 0us on the
        # other; fill with zeros instead of leaving it as nan so the
        # diff still makes sense (kernels that disappear are themselves
        # an interesting signal).
        ls = left_per_kernel.get(n) or [0.0] * n_left
        rs = right_per_kernel.get(n) or [0.0] * n_right
        lm, lsd = _mean_stddev(ls)
        rm, rsd = _mean_stddev(rs)
        delta = rm - lm
        # Pooled stddev (Welch-ish): sqrt(s_l^2/n_l + s_r^2/n_r). Skip
        # if either run set has < 2 samples.
        if len(ls) >= 2 and len(rs) >= 2:
            pooled = math.sqrt(lsd ** 2 / len(ls) + rsd ** 2 / len(rs))
            sigmas = (delta / pooled) if pooled > 0 else 0.0
            sig_str = f"{sigmas:+.2f}"
        else:
            sig_str = "n/a"
        l_str = f"{_fmt_us(lm)}+-{_fmt_us(lsd)}"
        r_str = f"{_fmt_us(rm)}+-{_fmt_us(rsd)}"
        out.append(
            f"  {n[:40]:<40} {l_str:>22} {r_str:>22} "
            f"{_fmt_us(delta):>10} {sig_str:>7}"
        )
    out.append("")
    out.append(
        "  sigmas = delta / sqrt(s_l^2/n_l + s_r^2/n_r). "
        "|sigmas| < 1 means the cross-axis delta is dominated by "
        "within-axis run-to-run variation."
    )
    return out


# ---------------------------------------------------------------------------
# entrypoint
# ---------------------------------------------------------------------------


def main() -> None:
    p = argparse.ArgumentParser(
        description=__doc__.split("\n", 1)[0],
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--prefix", default="dsv3_var", help="DEMO_RUN_NAME prefix")
    p.add_argument("--left", default="embed", help="left axis (default: embed)")
    p.add_argument("--right", default="mlp", help="right axis (default: mlp)")
    p.add_argument(
        "--left-traces",
        nargs="*",
        default=None,
        help="explicit list of left-axis trace files (overrides --prefix discovery)",
    )
    p.add_argument(
        "--right-traces",
        nargs="*",
        default=None,
        help="explicit list of right-axis trace files (overrides --prefix discovery)",
    )
    p.add_argument(
        "--filter",
        default=None,
        help="regex applied to kernel names; defaults to showing the synthesised "
        "buckets + everything if omitted",
    )
    p.add_argument(
        "--out",
        default=None,
        help="optional path to also write the rendered report to",
    )
    args = p.parse_args()

    if args.left_traces:
        left_paths = [Path(p) for p in args.left_traces]
    else:
        left_paths = find_traces_for_axis(args.prefix, args.left)
    if args.right_traces:
        right_paths = [Path(p) for p in args.right_traces]
    else:
        right_paths = find_traces_for_axis(args.prefix, args.right)

    if not left_paths and not right_paths:
        sys.exit(
            f"No traces found under {OUTPUT_DIR} matching prefix "
            f"'{args.prefix}'. Run ``run_variance.sh`` first or pass "
            f"--left-traces/--right-traces explicitly."
        )

    print(f"left ({args.left}) traces ({len(left_paths)}):")
    for p_ in left_paths:
        print(f"  {p_}")
    print(f"right ({args.right}) traces ({len(right_paths)}):")
    for p_ in right_paths:
        print(f"  {p_}")
    print()

    left_agg = aggregate_runs(left_paths) if left_paths else {}
    right_agg = aggregate_runs(right_paths) if right_paths else {}

    filt = re.compile(args.filter) if args.filter else None
    label_l = f"{args.prefix}/{args.left}"
    label_r = f"{args.prefix}/{args.right}" if right_paths else None
    lines = render(
        label_l,
        left_agg,
        label_r,
        right_agg if right_paths else None,
        filter_re=filt,
    )
    text = "\n".join(lines)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n")


if __name__ == "__main__":
    main()
