# MoE Block A2A-EP — WIP Analysis

Living document of findings from the `moe_block_demo` runs and HLO
analysis on a 4-GPU mesh `('ep'=2, 'fsdp'=2)` with the canonical demo
config:

```
B = 8     # global batch
S = 32    # sequence length
H = 64    # hidden / embed dim
I = 128   # intermediate / mlp dim
E = 16    # num experts
K = 2     # topK
ep   = 2  # mesh axis
fsdp = 2  # mesh axis
dtype = bf16
```

Run with `bash moe_block_demo/run.sh`. Two FSDP conventions are
swept via `FSDP_LOGICAL_AXIS={embed, mlp}`. Artifacts under
`moe_block_demo/output/fsdp_<axis>/`:

```
output/fsdp_<axis>/
  ├─ sharded_shapes.txt        # per-param physical NamedShardings
  ├─ collective_summary.txt    # XLA's logical collective counts
  ├─ moe_a2a_ep_dataflow.svg   # full fwd+bwd dataflow w/ collectives
  ├─ hlo/module_*after_optimizations.txt
  └─ xprof/                    # tensorboard-loadable profiler trace
```

---

## 1. End-to-end dataflow summary

The forward pipeline in `_forward_a2a_ep` (in
`transformer_engine/jax/flax/moe.py`) runs per ep-shard inside a
`shard_map`:

1. **Reshard input** `P('fsdp',_,_) → P('ep',_,_)`  (outer XLA, before
   shard_map). One `collective-permute`, batch-only.
2. **Gate** einsum `(inputs, gate_kernel) → gate_logits`. Runs in the
   outer scope; per-shard local data.
3. **Router topk** (`fused_topk_with_score_function`): produces
   `sparse_probs`, `routing_map`, local `group_sizes`.
4. **AG group_sizes over ep** → `[ep, E]` matrix
   `all_shards_tokens_per_expert`. **Single source feeding 4
   downstream stages**: forward RAA params, local permute, local
   unpermute, reverse RAA params.
5. **Aux-loss path** (in parallel): AG `logits_2d` over ep so the
   global aux loss sees the union of all shards' routing decisions.
6. **Global permute** (`unfused_token_dispatch`): sorts tokens
   expert-major, expanding by topK.
7. **Forward ragged-A2A over ep**: per-expert chunks routed to
   expert-owning shards.
8. **Local permute** (Triton `sort_chunks_by_index`): re-groups
   incoming buffer from `(source_shard, expert)` order to local
   expert-major order.
9. **3 grouped GEMMs** (`wi_0`, `wi_1`, `wo`): each AGs its weight
   slice along `fsdp`, runs full GEMM, output stays replicated across
   fsdp.
10. **Local unpermute** (Triton inverse).
11. **Reverse ragged-A2A over ep**: chunks back to original source
    shards.
12. **Global combine**: token combine + topK weighted sum.
13. **Output** stays at `P('ep',_,_)` (in real model: another reshard
    back to `P('fsdp',_,_)` for the next attention block).

The full dataflow is in
`output/fsdp_<axis>/moe_a2a_ep_dataflow.svg`.

---

## 2. Forward collective audit (post-optimization)

XLA's behavior is much smarter than the source-level dataflow
suggests. Cross-checking the SVG's predicted collectives against the
actual post-opt HLO from
`output/fsdp_<axis>/hlo/module_*after_optimizations.txt`:

| Source-level expectation | XLA's actual lowering |
|---|---|
| 1 `collective-permute` for `P('fsdp')→P('ep')` reshard | ✅ 1 op, `source_target_pairs={{0,0},{2,1},{1,2},{3,3}}` (4-device mesh, swaps (ep=0,fsdp=1) ↔ (ep=1,fsdp=0)) |
| 1 `all-gather (ep)` of group_sizes (int32) | ✅ Fused into a **multi-tensor (int32, bf16)** all-gather along with the aux-loss `logits_2d` AG — single NCCL call instead of two |
| 1 `all-gather (ep)` of `logits_2d` for aux loss | ✅ (fused as above) |
| 1 ragged-A2A (forward) `[B/ep*S*K, H] → [B*S*K, H]` per ep | ✅ `ragged-all-to-all-start` shape `[256→512]` |
| 3× `all-gather (fsdp)` of weights `wi_0, wi_1, wo` | ⚠️ XLA fuses **all three** into one **multi-tensor all-gather** along `dimensions={0}` (the leading dim of each per-shard kernel) regardless of which logical axis was sharded. **Empirically the same fusion happens for both `embed` and `mlp` conventions** (verified via `compare_hlo.py`). A bitcast + fused transpose then converts the AG output to the row-major `(E_local, K, N)` layout that `te_grouped_gemm_ffi` requires. The transpose op count is identical; only the *pattern* differs (see §4). |
| 1 ragged-A2A (reverse) `[B*S*K, H] → [B/ep*S*K, H]` per ep | ✅ `ragged-all-to-all-start.1` shape `[512→256]` |
| 1 `all-reduce (ep, f32[])` for the loss scalar | ✅ |

Plus two tiny `all-to-all` ops on int32 vectors that the ragged-A2A
implementation uses to shuffle send/recv offsets. These are O(E)
bytes each.

### Per-axis collective volume per training step

| Op | bytes-on-the-wire (per device) |
|---|---|
| collective-permute (input reshard) | `B/fsdp*S*H*2 = 16 KiB` |
| AG group_sizes (ep) | `E*4 = 64 B` |
| AG logits_2d for aux (ep) | `(B/ep*S)*E*2 = 4 KiB` |
| forward RAA (ep) | `(B/ep*S*K)*H*2 = 32 KiB` |
| FSDP AG of `wi_0+wi_1+wo` | `2 * shape(wi_*) + shape(wo) = 192 KiB` |
| reverse RAA (ep) | `(B*S*K)*H*2 = 64 KiB` |

(With realistic dims H≈4096, I≈14336, E≈64, the FSDP weight AGs and
the RAAs dominate by orders of magnitude. These tiny demo numbers
are to validate the *plumbing*.)

---

## 3. Backward collective audit

| Source-level expectation | XLA's actual lowering |
|---|---|
| ragged-A2A bwd of *forward* RAA `[B*S*K → B/ep*S*K]` | ❌ **DCE'd** — only consumer is `d(inputs)`, but `value_and_grad(loss_fn, argnums=variables)` doesn't request it. Net: only **3 ragged-A2As** in the HLO instead of the naively-expected 4. |
| ragged-A2A bwd of *reverse* RAA `[B/ep*S*K → B*S*K]` | ✅ `ragged-all-to-all-start.2`, shape `[256→512]` |
| 3× reduce-scatter of weight grads over fsdp + 1× AR of `dgate_kernel` over fsdp & ep | ⚠️ XLA fused `dwi_0 + dwi_1 + dwo + dgate_kernel` partials into ONE `bf16[197632]` **all-reduce over ep** + slice. Reasoning: messages are too small for RS to win; AR + slice is one less collective. |
| 1× all-reduce of `d_gate_logits` over fsdp | ✅ shape `bf16[B/ep,S,E] = bf16[4,32,16]`. Needed because `gate_kernel` is replicated → its grad needs reduction across batch shards. |
| 1× reduce-scatter of `d(global_logits_2d)` over ep (dual of fwd aux-AG) | ✅ shape `bf16[B/ep*S, E] = bf16[128,16]` |
| 1× collective-permute (dual of fwd input reshard) | ✅ `source_target_pairs={{0,0},{1,2},{2,1},{3,3}}` — swap pair reversed |
| AR of loss scalar over ep | (folded into fwd; one `f32[]` AR shared) |

So the *actual* bwd collective count is well below the naive count.
The full annotated bwd graph is in the SVG `cluster_bwd` subgraph,
including the DCE'd RAA shown as a dashed grey node.

---

## 3b. TE custom_partitioning audit (what GSPMD vs explicit handle)

| Primitive / surface | DP | TP / SP | FSDP |
|---|---|---|---|
| `dense` (`GemmPrimitive` w/ `infer_sharding_from_operands` + `partition` + `shardy_sharding_rule`, `cpp_extensions/gemm.py:1021/1054/1145`) | ✅ via output following lhs batch spec | ✅ explicit (`tp_resource`, `tpsp_resource`) | ✅ explicit ("Non-contracting dims of RHS always needs to be gathered along the FSDP axis", `gemm.py:940-952`) |
| `dense`'s `kernel_fsdp_info` knob (`dense.py:328`) | n/a | n/a | ✅ wired |
| `grouped_dense` (`GroupedGemmPrimitive` -- **no** `infer_sharding_from_operands` / `partition` / `shardy_sharding_rule`) | ✅ via GSPMD propagation only | ✅ via GSPMD propagation only | ⚠️ via GSPMD propagation only -- explicit knob is GATED off |
| `grouped_dense`'s `kernel_fsdp_info` knob | -- | -- | ❌ **`assert not kernel_fsdp_enabled, "FSDP sharding for grouped_dense is not supported yet."`** at `dense.py:411` (fwd) and `:468` (bwd) |

**Implication for the MoE FFN**:

- The fwd FSDP-AG-of-weights and bwd weight-grad reductions you see
  in the HLO today are entirely **GSPMD's doing** -- TE does nothing
  explicit. That's why our `MoEBlock` "just works" with
  `wi_*: P('ep','fsdp',None)` etc.
- Adding TP/SP later is a simple matter of declaring activation/weight
  shardings; GSPMD will propagate. No `MoEBlock`-level changes needed.
- The explicit `kernel_fsdp_info` route (Experiment 1: quantize-before-AG)
  is the one place where we *do* need to touch
  `grouped_dense` / `GroupedGemmPrimitive` -- because today it
  asserts off.

➡ Bottom line: **Experiment 3 needs to change the `shard_map`
in_specs/out_specs only**. DP/TP propagation is already free; the
new fsdp-axis weight-grad reduction will appear automatically once
the activations stop being replicated on `fsdp`.

---

## 4. FSDP `'embed'` vs `'mlp'` axis comparison

Two conventions for which logical axis maps to the `fsdp` mesh axis:

| Convention | `wi_*` layout | `wo` layout |
|---|---|---|
| `embed` | `P('ep','fsdp',None)` ⇒ shard `H` | `P('ep',None,'fsdp')` ⇒ shard `H` |
| `mlp` | `P('ep',None,'fsdp')` ⇒ shard `I` | `P('ep','fsdp',None)` ⇒ shard `I` |

### What `te_grouped_gemm_ffi` requires (from the embed HLO)

The TE custom call site pins down the cuBLASLt layout expectation
exactly. From `output/fsdp_embed/hlo/module_*after_optimizations.txt`,
`te_grouped_gemm_ffi.77/.78` (the `wi_0` / `wi_1` GEMMs):

```
operand_layout_constraints = {
    bf16[512,64]{1,0},        # LHS X = (M, H), row-major
    f32[0]{0},
    bf16[8,64,128]{2,1,0},    # RHS W = (E_local, H, I), STANDARD row-major
    ...
}
backend_config = {lhs_is_trans = false, rhs_is_trans = false, ...}
```

And `te_grouped_gemm_ffi.79` (the `wo` GEMM):

```
operand_layout_constraints = {
    bf16[512,128]{1,0},       # LHS = (M, I), row-major
    f32[0]{0},
    bf16[8,128,64]{2,1,0},    # RHS W = (E_local, I, H), STANDARD row-major
    ...
}
```

The decoded layout: dim-2 stride 1, dim-1 stride next, dim-0 stride
slowest. So TE wants the per-group kernel as **standard row-major
`(E_local, K, N)`** with the group dim as the slowest axis, the
contracting dim K (`H` for `wi_*`, `I` for `wo`) in the middle, and
the output dim N as the fastest axis. No transpose flag is set; the
kernel must arrive in this exact stride pattern.

### What XLA actually does for the AG (and why **both** conventions need a transpose)

Inspecting `%all-gather-start.1` in the embed HLO:

```
all-gather-start(wi_0, wi_1, wo), dimensions={0}, replica_groups=...
  bf16[8,32,128] -> bf16[16,32,128]    # wi_0 (per-shard -> AG)
  bf16[8,32,128] -> bf16[16,32,128]    # wi_1
  bf16[?,128,8]{1,2,0} -> bf16[64,128,8]{1,2,0}   # wo (note non-std layout)
```

XLA chose `dimensions={0}` for ALL three weights, even though for
`embed` the *logical* fsdp-sharded dim is dim 1 (`H`), not dim 0.
That's because NCCL all-gather natively concatenates each peer's
contribution along the leading dim of the buffer — gathering along
any other dim would require strided NCCL or an extra reshuffle. So
XLA always gathers along dim 0 and then *bitcasts + transposes* the
result into the `(E_local, K, N)` row-major layout TE wants. The
HLO shows this as a `%fused_transpose` op fed by the AG output.

**This means `embed` is *not* transpose-free.** Both conventions
incur a post-AG bitcast + transpose. The previous version of this
document overstated the case — that error has been corrected.

### Where the actual `embed` vs `mlp` cost difference comes from

The difference is *which permutation* the post-AG transpose has to
perform:

```
embed (fsdp shards dim 1, "H"):
  AG output  : (fsdp, E_local, H/fsdp, I)
  GEMM wants : (E_local, H, I)
  Permute    : move fsdp from dim 0 -> dim 1, then collapse with H/fsdp
               (fsdp, E_local, H/fsdp, I) -> (E_local, fsdp, H/fsdp, I)
                                          -> (E_local, H, I)
  Distance   : fsdp travels past ONE other dim (E_local).

mlp   (fsdp shards dim 2, "I"):
  AG output  : (fsdp, E_local, H, I/fsdp)
  GEMM wants : (E_local, H, I)
  Permute    : move fsdp from dim 0 -> dim 2, then collapse with I/fsdp
               (fsdp, E_local, H, I/fsdp) -> (E_local, H, fsdp, I/fsdp)
                                          -> (E_local, H, I)
  Distance   : fsdp travels past TWO other dims (E_local, H).
```

The `embed` permutation has the gathered axis only one position
removed from the destination, so the resulting strided memory access
pattern stays close to a pure copy and XLA can fold it into a
neighboring fusion (the multi-tensor all-gather wrapper, or the
GEMM's pre-load loop).

The `mlp` permutation has the gathered axis two dims removed, so the
output strides are larger and less coalesced. XLA either materializes
a separate transpose op (extra memory traffic = read-then-write of
the full kernel) or fuses it as `loop_transpose_fusion` with worse
locality. Either way it costs more than `embed`.

### Empirical comparison via `compare_hlo.py` (verified)

Generated by running both axes through the demo and diffing the
post-opt HLO with `python3 moe_block_demo/compare_hlo.py`:

| Metric | `embed` | `mlp` | Δ |
|---|---|---|---|
| HLO size (bytes) | 233 934 | 233 801 | −133 |
| `all-gather` ops | 3 | 3 | 0 |
| Multi-tensor AGs (wi_0+wi_1+wo fused) | 1 | 1 | 0 |
| Single-tensor AGs (group_sizes, logits_2d aux) | 2 | 2 | 0 |
| `ragged-all-to-all` ops | 3 | 3 | 0 |
| `all-reduce` ops | 3 | 3 | 0 |
| `reduce-scatter` ops | 1 | 1 | 0 |
| `collective-permute` ops | 0 | 0 | 0 |
| `all-to-all` ops | 2 | 2 | 0 |
| Total `transpose` ops (inline + fused) | 7 | 7 | 0 |
| `%fused_transpose*` computations | 4 | 4 | 0 |

**The collective and transpose op counts are byte-for-byte identical
between the two conventions** — including the multi-tensor AG fusion
of `wi_0+wi_1+wo`. The HLO differs by 133 bytes total, all in
shape literals and replica-group descriptors.

This **refutes the prior draft's hypothesis** that `embed` would have
fewer transposes / better AG fusion than `mlp` at the count level.

### Where the difference actually lives: transpose permutation pattern

The only systematic difference is in the *kind* of permutation each
side performs after the AG. The `wi_*` post-AG fix-up is in
`%fused_transpose.1` / `%fused_transpose.2`:

```
embed (wi_*, lines 914-918 of fsdp_embed HLO):
  AG out (16, 32, 128){2,1,0}                # (fsdp*E_local, H/fsdp, I)
  -> bitcast (2, 8, 32, 128){3,2,1,0}        # (fsdp, E_local, H/fsdp, I)
  -> transpose dimensions={1,0,2,3}
  -> (8, 2, 32, 128){3,2,1,0}                # (E_local, fsdp, H/fsdp, I)
  -> reshape/bitcast (8, 64, 128)            # (E_local, H, I)

  Permutation kind: swap leading 2 dims. fsdp moves past 1 other
  dim (E_local). Contiguous read run = I = 128 elements.

mlp (wi_*, lines 914-918 of fsdp_mlp HLO):
  AG out (16, 64, 64){2,1,0}                 # (fsdp*E_local, H, I/fsdp)
  -> bitcast (2, 8, 64, 64){3,2,1,0}         # (fsdp, E_local, H, I/fsdp)
  -> transpose dimensions={1,2,0,3}
  -> (8, 64, 2, 64){3,2,1,0}                 # (E_local, H, fsdp, I/fsdp)
  -> reshape/bitcast (8, 64, 128)            # (E_local, H, I)

  Permutation kind: 2-position rotation. fsdp moves past 2 other
  dims (E_local, H). Contiguous read run = I/fsdp = 64 elements
  (HALF as big as embed).
```

The `wo` post-AG fix-up shows the **opposite** asymmetry — `embed`
pays the deeper permutation here. And there is a *third* differing
transpose in the bwd path (most likely the `dW` layout fix-up for
the `wo` GEMM) that mirrors the fwd `wo` asymmetry:

| Op | `embed` permutation | `mlp` permutation |
|---|---|---|
| `wi_*` post-AG fix-up (4D, fwd) | `{1,0,2,3}` — fsdp past 1 dim | `{1,2,0,3}` — fsdp past 2 dims |
| `wo` post-AG fix-up (3D, fwd)   | `{1,2,0}` — 2-pos rotation (deep) | `{1,0,2}` — simple swap (shallow) |
| Extra 3D transpose (bwd)        | `{2,0,1}` — 2-pos rotation (deep) | `{1,0,2}` — simple swap (shallow) |

(See `output/exp2_diff.txt` "Transpose permutations" section for the
raw enumeration. The other transposes — `{1,0}` x2 and `{0,2,1}` x1
— are identical in both conventions and cancel out.)

So while the *forward* subset looks symmetric (`wi_*` deep on mlp,
`wo` deep on embed), once the bwd transpose is included **both 3D
transposes go to embed's "deep" pile and both 4D transposes go to
mlp's "deep" pile**. That symmetry-breaking is what drives the
empirical delta in §4 "Empirical resolution" — see the dim-count
argument there for why a 2-position rotation in 3D is materially
more expensive than the same rotation in 4D for the same total
tensor volume.

### What this means for cost

The cost difference lives at the **memory-bandwidth /
cache-locality level inside the transpose kernel** — invisible to
HLO counting if you stop at op counts, but predictable from the
permutation patterns themselves. Two factors matter:

1. **Contiguous-run length** (the original §4 argument): `mlp`'s
   `wi_*` transpose has half the contiguous read run that `embed`'s
   does (`I/fsdp` vs `I`); `embed`'s `wo` transpose has the
   symmetric problem (`H/fsdp` vs `H`). In demo dims the read
   runs are 32 vs 128 and 64 vs 128; at realistic dims (`H=4096,
   I=16384, fsdp=8`) the reduction widens to 8× on the offending
   kernel. Taken alone, this factor is symmetric across the two
   conventions.

2. **Dim-count of the rotation** (the missing factor that resolves
   the empirical delta): a 2-position rotation in a 3D tensor
   touches more bytes per stride step than the same rotation in 4D
   for equal total volume, because the gathered axis has fewer
   sibling dims to amortize against in the GPU transpose kernel's
   shared-memory tile. Once the bwd transpose is included (see the
   table above), embed pays the deep cost twice in 3D and mlp pays
   it twice in 4D — and 3D-deep is more expensive than 4D-deep.
   This factor is **not** symmetric and is what drives mlp's
   empirical 7.3% win.

Whether this materializes as a measurable wall-time delta is still
ultimately an **xprof** question — see "Empirical resolution"
below for the answer.

### Static size table (what HLO does and does not vary)

For the demo dims (`E_local=8`, `H/fsdp=32`, `I/fsdp=64`, bf16):

| What | `embed` (shards `H`) | `mlp` (shards `I`) | Delta |
|---|---|---|---|
| Per-shard weight memory | `E_local·H·I/fsdp` | same | 0 |
| FWD AG wire bytes per weight | `(fsdp-1)/fsdp · per_shard` | same | 0 |
| FWD multi-tensor AG fusion | yes (1 AG for wi_0+wi_1+wo) | yes (1 AG for wi_0+wi_1+wo) | 0 |
| Post-AG bitcast + transpose (fwd + bwd) | shallow on `wi_*` (2× 4D), **deep on both 3D** (`wo` fwd + bwd) | **deep on `wi_*` (2× 4D)**, shallow on both 3D | asymmetric → mlp ↓ |
| Total transpose op count | 7 | 7 | 0 |
| BWD partial dW size (full, before reduction) | `E_local·H·I` | same | 0 |
| BWD reduction wire bytes (Exp 3) | `(fsdp-1)/fsdp · per_partial` | same | 0 |
| TP-style alternative possible | hard (sharded on contracting dim) | natural (column-parallel up-proj, row-parallel down-proj) | ✅ `mlp` |

**Key takeaways (HLO level)**:
- Collective op counts and transpose op counts are **identical**.
  The "embed avoids `loop_transpose_fusion` overhead" claim, in its
  count-based form, is **not supported by HLO evidence** at these
  dims.
- The two conventions are **not** symmetric at the transpose-pattern
  level once the bwd path is included: 4 of 7 transposes differ,
  and embed gets the "deep" cost on both 3D transposes while mlp
  gets it on both 4D transposes (see the per-permutation table
  above and `output/exp2_diff.txt`). A previous draft considered
  only the 3 fwd post-AG fix-ups and concluded "symmetric" — that
  was an incomplete enumeration.
- A 2-position rotation in 3D is materially more expensive than
  the same rotation in 4D for the same total tensor volume,
  because there are fewer sibling dims to amortize the strided
  access in the GPU transpose kernel's shared-memory tile loop.
  This predicts mlp wins overall, which is exactly what the
  variance sweep below confirms (-7.3% on `TRANSPOSE_FAMILY`).

### Empirical resolution via xprof variance sweep (CONCLUSIVE)

Ran `bash moe_block_demo/run_variance.sh` (`N=5` per axis,
embed-then-mlp ordering) at the dsv3_mini realistic preset
(`B=8, S=4096, H=2048, I=2048, E=64, K=8, ep=2, fsdp=2, bf16`).
Aggregated with `compare_variance.py`:

| metric | embed (5 runs) | mlp (5 runs) | delta | sigmas |
|---|---|---|---|---|
| `NCCL_TOTAL` | 74.06 ms +- 1.31 ms | 73.33 ms +- 1.74 ms | -730 us | -0.75 |
| `RAGGED_A2A` | 3.483 s +- 1.27 ms | 3.482 s +- 1.37 ms | -1.01 ms | -1.21 |
| `TRANSPOSE_FAMILY` | 7.43 ms +- 6.09 us | 6.88 ms +- 21.55 us | **-544 us (-7.3%)** | **-54.36** |
| `TOTAL` | 3.862 s +- 1.66 ms | 3.860 s +- 2.43 ms | -1.67 ms | -1.27 |

`sigmas = delta / sqrt(s_l^2/n_l + s_r^2/n_r)`. `|sigmas| < 1` means
delta is dominated by within-axis noise; `|sigmas| > 2` means real.

**Reading the table**:
- `NCCL_TOTAL`, `RAGGED_A2A`, `TOTAL`: cross-axis delta is below 1.3
  sigma -- indistinguishable from run-to-run noise. As expected:
  these collectives don't depend on which weight-axis maps to fsdp.
- `TRANSPOSE_FAMILY`: -7.3% with **54 sigmas** of separation. The
  signal is overwhelming. Within-axis stddev is ~6 us (embed) and
  ~22 us (mlp); the cross-axis delta is 25x larger than even the
  bigger of the two stddevs.

**Conclusion (revised, replaces the previous "recommended default
remains embed")**: at dsv3_mini realistic dims, `mlp` is
**reproducibly faster than `embed` by 7.3% on transpose-family
GPU-stream wall time**. The toy-dim HLO analysis hypothesis ("embed
permutation is shallower so should be cheaper") was **falsified** by
this measurement, but the mechanism is now understood — see below.

**Why mlp wins (resolution of the previous open question)**:
The previous draft of §4 enumerated only the 3 forward post-AG
fix-ups (2× `wi_*` + 1× `wo`) and concluded the two conventions were
symmetric ("each pays one shallow + one deep"). That enumeration was
incomplete. `output/exp2_diff.txt` shows there are actually **4
differing transpose ops**, not 3 — embed has an extra `{2,0,1}`
3D rotation in the bwd path where mlp has an extra `{1,0,2}`
shallow swap. Counting all four:

- **embed**: 2× shallow-4D (`{1,0,2,3}`, fsdp past 1 dim) + 1× deep-3D
  (`{1,2,0}`, fwd `wo`) + 1× deep-3D (`{2,0,1}`, bwd)
- **mlp**: 2× deep-4D (`{1,2,0,3}`, fsdp past 2 dims) + 2× shallow-3D
  (`{1,0,2}`, fwd `wo` + bwd)

So mlp pays its "deep" cost only on the 4D transposes — where the
gathered axis has 3 sibling dims to amortize the strided access —
and pays the cheap shallow cost on **both** 3D transposes. embed
does the opposite: it gets the cheap 4D pass twice, but pays the
deep cost twice in 3D where the shared-memory transpose kernel has
fewer dims to absorb the rotation, making each step "wider" and
giving the tile loop less reuse. That single dimensional asymmetry
(4D-deep is cheaper than 3D-deep at equal total volume) explains
the entire 7.3% delta. (Hypothesis (b) from a previous draft —
"cuBLASLt prologue absorbs the deeper permutation when fsdp is on
the contracting dim" — was also wrong: for `wi_*` the contracting
dim is `H`, which is what *embed* shards, not mlp. The mechanism is
purely in the standalone transpose kernel, not in cuBLASLt.)

**However**: 544 us out of a 3.86 s iter total is 0.014% of total
wall time. The transpose savings are **statistically certain but
economically negligible** at this scale because A2Av's
`RaggedAllToAllKernelImpl` (3.5 s) dominates everything. The mlp
default is the right choice but the magnitude of its win is bounded
by the transpose-family share of the iter.

### Open question: how does the win scale?

The transpose-family cost scales `O(E_local * H * I)` per fwd pass
(`O(2 * E_local * H * I)` per training step counting bwd recompute).
RAA scales differently. At larger E (256+) and the moments where
ring-of-experts becomes infeasible, the transpose savings will
become a larger fraction of iter time. To know how much, run:

```
DEMO_NUM_EXPERTS=256 DEMO_HIDDEN_SIZE=7168 \
  bash moe_block_demo/run_realistic.sh
N=5 ORDER=interleave bash moe_block_demo/run_variance.sh
```

Recommended default for `MoEBlock`: **`mlp`** for the
`FSDP_LOGICAL_AXIS` convention (when one is needed -- this only
matters if the user wires `fsdp` explicitly into the logical-axis
rules table; the new Experiment-3 default activates fsdp on the
batch axis, which sidesteps this entirely for activations).

### Asymptotic trends with realistic dims

For `H≈4096, I≈4·H≈16384, E≈64, fsdp≈8`:
- AG bytes per weight per fwd ≈ 917 MB. **× 3** for `wi_0+wi_1+wo`.
- Post-AG transpose cost scales with `E_local · H · I / fsdp` per
  call. Both conventions move the same total bytes; only the
  contiguous-run granularity differs (`I` vs `I/fsdp` for `wi_*` in
  embed-vs-mlp respectively, and the symmetric `H` vs `H/fsdp` for
  `wo`). At `fsdp=8`, the offending kernel's contiguous run shrinks
  to ⅛ of the matched kernel's.

---

## 5. The activation-replication caveat (important)

The current `MoEBlock` uses `shard_map(in_specs=P('ep', None, None))`
for the FFN body. With mesh `('ep','fsdp')` and `'ep'` sharding the
batch dim, the `'fsdp'` axis is `None` ⇒ **activations are replicated
across fsdp peers within an ep group**.

So the FFN compute is:

- params: sharded on `fsdp` ✓
- params: AG'd on fsdp before GEMM ✓
- activations: **replicated** on fsdp ❌ (no DP over fsdp)
- bwd weight grads: identical across fsdp peers (no reduction needed
  over fsdp); only reduced over `ep` for the partial-on-`E` direction
  not covered by ep param-sharding

This is **ZeRO-1 for the FFN** (params sharded for memory), not true
FSDP. Two fsdp peers within an ep group do **redundant compute** on
the same `B/ep` tokens.

True FSDP would require `in_specs=P(('ep','fsdp'), None, None)` so
the batch is sharded over BOTH axes simultaneously. Each device
would then own `B/(ep*fsdp)` unique tokens, FFN compute would be
`ep*fsdp`-way parallel, and bwd would need a real fsdp-axis weight
grad reduction (RS or AR).

➡ This is **Experiment 3** in §6.

---

## 6. Open follow-up experiments

Capturing the experiments the MoEBlock was designed to enable, with
priority and current status:

### Experiment 1 — Quantize before FSDP all-gather *(planned)*

**Today**: `grouped_dense` AGs bf16 weights along fsdp, then
quantizes the *full* gathered tensor to FP8 on every device.
Wasteful: AG bandwidth = bf16 (2× FP8); quantization time × num_fsdp.

**Goal**: quantize each shard's 1/num_fsdp slice locally, then AG the
FP8 tensor + scales.

**Wins**: AG bandwidth ÷ 2 (FP8 vs bf16); weight-quant time ÷
num_fsdp.

**Mechanism**: `dense` already accepts
`kernel_fsdp_info=(mesh_axis_name, dim_index)`. `grouped_dense`
currently rejects non-default values. Need to thread
`kernel_fsdp_info` through `grouped_dense` and the GroupedGemm
custom partitioning, do the quantize on the local shard, then AG the
ScaledTensor (data + scales) using `flatten_axis` consistent with
the kernel layout.

**Knob to add**: `quantize_before_fsdp_ag: bool` on `MoEBlock`
(default `False` to preserve current behavior).

**Files of interest**:
- `transformer_engine/jax/dense.py` — existing `kernel_fsdp_info`
  plumbing.
- `transformer_engine/jax/flax/moe.py` — `_expert_ffn`'s 3
  `grouped_dense` call sites.

### Experiment 2 — Eliminate `loop_transpose_fusion` via layout/FSDP-axis sweep *(EMPIRICALLY DONE; mlp wins by 7.3% on transpose time, dwarfed by RAA at dsv3_mini)*

**Result**: `FSDP_LOGICAL_AXIS={embed,mlp}` is wired through the
demo (`run_demo.py`) and verified via HLO + xprof variance sweep.
At the dsv3_mini realistic preset, `mlp` is reproducibly faster
than `embed` by 544 us (7.3%) on transpose-family GPU-stream wall
time, with 54 sigmas of statistical separation across N=5 runs per
axis (see §4 "Empirical resolution"). At realistic dims this is
0.014% of total iter time because RAA dominates; the recommended
default is `mlp` but the magnitude is bandwidth-bound.

**Original goal not met (zero-transpose layout)**: HLO inspection
shows the transpose count is identical for both conventions (7
inline + 4 fused on each side). XLA always all-gathers along
dim-0 of each per-shard kernel and bitcasts+transposes into the
`(E_local, H, I)` row-major layout cuBLASLt requires. The two
conventions just *permute differently* (which dim has to travel
past how many others). Achieving an actual zero-transpose layout
would require either (a) presenting the per-shard kernel to the
all-gather already in `(E_local, H, I)` order with the gathered
axis as dim-0 *and* in the right place after gather (impossible
because dim-0 is what the AG concatenates) or (b) changing the
custom-partitioning rules on `GroupedGemmPrimitive` to express the
gathered+transposed layout as a single fused custom call so XLA
elides the transpose. The latter is structurally possible but
substantially deeper than the original "swap the layout knob"
plan and is not currently scheduled.

**What's still left for users**: `MoEBlock` already exposes
`wi_kernel_axes` / `wo_kernel_axes` for layout control; the demo's
`FSDP_LOGICAL_AXIS` env var documents the recommended axis
convention. No further `MoEBlock` changes needed unless we pursue
the fused-AG-transpose custom call route.

### Experiment 3 — True FSDP via batch-sharded activations *(LANDED — promoted to official design, now the demo default)*

**Today**: `shard_map(in_specs=P('ep', None, None))` ⇒ activations
replicated across fsdp peers within an ep group ⇒ ZeRO-1, not FSDP
(see §5).

**What Maxtext does** (training default, validated by reading
`maxtext/src/maxtext/layers/moe.py:1401-1462` and
`maxtext/src/maxtext/configs/base.yml:432-433`):

```yaml
['activation_batch', ['data', 'fsdp', 'fsdp_transpose', 'expert']],
['activation_batch_no_exp', ['data', 'fsdp', 'fsdp_transpose']],
```

So Maxtext's `input_partition_pspec` is
`P(('data','fsdp','fsdp_transpose','expert'), 'activation_norm_length', None)`
— batch sharded over **all** of `(data, fsdp, fsdp_transpose, expert)`
simultaneously. The `shard_map`'s `in_specs` matches, so:
- No entry/exit reshard (no `collective-permute`).
- Activations are batch-sharded over fsdp ⇒ no redundant compute.
- FFN is `data*fsdp*fsdp_transpose*expert`-way data parallel.

There's a runtime fallback at `moe.py:1401-1417` to
`activation_batch_no_exp` when `expert` isn't in the `activation_batch`
rule (e.g. some inference configs) or when `inputs.shape[0]==1`.

**LANDED**: `MoEBlock` now exposes a `data_parallelism_axes:
Tuple[str, ...] = ()` field. Setting it to e.g. `("fsdp",)` makes
the shard_map's `in_specs`/`out_specs` for the batch dim become
`P(("ep","fsdp"), None, None)`. Inside the body, `axis_index("ep")`
is unchanged (EP routing still uses ep only); the fsdp peers within
an ep group own different batch slices and route in lockstep. The
aux-loss `all_gather` automatically gathers over `("ep","fsdp")` to
see the global token batch; `recv_buffer_rows` is automatically
tightened from `B*S*K` to `B/dp_size*S*K`. The demo
(`moe_block_demo/run_demo.py`) and the distributed test
(`tests/jax/test_distributed_moe_block.py`) both opt in to
`data_parallelism_axes=("fsdp",)` as their official baseline.

**Side-by-side**:

| | Maxtext default | TE `MoEBlock` (Exp 3 landed) | TE `MoEBlock` (legacy: `data_parallelism_axes=()`) |
|---|---|---|---|
| `in_specs` | `P(('data','fsdp','fsdp_transpose','expert'), seq, None)` | `P(('ep','fsdp'), None, None)` | `P('ep', None, None)` |
| Reshard at entry? | No | No | Yes (`collective-permute` for `P('fsdp')→P('ep')`) |
| Activations sharded on fsdp? | Yes | Yes | No (replicated within ep group) |
| FFN DP degree | `data * fsdp * fsdp_transpose * expert` | `ep * fsdp` | `ep` |

**What changed in the bwd HLO (vs legacy)**:
- The fused `bf16[197632]` mega-AR over `ep` (which combined dwi_*+dwo+dgate)
  splits into:
  * a real reduce-scatter over `fsdp` for `dwi_*` and `dwo` (because
    activations now genuinely differ across fsdp peers), AND
  * a smaller AR over `(ep, fsdp)` for `dgate_kernel` (still
    replicated parameter).
- The fwd `collective-permute` for `P('fsdp')→P('ep')` reshard
  disappears entirely.
- Loss-scalar AR widens from `(ep)` to `(ep, fsdp)`.
- Aux-loss path's fwd AG widens from `(ep)` to `(ep, fsdp)`; its
  bwd RS likewise widens.

XLA may still fuse the four FFN bwd RS-over-fsdp ops into a single
multi-tensor RS; that's an empirical question for the next HLO
review.

### Follow-up: relax `gemm.cpp:1029`

Currently `tests/jax/test_moe_block.py::test_align_size_equivalence_pure_jax`
is `xfail` because `pure_jax` permutation with `align_size > 0`
produces `m > sum(group_sizes)` and `gemm.cpp:1029` asserts equality.

**Decision**: relax that assertion from `m == sum(group_sizes)` to
`m >= sum(group_sizes)`. The grouped GEMM kernel itself only reads
exactly `sum(group_sizes)` rows — extra trailing rows in the input
buffer are ignored (and the corresponding output rows are
unspecified, which is fine since the caller doesn't read them).

Once relaxed, `pure_jax + align_size > 0` becomes a first-class
configuration and the xfail can be removed.

---

## 7. Snapshot of the current refactor

What landed in this session:

- `transformer_engine/jax/flax/moe.py`: ring-of-experts EP path
  removed; `_forward_a2a_ep` is now the only EP path. `_global_permute
  / _expert_ffn / _global_combine` factored apart.
- `transformer_engine/jax/permutation.py`: A2A param helpers
  (`compute_ragged_all_to_all_params`,
  `compute_reverse_ragged_all_to_all_params`,
  `local_permute_after_a2a`, `local_unpermute_before_a2a`). Pure-JAX
  local permute path removed; only the Triton
  `sort_chunks_by_index`-based path remains.
- `tests/jax/test_distributed_moe_block.py`: switched to the
  canonical Flax-Linen `eval_shape → get_partition_spec →
  logical_to_mesh_sharding → jit(init, out_shardings=...)` pattern
  for true on-device sharded init.
- `tests/jax/test_moe_block.py`: `test_align_size_equivalence_pure_jax`
  xfail reason updated to recommend the C++ relax above.
- `moe_block_demo/`: standalone runner producing HLO dumps, xprof,
  and the SVG dataflow diagram for both FSDP conventions.

Pending validation:

- Run `test_moe_block` and `test_distributed_moe_block` on a 4-GPU
  box and report deltas.
- Profile the demo with realistic dims (B=512, H=4096, I=14336, E=64,
  K=8) once the box is available.

---

## 8. Why our iter time is so different from Maxtext profiles

The dsv3_mini realistic preset measures **3.86 s per iter** on
4 GPUs (`compare_variance.py` aggregate). Maxtext's
`xprof_profiles_deepseek_4gpu_OLD_GOOD/` profiles are dramatically
shorter at comparable model dims. The discrepancy is structural,
not a bug in our measurement:

1. **EP strategy: A2Av vs Ring-of-Experts (single biggest factor)**.
   Maxtext's profiled config (`use_ring_of_experts=true`)
   pipelines `num_ep` rounds of `(roll, GEMM, accumulate)` using
   NCCL `collective_permute` between rounds. NCCL ring kernels are
   pure async streaming.
   Our `MoEBlock` uses `jax.lax.ragged_all_to_all`, which today
   lowers to XLA's reference `RaggedAllToAllKernelImpl` -- a
   pure-CUDA implementation that **busy-waits on per-peer
   per-expert offsets**. At our config it eats ~3.5 s of the 3.86 s
   total. Replacing this lowering with a NCCL-backed A2Av
   (whenever JAX/XLA ships it, or via a TE primitive) is the single
   highest-leverage perf change available.

2. **FP8 vs BF16**. Maxtext profiles run with FP8 quantized
   matmuls; we run BF16. cuBLASLt FP8 GEMMs are ~2x faster on
   compute-bound shapes.

3. **Python loop dispatch overhead**. `_expert_ffn` calls
   `grouped_dense` 3 times in Python; Maxtext's GMM dispatch is a
   single fused TE call.

4. **Different B/S ratios**. Our dsv3_mini uses B=8/S=4096 to keep
   per-GPU memory tractable on the 4-GPU box; Maxtext profiles use
   different mixes that change the M-dim of the GEMMs.

The fact that **`TRANSPOSE_FAMILY` is 0.014% of total iter time at
dsv3_mini** is therefore *artificially small* relative to what it
would be with a NCCL-backed A2Av. Once RAA is replaced, the
embed-vs-mlp choice (and the Experiment-1 quantize-before-AG win)
become much larger fractions of the iter.

For these reasons, **do not compare absolute iter times against
Maxtext profiles**. Compare deltas within the same demo
configuration.
