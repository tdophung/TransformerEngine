#!/usr/bin/env bash
# Launch one xprof viewer per xprof trace dir produced by the MoEBlock
# demo, each on its own port. Auto-discovers all
# ``output/[<run_name>/]fsdp_<axis>/xprof/`` dirs and assigns ports in
# chronological order of their inner profile-capture timestamps so that
# repeated runs land on stable port numbers.
#
# Usage:
#   bash moe_block_demo/start_xprof.sh
#       Auto-discover every xprof dir under output/, one per port.
#
#   bash moe_block_demo/start_xprof.sh fsdp_embed fsdp_mlp
#       Toy demo only (matches dirs under output/fsdp_*).
#
#   bash moe_block_demo/start_xprof.sh dsv3_mini/fsdp_embed dsv3_mini/fsdp_mlp
#       Realistic preset only.
#
#   BASE_PORT=9000 bash moe_block_demo/start_xprof.sh
#       Override starting port (default 8796).
#
#   PROFILE_DIR=/path/to/output bash moe_block_demo/start_xprof.sh
#       Override which output root to scan.
#
# After starting, the script prints an SSH tunnel command to forward
# every assigned port to your local machine in one shot.
#
# Press Ctrl+C to stop all viewers (the script `wait`s on them).

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE_DIR="${PROFILE_DIR:-${SCRIPT_DIR}/output}"
BASE_PORT="${BASE_PORT:-8796}"
SSH_HOST="${SSH_HOST:-prenyx}"

# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

# Earliest profile timestamp inside an xprof dir. JAX's profiler writes
# each capture to ``<xprof>/plugins/profile/<YYYY_MM_DD_HH_MM_SS>/``,
# so sorting these lexicographically sorts chronologically.
_profile_timestamp() {
    ls -1 "$1/plugins/profile/" 2>/dev/null | sort | head -1
}

# Render a relative label like "dsv3_mini/fsdp_embed" or "fsdp_embed"
# for a given xprof dir.
_label_for() {
    local d="$1"
    # Strip the trailing "/xprof/" and the PROFILE_DIR prefix.
    local rel="${d%/xprof/}"
    rel="${rel#${PROFILE_DIR}/}"
    echo "${rel}"
}

# ---------------------------------------------------------------------
# Discover candidate xprof dirs
# ---------------------------------------------------------------------

declare -a candidates
if [[ $# -gt 0 ]]; then
    for arg in "$@"; do
        # Accept both ``fsdp_embed`` and ``fsdp_embed/`` and
        # ``dsv3_mini/fsdp_embed``.
        d="${PROFILE_DIR}/${arg%/}/xprof/"
        if [[ -d "$d" ]]; then
            candidates+=("$d")
        else
            echo "WARNING: ${d} not found, skipping." >&2
        fi
    done
else
    # Glob both the toy layout (output/fsdp_*/xprof) and the prefixed
    # layout (output/<run>/fsdp_*/xprof).
    while IFS= read -r d; do
        candidates+=("$d")
    done < <(find "$PROFILE_DIR" -mindepth 2 -maxdepth 4 -type d -name xprof 2>/dev/null)
fi

if [[ ${#candidates[@]} -eq 0 ]]; then
    echo "No xprof dirs found under ${PROFILE_DIR}/" >&2
    echo "Run ``bash moe_block_demo/run.sh`` (toy) or" >&2
    echo "    ``bash moe_block_demo/run_realistic.sh`` (realistic)" >&2
    echo "first to produce traces." >&2
    exit 1
fi

# Sort by inner profile timestamp so repeated runs get stable ports.
declare -a dirs
while IFS= read -r line; do
    dirs+=("${line#* }")
done < <(
    for d in "${candidates[@]}"; do
        ts=$(_profile_timestamp "$d")
        echo "${ts:-zzz} ${d}"
    done | sort
)

MAX_PORT=$(( BASE_PORT + ${#dirs[@]} - 1 ))

# ---------------------------------------------------------------------
# Cleanup any prior xprof on the ports we are about to use
# ---------------------------------------------------------------------
echo "Cleaning up any existing xprof / tensorboard processes on ports ${BASE_PORT}..${MAX_PORT}"
for p in $(seq "$BASE_PORT" "$MAX_PORT"); do
    # Try fuser first (POSIX), fall back to lsof.
    if command -v fuser >/dev/null 2>&1; then
        fuser -k "${p}/tcp" 2>/dev/null || true
    elif command -v lsof >/dev/null 2>&1; then
        for pid in $(lsof -ti tcp:"${p}" 2>/dev/null); do
            kill -9 "$pid" 2>/dev/null || true
        done
    fi
done
# Also kill any lingering xprof processes started by us.
pkill -9 -f "xprof --port" 2>/dev/null || true
sleep 0.5

# ---------------------------------------------------------------------
# Launch
# ---------------------------------------------------------------------
if ! command -v xprof >/dev/null 2>&1; then
    echo "ERROR: 'xprof' not on PATH. Install with ``pip install xprof``." >&2
    exit 2
fi

echo
echo "Starting xprof servers..."
echo
port=${BASE_PORT}
for d in "${dirs[@]}"; do
    label="$(_label_for "$d")"
    printf "  %-32s ->  http://localhost:%d/\n" "${label}" "${port}"
    xprof --port "${port}" "$d" >/dev/null 2>&1 &
    port=$((port + 1))
done

echo
echo "SSH tunnel (copy-paste to your local machine):"
tunnel_args=""
port=${BASE_PORT}
for _ in "${dirs[@]}"; do
    tunnel_args+=" -L ${port}:localhost:${port}"
    port=$((port + 1))
done
echo "  ssh${tunnel_args} ${SSH_HOST}"
echo
echo "Then open the URLs above in your browser. In each viewer, go to"
echo "  Tools > trace_viewer (or 'Profile' for kernel-level breakdowns)."
echo
echo "Press Ctrl+C to stop all xprof servers."
wait
