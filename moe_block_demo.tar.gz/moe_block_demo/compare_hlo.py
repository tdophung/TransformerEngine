"""Side-by-side HLO diff between two ``moe_block_demo`` runs.

Reads the post-optimization HLO under
``output/fsdp_<axis>/hlo/module_*after_optimizations.txt`` for two axes and
prints a tabular comparison of:

  * collective op counts (all-gather, ragged-all-to-all, all-reduce,
    reduce-scatter, collective-permute, all-to-all);
  * each ``all-gather-start`` op's operand count and replica_groups
    (so you can see if XLA fused ``wi_0 + wi_1 + wo`` into one
    multi-tensor AG or kept them split);
  * every transpose permutation that appears anywhere in the module
    (inline or inside a ``%fused_transpose`` computation), tallied by
    permutation pattern;
  * the number of distinct ``%fused_transpose*`` HloComputations.

Usage:

    # Default: compare ``embed`` (left) vs ``mlp`` (right). Assumes both
    # runs already exist under ``moe_block_demo/output/``.
    python3 moe_block_demo/compare_hlo.py

    # Custom axes / labels.
    python3 moe_block_demo/compare_hlo.py --left embed --right mlp

    # Pin to a specific HLO file (useful when there are multiple
    # post-opt dumps for different jits in the same run dir).
    python3 moe_block_demo/compare_hlo.py \\
        --left-file output/fsdp_embed/hlo/module_4634.jit_fwd_and_grad.sm_10.0a_gpu_after_optimizations.txt \\
        --right-file output/fsdp_mlp/hlo/module_4634.jit_fwd_and_grad.sm_10.0a_gpu_after_optimizations.txt

Pure stdlib; no extra deps.
"""

from __future__ import annotations

import argparse
import re
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

DEMO_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = DEMO_DIR / "output"

# Match an HLO instruction line: ``  %lhs = T[...] op(args)...`` or
# ``  ROOT %lhs = ...`` (ROOT-prefixed instructions live inside
# computations like %fused_transpose). Captures the op name. Skips
# comments, blank lines, and computation headers.
HLO_INSTR_RE = re.compile(r"^\s*(?:ROOT\s+)?%[^\s=]+\s*=\s*.*?\s+([\w-]+)\(")

# transpose(...), dimensions={X,Y,Z,...}. Allow nested () inside the
# transpose argument list (rare but possible for fusion arguments).
TRANSPOSE_RE = re.compile(r"\btranspose\s*\([^)]*\),\s*dimensions=\{([^}]+)\}")

# dimensions={N} on the all-gather op itself.
AG_DIM_RE = re.compile(r"\bdimensions=\{(\d+)\}")

# ``%fused_transpose`` and ``%fused_transpose.<n>`` computation headers.
FUSED_TRANSPOSE_RE = re.compile(r"^%fused_transpose[\.\d]*\s*\(", re.MULTILINE)

# Collective ops we care about. We split into "logical instances"
# (``-start`` for async, no-suffix for sync) and ignore ``-done``.
LOGICAL_COLLECTIVES = {
    "all-gather": ["all-gather-start", "all-gather"],
    "ragged-all-to-all": ["ragged-all-to-all-start", "ragged-all-to-all"],
    "all-reduce": ["all-reduce-start", "all-reduce"],
    "reduce-scatter": ["reduce-scatter-start", "reduce-scatter"],
    "collective-permute": ["collective-permute-start", "collective-permute"],
    "all-to-all": ["all-to-all-start", "all-to-all"],
}

DONE_OPS = {
    "all-gather-done",
    "ragged-all-to-all-done",
    "all-reduce-done",
    "reduce-scatter-done",
    "collective-permute-done",
    "all-to-all-done",
}


@dataclass
class HloSummary:
    path: Path
    size_bytes: int
    n_lines: int
    op_counts: Counter  # raw op name -> count
    ag_details: List[Tuple[int, Optional[int], str]]  # (operand_count, dim, replica_groups)
    transpose_perms: List[str]
    n_fused_transpose_computations: int

    def logical_count(self, family: str) -> int:
        return sum(self.op_counts.get(op, 0) for op in LOGICAL_COLLECTIVES[family])


# ---------------------------------------------------------------------------
# parsing
# ---------------------------------------------------------------------------


def _split_top_level(s: str) -> List[str]:
    """Split a comma-separated argument list at depth-0 commas.

    Handles nested ``(...)``, ``[...]``, ``{...}``.
    """
    out: List[str] = []
    depth = 0
    start = 0
    for i, ch in enumerate(s):
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            depth -= 1
        elif ch == "," and depth == 0:
            out.append(s[start:i])
            start = i + 1
    tail = s[start:]
    if tail.strip():
        out.append(tail)
    return out


def _extract_replica_groups(line: str) -> Optional[str]:
    """Capture the ``replica_groups=...`` value from an HLO line.

    Handles two formats:
      * ``replica_groups={{0,2},{1,3}}``                 (list-of-lists)
      * ``replica_groups=mesh['axis_0'=2,...] {'axis_1'}`` (mesh spec)
    Walks brace/bracket depth and stops at the next top-level comma.
    """
    key = "replica_groups="
    idx = line.find(key)
    if idx < 0:
        return None
    start = idx + len(key)
    depth_brace = 0
    depth_bracket = 0
    end = len(line)
    for i in range(start, len(line)):
        ch = line[i]
        if ch == "{":
            depth_brace += 1
        elif ch == "}":
            depth_brace -= 1
        elif ch == "[":
            depth_bracket += 1
        elif ch == "]":
            depth_bracket -= 1
        elif ch == "," and depth_brace == 0 and depth_bracket == 0:
            end = i
            break
    return line[start:end].strip()


def _ag_operand_count(line: str) -> int:
    """Count operands inside the first ``(...)`` of an all-gather-start."""
    head = "all-gather-start("
    if head not in line:
        head = "all-gather("
        if head not in line:
            return 0
    rest = line.split(head, 1)[1]
    # find the matching close paren at depth 0
    depth = 0
    for i, ch in enumerate(rest):
        if ch == "(":
            depth += 1
        elif ch == ")":
            if depth == 0:
                args = rest[:i]
                break
            depth -= 1
    else:
        args = rest
    return len([a for a in _split_top_level(args) if a.strip()])


def parse_hlo(path: Path) -> HloSummary:
    text = path.read_text()
    lines = text.splitlines()

    op_counts: Counter = Counter()
    ag_details: List[Tuple[int, Optional[int], str]] = []
    transpose_perms: List[str] = []

    for line in lines:
        m = HLO_INSTR_RE.match(line)
        if not m:
            continue
        op = m.group(1)
        if op in DONE_OPS:
            continue
        op_counts[op] += 1

        if op in ("all-gather-start", "all-gather"):
            n = _ag_operand_count(line)
            dm = AG_DIM_RE.search(line)
            dim = int(dm.group(1)) if dm else None
            rg = _extract_replica_groups(line)
            ag_details.append((n, dim, rg if rg is not None else "?"))

        for tm in TRANSPOSE_RE.finditer(line):
            transpose_perms.append(tm.group(1).strip())

    # transposes inside %fused_transpose computations live on their own lines
    # and are already picked up by the per-line scan above. We additionally
    # count how many distinct fused_transpose computations exist.
    n_fused = len(FUSED_TRANSPOSE_RE.findall(text))

    return HloSummary(
        path=path,
        size_bytes=path.stat().st_size,
        n_lines=len(lines),
        op_counts=op_counts,
        ag_details=ag_details,
        transpose_perms=transpose_perms,
        n_fused_transpose_computations=n_fused,
    )


# ---------------------------------------------------------------------------
# file picking
# ---------------------------------------------------------------------------


def find_hlo_file(axis: str, run_name: str = "") -> Path:
    base = OUTPUT_DIR / run_name if run_name else OUTPUT_DIR
    hlo_dir = base / f"fsdp_{axis}" / "hlo"
    if not hlo_dir.is_dir():
        prefix_hint = f"DEMO_RUN_NAME={run_name} " if run_name else ""
        raise FileNotFoundError(
            f"No HLO dir at {hlo_dir}. Run "
            f"``{prefix_hint}FSDP_LOGICAL_AXIS={axis} bash {DEMO_DIR}/run.sh`` first."
        )

    # Prefer fwd_and_grad post-opt; fall back to any post-opt; finally
    # any module dump.
    patterns = [
        "module_*fwd_and_grad*after_optimizations.txt",
        "module_*after_optimizations.txt",
        "module_*.txt",
    ]
    for pat in patterns:
        cands = sorted(hlo_dir.glob(pat))
        if cands:
            return max(cands, key=lambda p: p.stat().st_size)
    raise FileNotFoundError(f"No HLO files under {hlo_dir}.")


# ---------------------------------------------------------------------------
# rendering
# ---------------------------------------------------------------------------


def _delta_str(left: int, right: int) -> str:
    d = right - left
    if d == 0:
        return "  ="
    return f"{d:+d}"


def render(left_label: str, left: HloSummary, right_label: str, right: HloSummary) -> str:
    out: List[str] = []
    out.append("=== HLO files ===")
    out.append(f"  {left_label:<8}: {left.path}")
    out.append(f"  {right_label:<8}: {right.path}")
    out.append(
        f"  {left_label:<8}: {left.size_bytes:>10} bytes, {left.n_lines:>6} lines"
    )
    out.append(
        f"  {right_label:<8}: {right.size_bytes:>10} bytes, {right.n_lines:>6} lines"
    )

    # 1) logical collective family counts
    out.append("")
    out.append("=== Logical collective counts (start+sync, ignoring -done) ===")
    out.append(
        f"  {'family':<22} {left_label:>8} {right_label:>8} {'delta':>8}"
    )
    out.append(f"  {'-'*22} {'-'*8} {'-'*8} {'-'*8}")
    for family in LOGICAL_COLLECTIVES:
        l = left.logical_count(family)
        r = right.logical_count(family)
        out.append(
            f"  {family:<22} {l:>8} {r:>8} {_delta_str(l, r):>8}"
        )

    # 2) raw op counts (only ops that appear in either side)
    out.append("")
    out.append("=== Raw op counts (collectives only, all variants) ===")
    out.append(
        f"  {'op':<26} {left_label:>8} {right_label:>8} {'delta':>8}"
    )
    out.append(f"  {'-'*26} {'-'*8} {'-'*8} {'-'*8}")
    raw_ops = set()
    for fam_ops in LOGICAL_COLLECTIVES.values():
        raw_ops.update(fam_ops)
    raw_ops |= DONE_OPS
    for op in sorted(raw_ops):
        l = left.op_counts.get(op, 0)
        r = right.op_counts.get(op, 0)
        if l == 0 and r == 0:
            continue
        out.append(
            f"  {op:<26} {l:>8} {r:>8} {_delta_str(l, r):>8}"
        )

    # 3) all-gather details
    out.append("")
    out.append("=== all-gather-start details (operand_count, gather_dim, replica_groups) ===")
    for label, data in [(left_label, left), (right_label, right)]:
        out.append(f"  {label}:")
        if not data.ag_details:
            out.append("    (none)")
            continue
        for i, (n, dim, rg) in enumerate(data.ag_details):
            tag = "MULTI" if n > 1 else "single"
            dim_s = f"dim={dim}" if dim is not None else "dim=?"
            out.append(
                f"    [{i}] {tag:<5} ({n} operand{'s' if n != 1 else ''}), {dim_s}, "
                f"replica_groups={rg}"
            )
        out.append(
            f"    -> {sum(1 for n, _, _ in data.ag_details if n > 1)} multi-tensor / "
            f"{sum(1 for n, _, _ in data.ag_details if n == 1)} single-tensor"
        )

    # 4) transpose permutation tally
    out.append("")
    out.append("=== Transpose permutations (all transposes anywhere in the module) ===")
    for label, data in [(left_label, left), (right_label, right)]:
        c = Counter(data.transpose_perms)
        total = sum(c.values())
        out.append(f"  {label} ({total} total transpose ops, "
                   f"{data.n_fused_transpose_computations} fused_transpose computations):")
        if not c:
            out.append("    (none)")
            continue
        for perm, n in c.most_common():
            out.append(f"    dimensions={{{perm}}}  x{n}")

    # 5) summary deltas in a one-line "did the experiment hypothesis hold?"
    out.append("")
    out.append("=== Hypothesis check (Experiment 2) ===")
    out.append(
        f"  Total transposes      : {left_label}={sum(1 for _ in left.transpose_perms):>3}  "
        f"{right_label}={sum(1 for _ in right.transpose_perms):>3}  "
        f"delta={_delta_str(len(left.transpose_perms), len(right.transpose_perms))}"
    )
    out.append(
        f"  fused_transpose comps : {left_label}={left.n_fused_transpose_computations:>3}  "
        f"{right_label}={right.n_fused_transpose_computations:>3}  "
        f"delta={_delta_str(left.n_fused_transpose_computations, right.n_fused_transpose_computations)}"
    )
    out.append(
        f"  multi-tensor AGs      : "
        f"{left_label}={sum(1 for n, _, _ in left.ag_details if n > 1):>3}  "
        f"{right_label}={sum(1 for n, _, _ in right.ag_details if n > 1):>3}"
    )
    out.append(
        f"  single-tensor AGs     : "
        f"{left_label}={sum(1 for n, _, _ in left.ag_details if n == 1):>3}  "
        f"{right_label}={sum(1 for n, _, _ in right.ag_details if n == 1):>3}"
    )
    return "\n".join(out)


# ---------------------------------------------------------------------------
# entrypoint
# ---------------------------------------------------------------------------


def main() -> None:
    p = argparse.ArgumentParser(
        description=__doc__.split("\n", 1)[0],
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--left", default="embed", help="left axis label (default: embed)")
    p.add_argument("--right", default="mlp", help="right axis label (default: mlp)")
    p.add_argument(
        "--run-name",
        default="",
        help="optional ``DEMO_RUN_NAME`` prefix subdir (e.g. ``dsv3_mini``) "
        "applied to BOTH sides. When empty (default), looks under "
        "``output/fsdp_<axis>/`` (the toy-demo path).",
    )
    p.add_argument(
        "--left-run-name",
        default=None,
        help="override --run-name for the left side only",
    )
    p.add_argument(
        "--right-run-name",
        default=None,
        help="override --run-name for the right side only",
    )
    p.add_argument(
        "--left-file",
        default=None,
        help="explicit path to left HLO file (overrides --left/--left-run-name auto-glob)",
    )
    p.add_argument(
        "--right-file",
        default=None,
        help="explicit path to right HLO file (overrides --right/--right-run-name auto-glob)",
    )
    p.add_argument(
        "--out",
        default=None,
        help="optional path to also write the report to (besides stdout)",
    )
    args = p.parse_args()

    left_run = args.left_run_name if args.left_run_name is not None else args.run_name
    right_run = args.right_run_name if args.right_run_name is not None else args.run_name
    left_path = (
        Path(args.left_file) if args.left_file else find_hlo_file(args.left, left_run)
    )
    right_path = (
        Path(args.right_file) if args.right_file else find_hlo_file(args.right, right_run)
    )

    left = parse_hlo(left_path)
    right = parse_hlo(right_path)
    report = render(args.left, left, args.right, right)
    print(report)
    if args.out:
        Path(args.out).write_text(report + "\n")


if __name__ == "__main__":
    main()
