#!/usr/bin/env bash
# Launch ``run_demo.py`` with HLO dumping enabled and the right Python
# path so it picks up the in-tree TransformerEngine build.
#
# Run from the repo root (or any cwd; paths below are absolute):
#
#     bash moe_block_demo/run.sh
#
# Outputs land under ``moe_block_demo/output/``:
#   * ``hlo/``               -- post-optimisation HLO dumps
#   * ``xprof/``             -- JAX profiler trace dir
#   * ``sharded_shapes.txt`` -- per-tensor shape + NamedSharding spec
#   * ``collective_summary.txt`` -- counts of all-gather / ragged-A2A /
#                                   all-reduce / reduce-scatter found
#                                   in the post-opt HLO

set -euo pipefail

DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Match run_demo.py's output layout so HLO dumps land where the script
# expects to scan them. ``DEMO_RUN_NAME`` (set by ``run_realistic.sh``
# or any other wrapper) inserts a prefix subdir; when unset (the toy
# demo case), paths are exactly what they used to be.
FSDP_AXIS_NAME="${FSDP_LOGICAL_AXIS:-mlp}"
RUN_NAME="${DEMO_RUN_NAME:-}"
# Mirror run_demo.py's path layout: bf16 keeps the legacy
# ``fsdp_<axis>/`` dir name (so existing helpers continue to work);
# non-bf16 recipes append ``_<tag>`` (e.g. ``_fp8_cs``, ``_mxfp8``)
# so they land in separate sibling dirs.
QUANT_RECIPE="${DEMO_QUANT_RECIPE:-}"
if [[ -z "$QUANT_RECIPE" && "${DEMO_USE_FP8:-0}" != "0" ]]; then
    QUANT_RECIPE="fp8_cs"
fi
QUANT_RECIPE="${QUANT_RECIPE:-bf16}"
AXIS_DIR="fsdp_${FSDP_AXIS_NAME}"
if [[ "$QUANT_RECIPE" != "bf16" ]]; then
    AXIS_DIR="${AXIS_DIR}_${QUANT_RECIPE}"
fi
if [[ -n "$RUN_NAME" ]]; then
    OUTPUT_DIR="$DEMO_DIR/output/${RUN_NAME}/${AXIS_DIR}"
else
    OUTPUT_DIR="$DEMO_DIR/output/${AXIS_DIR}"
fi
HLO_DIR="$OUTPUT_DIR/hlo"

mkdir -p "$HLO_DIR" "$OUTPUT_DIR/xprof"
# Wipe stale HLO so the post-run scan only sees fresh dumps.
rm -f "$HLO_DIR"/module_*.txt "$HLO_DIR"/*.html "$HLO_DIR"/*.dot 2>/dev/null || true

# Tell XLA to dump HLO. ``--xla_dump_hlo_as_text`` produces .txt files
# named ``module_<id>.<phase>.txt``; we read the post-opt one. The
# ``--xla_dump_hlo_pass_re=.*`` flag would ALSO dump every pass; we
# don't need that, just the final (and the unoptimized) snapshot.
export XLA_FLAGS="${XLA_FLAGS:-} --xla_dump_to=$HLO_DIR --xla_dump_hlo_as_text --xla_dump_hlo_module_re=.*"

# Do NOT add the workspace dir to PYTHONPATH: ``$DEMO_DIR/..`` is
# ``/.../tdophung/`` which contains a ``jax/`` source checkout that
# would shadow the installed ``jax`` package and cause cryptic
# import-time failures (``module 'jax' has no attribute 'Array'`` when
# flax tries ``Union[jax.Array, Any]``). TransformerEngine is already
# pip-installed in the container so it does not need to be on the path.

# Run from a neutral cwd so Python's automatic '' (cwd) sys.path entry
# does not pull in any local checkouts either.
cd /
python3 "$DEMO_DIR/run_demo.py" "$@"

# Build the static dataflow diagram (does not depend on the run, but
# rendering it after the run lets you flip between the diagram and the
# HLO collective summary side by side).
python3 "$DEMO_DIR/build_diagram.py"
