"""Render an SVG dataflow diagram of ``MoEBlock._forward_a2a_ep``.

This script does not import JAX. It captures the same dims used by
``run_demo.py``, walks the source-level structure of ``_forward_a2a_ep``
in ``transformer_engine/jax/flax/moe.py``, and emits a Graphviz DOT
file + SVG showing:

  * each named tensor that crosses a stage boundary, with its
    **per-shard** shape and bf16 byte count;
  * which mesh axis the tensor is sharded on (``ep``, ``fsdp``, or
    replicated);
  * the type of cross-shard collective that XLA inserts at each stage
    transition (all-gather, ragged-all-to-all, etc.).

The output corresponds to a single ``ep`` shard's view: anywhere a
tensor is sharded along ``ep`` you see the per-shard slice. ``fsdp``
sharding is annotated in the box label.

Run::

    python3 build_diagram.py

The SVG is rendered via ``dot -Tsvg`` if available; otherwise only the
DOT file is written. Outputs land under ``output/``.
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple


# ---------------------------------------------------------------------------
# Config (must match run_demo.py — both read the same DEMO_* env vars)
# ---------------------------------------------------------------------------
import os as _os


def _env_int(name: str, default: int) -> int:
    raw = _os.environ.get(name)
    return int(raw) if raw not in (None, "") else default


B = _env_int("DEMO_BATCH_SIZE", 8)
S = _env_int("DEMO_SEQUENCE_LENGTH", 32)
H = _env_int("DEMO_HIDDEN_SIZE", 64)
I = _env_int("DEMO_INTERMEDIATE_SIZE", 128)
E = _env_int("DEMO_NUM_EXPERTS", 16)
K = _env_int("DEMO_NUM_EXPERTS_PER_TOK", 2)
EP = _env_int("DEMO_EP_SIZE", 2)
FSDP = _env_int("DEMO_FSDP_SIZE", 2)
BYTES_PER_ELEM = 2  # bf16

# Match run_demo.py's FSDP axis convention via the same env var.
FSDP_LOGICAL_AXIS = _os.environ.get("FSDP_LOGICAL_AXIS", "mlp")
assert FSDP_LOGICAL_AXIS in ("embed", "mlp")
DEMO_RUN_NAME = _os.environ.get("DEMO_RUN_NAME", "")
# Mirror run_demo.py's path layout: bf16 keeps the legacy dir name;
# non-bf16 recipes (fp8_cs, fp8_ds, mxfp8) land in sibling
# ``fsdp_<axis>_<tag>/`` dirs. ``DEMO_USE_FP8=1`` is the legacy
# alias for ``DEMO_QUANT_RECIPE=fp8_cs``.
_QUANT_RECIPE = _os.environ.get("DEMO_QUANT_RECIPE", "").strip().lower()
if not _QUANT_RECIPE:
    _QUANT_RECIPE = (
        "fp8_cs" if bool(int(_os.environ.get("DEMO_USE_FP8", "0") or "0")) else "bf16"
    )
QUANT_TAG = _QUANT_RECIPE

E_LOCAL = E // EP                    # 8
B_EP = B // EP                       # 4 (per ep-shard, replicated across fsdp)
B_FSDP = B // FSDP                   # 4 (per fsdp-shard, legacy view)
B_DEV = B // (EP * FSDP)             # 2 (per-DEVICE unique batch under Exp 3)
N_LOCAL = B_DEV * S                  # 64 -- token count per device
RECV_BUF = (B // FSDP) * S * K       # 256 -- worst-case recv buffer per device
                                     #     ep peers each send <= B/(ep*fsdp)*S*K
                                     #     => ep * B/(ep*fsdp)*S*K = B/fsdp*S*K

# Per-shard weight extents under the active FSDP convention:
#   wi_*: (E_local, H, I), shard the embed (H, dim 1) OR mlp (I, dim 2)
#   wo:   (E_local, I, H), shard the mlp (I, dim 1) OR embed (H, dim 2)
if FSDP_LOGICAL_AXIS == "embed":
    WI_SHARD_DIM, WI_SHARD_SIZE = 1, H // FSDP
    WI_SPEC = "P('ep','fsdp',None)"
    WO_SHARD_DIM, WO_SHARD_SIZE = 2, H // FSDP
    WO_SPEC = "P('ep',None,'fsdp')"
    WI_PER_SHARD = (E_LOCAL, H // FSDP, I)
    WO_PER_SHARD = (E_LOCAL, I, H // FSDP)
else:  # "mlp"
    WI_SHARD_DIM, WI_SHARD_SIZE = 2, I // FSDP
    WI_SPEC = "P('ep',None,'fsdp')"
    WO_SHARD_DIM, WO_SHARD_SIZE = 1, I // FSDP
    WO_SPEC = "P('ep','fsdp',None)"
    WI_PER_SHARD = (E_LOCAL, H, I // FSDP)
    WO_PER_SHARD = (E_LOCAL, I // FSDP, H)


def fmt_bytes(n: int) -> str:
    if n < 1024:
        return f"{n}B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f}KiB"
    return f"{n / (1024 * 1024):.2f}MiB"


def shape_size(shape: Tuple[int, ...]) -> int:
    n = 1
    for s in shape:
        n *= int(s)
    return n * BYTES_PER_ELEM


# ---------------------------------------------------------------------------
# Stage and edge model
# ---------------------------------------------------------------------------
class Stage:
    def __init__(
        self,
        node_id: str,
        title: str,
        tensors: List[Tuple],
        scope: str = "shard_map",
        dead: bool = False,
    ) -> None:
        # tensors: list of either
        #   (name, per-shard shape, note)        -- legacy 3-tuple
        #   (name, per-shard shape, symbolic, note) -- 4-tuple, shows
        #       both numeric and symbolic dims (preferred).
        # dead: render with a dashed border + grey fill; used for
        # backward nodes that XLA dead-code-eliminates because their
        # gradient consumer is not requested (e.g. ``d(inputs)``).
        self.id = node_id
        self.title = title
        self.tensors = tensors
        self.scope = scope
        self.dead = dead

    def label(self) -> str:
        # Plain text record-style label. ``\l`` left-justifies a line
        # in record-shape Graphviz nodes; ``\n`` centers it.
        body_lines = []
        for entry in self.tensors:
            if len(entry) == 4:
                name, shape, symbolic, note = entry
            else:
                name, shape, note = entry
                symbolic = ""
            sz = fmt_bytes(shape_size(shape))
            shape_str = "x".join(str(s) for s in shape) if shape else "scalar"
            sym_str = f" = ({symbolic})" if symbolic else ""
            body_lines.append(
                f"  {name}: [{shape_str}]{sym_str}  {sz}  {note}"
            )
        body = "\\l".join(body_lines) + "\\l" if body_lines else ""
        title = self.title.replace('"', '\\"')
        return f"{title}\\n{body}" if body else title


class Edge:
    """Edge connecting one stage to the next, optionally annotated as a collective."""
    def __init__(
        self,
        src: str,
        dst: str,
        collective: Optional[str] = None,
        bytes_moved: Optional[int] = None,
        note: str = "",
    ) -> None:
        self.src = src
        self.dst = dst
        self.collective = collective
        self.bytes_moved = bytes_moved
        self.note = note


# ---------------------------------------------------------------------------
# Build the model
# ---------------------------------------------------------------------------
def build_stages() -> Tuple[List[Stage], List[Edge]]:
    stages: List[Stage] = []
    edges: List[Edge] = []

    # -- Initial: param + input layout outside shard_map ------------------
    # Experiment 3 default: input arrives ALREADY sharded on
    # (ep, fsdp) -> matches the shard_map's in_specs -> NO entry
    # collective-permute. Each device owns B/(ep*fsdp) unique tokens.
    stages.append(
        Stage(
            "init",
            f"Init (per-device, outside shard_map). FSDP: {FSDP_LOGICAL_AXIS!r}"
            "  --  Experiment-3 layout (true FSDP)",
            [
                (
                    "inputs",
                    (B_DEV, S, H),
                    "B/(ep*fsdp) x S x H",
                    f"P(('ep','fsdp'), None, None) -- batch sharded over BOTH"
                    f" ep AND fsdp; matches shard_map in_specs (no reshard)",
                ),
                (
                    "wi_0",
                    WI_PER_SHARD,
                    "E/ep x H x I/fsdp" if FSDP_LOGICAL_AXIS == "mlp"
                    else "E/ep x H/fsdp x I",
                    f"{WI_SPEC} (shards {FSDP_LOGICAL_AXIS} on dim {WI_SHARD_DIM})",
                ),
                (
                    "wi_1",
                    WI_PER_SHARD,
                    "E/ep x H x I/fsdp" if FSDP_LOGICAL_AXIS == "mlp"
                    else "E/ep x H/fsdp x I",
                    f"{WI_SPEC}",
                ),
                (
                    "wo",
                    WO_PER_SHARD,
                    "E/ep x I/fsdp x H" if FSDP_LOGICAL_AXIS == "mlp"
                    else "E/ep x I x H/fsdp",
                    f"{WO_SPEC} (shards {FSDP_LOGICAL_AXIS} on dim {WO_SHARD_DIM})",
                ),
                (
                    "gate_kernel",
                    (H, E),
                    "H x E",
                    f"P(None, None) -- gate is replicated",
                ),
            ],
            scope="outside",
        )
    )

    # -- Gate (einsum, runs in outer scope but per-shard local data) ------
    stages.append(
        Stage(
            "gate",
            "1. Gate: einsum(inputs, gate_kernel)",
            [
                (
                    "gate_logits",
                    (B_DEV, S, E),
                    "B/(ep*fsdp) x S x E",
                    "P(('ep','fsdp'), None, None)",
                ),
            ],
            scope="outside",
        )
    )
    edges.append(Edge("init", "gate"))

    # ---------------- shard_map body ------------------------------------
    stages.append(
        Stage(
            "route",
            "2. Router topk (fused_topk_with_score_function)",
            [
                ("inputs_2d",    (N_LOCAL, H), "(B/(ep*fsdp)*S) x H", "flatten of inputs"),
                ("logits_2d",    (N_LOCAL, E), "(B/(ep*fsdp)*S) x E", "flatten of gate_logits"),
                ("sparse_probs", (N_LOCAL, E), "(B/(ep*fsdp)*S) x E", "post-topk + softmax"),
                ("routing_map",  (N_LOCAL, E), "(B/(ep*fsdp)*S) x E", "bool token->expert mask"),
                ("group_sizes",  (E,),         "E",                   "this-device-only count per expert"),
            ],
        )
    )
    edges.append(Edge("gate", "route"))

    # Aux-loss path: AG logits across BOTH ep AND fsdp (Experiment 3:
    # batch is sharded over both, so the global token batch lives on
    # all (ep, fsdp) peers combined).
    stages.append(
        Stage(
            "aux",
            "2b. Aux-loss path (AG logits over (ep, fsdp))",
            [
                (
                    "global_logits_2d",
                    (B * S, E),
                    "(B*S) x E",
                    "after AllGather over ('ep','fsdp') for cross-shard fairness",
                ),
                ("aux_loss", (), "scalar (f32)", "scalar contribution to total loss"),
            ],
        )
    )
    edges.append(
        Edge(
            "route",
            "aux",
            collective="all-gather (ep, fsdp)",
            bytes_moved=shape_size((N_LOCAL, E)) * (EP * FSDP - 1),
            note="logits gathered over both batch axes for global aux loss",
        )
    )

    stages.append(
        Stage(
            "global_permute",
            "3. Global permute (token dispatch over all E)",
            [
                (
                    "perm.sorted_inputs",
                    (N_LOCAL * K, H),
                    "(B/(ep*fsdp)*S*K) x H",
                    "tokens duplicated per topK and grouped by expert id",
                ),
                ("perm.group_sizes", (E,), "E", "this-device count per expert"),
            ],
        )
    )
    edges.append(Edge("route", "global_permute"))

    # AG group_sizes across ep so every shard has the [ep, E] matrix.
    # WHY: the local group_sizes from the router only counts tokens
    # routed FROM this ep-shard. To plan the ragged-A2A you need to
    # know, for every (source_shard, dest_expert) pair, how many tokens
    # are involved -- that's an [ep, E] matrix. This single AG produces
    # the matrix that 4 downstream stages all depend on.
    stages.append(
        Stage(
            "ag_gs",
            "4. AllGather group_sizes over ep  (single source feeding 4 stages)",
            [
                (
                    "all_shards_tokens_per_expert",
                    (EP, E),
                    "ep x E",
                    "[i,e] = #tokens shard i wants on expert e."
                    " Drives input/send/recv offsets+sizes for"
                    " BOTH ragged-A2As AND the local (un)permutes.",
                ),
            ],
        )
    )
    edges.append(
        Edge(
            "global_permute",
            "ag_gs",
            collective="all-gather (ep)",
            bytes_moved=E * 4 * (EP - 1),  # int32, 4 bytes
            note="group_sizes int32 vectors",
        )
    )

    # Forward ragged-A2A
    stages.append(
        Stage(
            "raa_fwd",
            "5. Forward ragged_all_to_all over ep",
            [
                (
                    "x_recv",
                    (RECV_BUF, H),
                    "(B/fsdp*S*K) x H",
                    "static recv buffer; worst case = ep peers each send"
                    " B/(ep*fsdp)*S*K rows -> sum is B/fsdp*S*K"
                    " (Experiment 3 tightens the buffer fsdp-fold vs legacy)",
                ),
            ],
        )
    )
    edges.append(
        Edge(
            "global_permute",
            "raa_fwd",
            collective="ragged-all-to-all (ep)",
            bytes_moved=shape_size((N_LOCAL * K, H)) * (EP - 1) // EP,
            note="per-expert chunks routed to expert-owning shards",
        )
    )
    edges.append(
        Edge(
            "ag_gs",
            "raa_fwd",
            note="provides input_offsets / send_sizes /"
            " output_offsets / recv_sizes",
        )
    )

    # Local permute (Triton chunk sort)
    stages.append(
        Stage(
            "local_perm",
            "6. Local permute (Triton sort_chunks_by_index)",
            [
                (
                    "sorted_x",
                    (RECV_BUF, H),
                    "(B/fsdp*S*K) x H",
                    "expert-major: rows grouped by LOCAL expert id"
                    " (resorted from source-shard-major)",
                ),
                (
                    "local_group_sizes",
                    (E_LOCAL,),
                    "E/ep",
                    "per-local-expert token count",
                ),
            ],
        )
    )
    edges.append(Edge("raa_fwd", "local_perm"))
    edges.append(
        Edge("ag_gs", "local_perm",
             note="needs per-(src,local_expert) chunk sizes"),
    )

    # FSDP all-gather of weight slices happens here (custom_partitioning
    # of grouped_dense). wi_0/wi_1 are P('ep','fsdp',None) -> per-shard
    # [E_local, H/FSDP, I] -- AG along fsdp before GEMM. Under
    # Experiment 3, sorted_x is now UNIQUE per device (no longer
    # replicated across fsdp peers), so the FFN compute is genuinely
    # ep*fsdp-way data parallel. The fwd collective is still just an
    # AG of the weight; the bwd will now require a real RS over fsdp
    # for weight grads (see d_ffn_w*_rs nodes below).
    stages.append(
        Stage(
            "ffn_w0",
            "7. grouped_dense wi_0  (FSDP-AG of wi_0 happens here)",
            [
                ("sorted_x (unique per device)", (RECV_BUF, H), "(B/fsdp*S*K) x H",
                 "Exp 3: unique per device, batch-sharded over fsdp"),
                ("wi_0 (gathered)", (E_LOCAL, H, I), "E/ep x H x I",
                 "after AllGather over fsdp"),
                ("layer_w0", (RECV_BUF, I), "(B/fsdp*S*K) x I", "GEMM output"),
            ],
        )
    )
    edges.append(
        Edge(
            "local_perm",
            "ffn_w0",
            collective="all-gather (fsdp)",
            bytes_moved=shape_size(WI_PER_SHARD) * (FSDP - 1),
            note=f"AG only the WEIGHT (sharded on {FSDP_LOGICAL_AXIS});"
            " activation is unique per device",
        )
    )

    stages.append(
        Stage(
            "ffn_w1",
            "8. grouped_dense wi_1  (FSDP-AG of wi_1 happens here)",
            [
                ("sorted_x (unique per device)", (RECV_BUF, H), "(B/fsdp*S*K) x H",
                 "Exp 3: unique per device"),
                ("wi_1 (gathered)", (E_LOCAL, H, I), "E/ep x H x I",
                 "after AllGather over fsdp"),
                ("layer_w1", (RECV_BUF, I), "(B/fsdp*S*K) x I", "GEMM output"),
            ],
        )
    )
    edges.append(
        Edge(
            "local_perm",
            "ffn_w1",
            collective="all-gather (fsdp)",
            bytes_moved=shape_size(WI_PER_SHARD) * (FSDP - 1),
            note=f"AG only the WEIGHT (sharded on {FSDP_LOGICAL_AXIS})",
        )
    )

    stages.append(
        Stage(
            "swiglu",
            "9. SwiGLU: act(layer_w0) * layer_w1",
            [("intermediate", (RECV_BUF, I), "(B/fsdp*S*K) x I",
              "elementwise; unique per device")],
        )
    )
    edges.append(Edge("ffn_w0", "swiglu"))
    edges.append(Edge("ffn_w1", "swiglu"))

    stages.append(
        Stage(
            "ffn_wo",
            "10. grouped_dense wo  (FSDP-AG of wo happens here)",
            [
                ("intermediate (unique per device)", (RECV_BUF, I), "(B/fsdp*S*K) x I",
                 "Exp 3: unique per device"),
                ("wo (gathered)", (E_LOCAL, I, H), "E/ep x I x H",
                 "after AllGather over fsdp"),
                ("expert_outputs", (RECV_BUF, H), "(B/fsdp*S*K) x H", "GEMM output"),
            ],
        )
    )
    edges.append(
        Edge(
            "swiglu",
            "ffn_wo",
            collective="all-gather (fsdp)",
            bytes_moved=shape_size(WO_PER_SHARD) * (FSDP - 1),
            note=f"AG only the WEIGHT (sharded on {FSDP_LOGICAL_AXIS})",
        )
    )

    stages.append(
        Stage(
            "local_unperm",
            "11. Local unpermute (sort_chunks_by_index inverse)",
            [("x_send_back", (RECV_BUF, H), "(B/fsdp*S*K) x H",
              "rows reordered back to (source_shard, expert) layout")],
        )
    )
    edges.append(Edge("ffn_wo", "local_unperm"))
    edges.append(
        Edge("ag_gs", "local_unperm",
             note="needs per-(src,local_expert) chunk sizes (inverse)"),
    )

    stages.append(
        Stage(
            "raa_rev",
            "12. Reverse ragged_all_to_all over ep",
            [("y_back", (N_LOCAL * K, H), "(B/(ep*fsdp)*S*K) x H",
              "shape matches perm.sorted_inputs")],
        )
    )
    edges.append(
        Edge(
            "local_unperm",
            "raa_rev",
            collective="ragged-all-to-all (ep)",
            bytes_moved=shape_size((RECV_BUF, H)) * (EP - 1) // EP,
            note="reverse path: chunks back to source shards",
        )
    )
    edges.append(
        Edge("ag_gs", "raa_rev",
             note="provides reverse send/recv sizes+offsets"),
    )

    stages.append(
        Stage(
            "global_combine",
            "13. Global combine (token combine + topk weighted sum)",
            [("output", (B_DEV, S, H), "B/(ep*fsdp) x S x H",
              "P(('ep','fsdp'), None, None)")],
        )
    )
    edges.append(Edge("raa_rev", "global_combine"))

    # ---------------- exit shard_map ------------------------------------
    # Output stays on P(('ep','fsdp'), ...) under Experiment 3 (no TP).
    stages.append(
        Stage(
            "output",
            "Output (per-device, outside shard_map)",
            [
                ("output", (B_DEV, S, H), "B/(ep*fsdp) x S x H",
                 "P(('ep','fsdp'), None, None) per shard_map out_specs"),
            ],
            scope="outside",
        )
    )
    edges.append(Edge("global_combine", "output"))
    # Aux-loss flows directly into the loss scalar (no further fwd dep).
    edges.append(
        Edge("aux", "loss",
             note="aux_loss summed into total loss (no other fwd consumer)"),
    )

    # ============================================================
    # Backward cluster
    # ============================================================
    # Mirrors the forward stages in reverse, annotated with the
    # *actual* HLO-observed bwd collectives. Reads top-to-bottom in
    # forward direction (which is bwd-direction for grads). The shapes
    # below match the post-opt HLO from
    # ``output/fsdp_<axis>/hlo/module_*jit_fwd_and_grad*after_opt*.txt``
    # for B=8 S=32 H=64 I=128 E=16 K=2 ep=2 fsdp=2.
    stages.append(
        Stage(
            "loss",
            "Loss scalar (jnp.mean(output**2) + aux_loss)",
            [("loss", (), "scalar (f32)",
              "f32[] -- replicated after AR over ep")],
            scope="bwd",
        )
    )
    edges.append(
        Edge(
            "output",
            "loss",
            collective="all-reduce (ep, fsdp, f32[])",
            bytes_moved=4,
            note="loss scalar reduce_sum over BOTH batch axes",
        )
    )

    # Backward of _global_combine: produces d_y_back + d_routing_weights.
    stages.append(
        Stage(
            "d_global_combine",
            "13'. d(_global_combine)",
            [
                ("d_y_back",          (N_LOCAL * K, H),
                 "(B/(ep*fsdp)*S*K) x H", "feeds bwd of reverse RAA"),
                ("d_routing_weights", (N_LOCAL, K),
                 "(B/(ep*fsdp)*S) x K",   "feeds bwd of router (gate path)"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("loss", "d_global_combine",
                      note="d(loss)/d(output)"))

    # Backward of reverse ragged_all_to_all -> ragged-A2A [256->512]
    stages.append(
        Stage(
            "d_raa_rev",
            "12'. d(reverse RAA)",
            [("d(x_send_back)", (RECV_BUF, H), "(B/fsdp*S*K) x H",
              "static buffer, mirrors x_send_back")],
            scope="bwd",
        )
    )
    edges.append(
        Edge(
            "d_global_combine",
            "d_raa_rev",
            collective="ragged-all-to-all (ep)",
            bytes_moved=shape_size((N_LOCAL * K, H)) * (EP - 1) // EP,
            note="dual of reverse RAA  (start.2 in HLO)",
        )
    )

    stages.append(
        Stage(
            "d_local_unperm",
            "11'. d(local_unpermute_before_a2a)",
            [("d(expert_outputs)", (RECV_BUF, H), "(B/fsdp*S*K) x H",
              "rows back to expert-major layout")],
            scope="bwd",
        )
    )
    edges.append(Edge("d_raa_rev", "d_local_unperm"))

    # GEMM bwds: each grouped_dense bwd produces d(input) and d(weight).
    # Under Experiment 3, the activations differ across fsdp peers, so
    # the partial dW also differs => REAL reduce-scatter over fsdp is
    # needed (vs the legacy ZeRO-1 layout where partials were identical
    # and the fsdp reduction was a XLA-CSE'd no-op).
    stages.append(
        Stage(
            "d_ffn_wo",
            "10'. d(grouped_dense wo)",
            [
                ("d(intermediate)", (RECV_BUF, I), "(B/fsdp*S*K) x I",
                 "input grad"),
                ("partial dwo (full kernel shape)",  (E_LOCAL, I, H),
                 "E/ep x I x H",
                 "before fsdp RS: GEMM bwd produces full-kernel-shape partial"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("d_local_unperm", "d_ffn_wo"))

    stages.append(
        Stage(
            "d_swiglu",
            "9'. d(SwiGLU)",
            [
                ("d(layer_w0)", (RECV_BUF, I), "(B/fsdp*S*K) x I", "elementwise"),
                ("d(layer_w1)", (RECV_BUF, I), "(B/fsdp*S*K) x I", "elementwise"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("d_ffn_wo", "d_swiglu"))

    stages.append(
        Stage(
            "d_ffn_w1",
            "8'. d(grouped_dense wi_1)",
            [
                ("d(sorted_x) #1", (RECV_BUF, H), "(B/fsdp*S*K) x H",
                 "input grad partial"),
                ("partial dwi_1 (full kernel shape)", (E_LOCAL, H, I),
                 "E/ep x H x I",
                 "before fsdp RS"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("d_swiglu", "d_ffn_w1"))

    stages.append(
        Stage(
            "d_ffn_w0",
            "7'. d(grouped_dense wi_0)",
            [
                ("d(sorted_x) #0", (RECV_BUF, H), "(B/fsdp*S*K) x H",
                 "input grad partial"),
                ("partial dwi_0 (full kernel shape)", (E_LOCAL, H, I),
                 "E/ep x H x I",
                 "before fsdp RS"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("d_swiglu", "d_ffn_w0"))

    stages.append(
        Stage(
            "d_local_perm",
            "6'. d(local_permute_after_a2a)",
            [("d(x_recv)", (RECV_BUF, H), "(B/fsdp*S*K) x H",
              "rows back to source-shard-major layout")],
            scope="bwd",
        )
    )
    edges.append(Edge("d_ffn_w0", "d_local_perm"))
    edges.append(Edge("d_ffn_w1", "d_local_perm"))

    # The bwd of the forward ragged_all_to_all is DEAD: the only thing
    # downstream of it is d(inputs), which value_and_grad does not
    # request (we only differentiate w.r.t. ``variables``). XLA DCEs
    # this op — only 3 ragged-A2As show up in the post-opt HLO instead
    # of the expected 4.
    stages.append(
        Stage(
            "d_raa_fwd_dce",
            "5'. d(forward RAA)  -- DCE'd by XLA",
            [
                (
                    "d(perm.sorted_inputs)",
                    (N_LOCAL * K, H),
                    "(B/(ep*fsdp)*S*K) x H",
                    "would be ragged-A2A but value_and_grad doesn't"
                    " request d(inputs); XLA drops it.",
                )
            ],
            scope="bwd",
            dead=True,
        )
    )
    edges.append(
        Edge(
            "d_local_perm",
            "d_raa_fwd_dce",
            collective="(ragged-all-to-all DCE'd)",
            note="bwd of fwd RAA -- eliminated",
        )
    )

    # Routing/aux-loss bwd path: d_aux flows DIRECTLY from loss (not via
    # combine), then bwd of the AG is a reduce-scatter over (ep, fsdp).
    stages.append(
        Stage(
            "d_aux_rs",
            "2b'. d(aux-loss AG over (ep, fsdp))",
            [
                ("d(aux_loss)",        (),         "scalar (f32)",
                 "scalar gradient = 1.0"),
                ("d(global_logits_2d)", (B * S, E), "(B*S) x E",
                 "before RS"),
                ("d(logits_2d)",       (N_LOCAL, E), "(B/(ep*fsdp)*S) x E",
                 "after RS"),
            ],
            scope="bwd",
        )
    )
    edges.append(
        Edge(
            "loss",
            "d_aux_rs",
            collective="reduce-scatter (ep, fsdp)",
            bytes_moved=shape_size((N_LOCAL, E)),
            note="dual of fwd AG-of-logits over (ep, fsdp); int32"
            " group_sizes AG is non-differentiable, so no RS for it",
        )
    )

    stages.append(
        Stage(
            "d_route",
            "2'. d(_route_topk) -- merge two grad sources",
            [("d(logits_2d) merged", (N_LOCAL, E), "(B/(ep*fsdp)*S) x E",
              "= d(routing_weights) backprop + d(aux) backprop")],
            scope="bwd",
        )
    )
    edges.append(Edge("d_aux_rs", "d_route",
                      note="d(logits_2d) from aux path"))
    edges.append(
        Edge(
            "d_global_combine",
            "d_route",
            note="d(logits_2d) from main path (via d_routing_weights)",
        )
    )

    # Backward through the gate (einsum). Since gate_kernel is
    # REPLICATED, its grad needs an AR over BOTH batch axes (ep, fsdp).
    # No d_input_reshard node any more -- there is no fwd reshard.
    stages.append(
        Stage(
            "d_gate",
            "1'. d(gate) -- partial dgate_kernel",
            [
                ("d(gate_logits)", (B_DEV, S, E), "B/(ep*fsdp) x S x E",
                 "per-device, batch-sharded over (ep, fsdp)"),
                ("partial dgate_kernel", (H, E), "H x E",
                 "P() (replicated, partial; reduced via AR below)"),
            ],
            scope="bwd",
        )
    )
    edges.append(Edge("d_route", "d_gate"))

    # Final reductions under Experiment 3 (no longer a no-op like the
    # legacy ZeRO-1 layout):
    #   * FFN weight grads: REDUCE-SCATTER over fsdp on the kernel's
    #     fsdp-sharded dim (H for embed, I for mlp), then optional AR
    #     over ep depending on whether kernel is ep-sharded on E.
    #   * gate_kernel: full all-reduce over (ep, fsdp) since it is
    #     replicated everywhere.
    stages.append(
        Stage(
            "d_weight_rs_fsdp",
            "Final-A: weight-grad reduce-scatter over fsdp",
            [
                ("dwi_0", WI_PER_SHARD,
                 "E/ep x H x I/fsdp" if FSDP_LOGICAL_AXIS == "mlp"
                 else "E/ep x H/fsdp x I", WI_SPEC),
                ("dwi_1", WI_PER_SHARD,
                 "E/ep x H x I/fsdp" if FSDP_LOGICAL_AXIS == "mlp"
                 else "E/ep x H/fsdp x I", WI_SPEC),
                ("dwo",   WO_PER_SHARD,
                 "E/ep x I/fsdp x H" if FSDP_LOGICAL_AXIS == "mlp"
                 else "E/ep x I x H/fsdp", WO_SPEC),
            ],
            scope="bwd",
        )
    )
    edges.append(
        Edge(
            "d_ffn_w0",
            "d_weight_rs_fsdp",
            collective="reduce-scatter (fsdp)",
            bytes_moved=(
                2 * shape_size((E_LOCAL, H, I))
                + shape_size((E_LOCAL, I, H))
            ) * (FSDP - 1) // FSDP,
            note=f"NEW under Exp 3: scatter on the {FSDP_LOGICAL_AXIS}"
            " dim. Activations differ across fsdp peers, so partials"
            " differ -- a real reduction is needed (was XLA-CSE'd"
            " no-op in legacy ZeRO-1 layout).",
        )
    )
    edges.append(Edge("d_ffn_w1", "d_weight_rs_fsdp"))
    edges.append(Edge("d_ffn_wo", "d_weight_rs_fsdp"))

    stages.append(
        Stage(
            "d_gate_ar",
            "Final-B: dgate_kernel all-reduce over (ep, fsdp)",
            [
                ("dgate_kernel", (H, E), "H x E",
                 "P() (replicated; full AR over both batch axes)"),
            ],
            scope="bwd",
        )
    )
    edges.append(
        Edge(
            "d_gate",
            "d_gate_ar",
            collective="all-reduce (ep, fsdp, bf16)",
            bytes_moved=shape_size((H, E)),
            note="replicated param: needs full AR across all batch axes",
        )
    )

    return stages, edges


# ---------------------------------------------------------------------------
# DOT/SVG emission
# ---------------------------------------------------------------------------
def emit_dot(stages: List[Stage], edges: List[Edge]) -> str:
    title = (
        f"MoEBlock _forward_a2a_ep dataflow  --  Experiment-3 layout\\n"
        f"B={B}, S={S}, H={H}, I={I}, E={E}, K={K},"
        f" ep={EP}, fsdp={FSDP}, bf16  (B/(ep*fsdp)={B_DEV} per device)\\n"
        f"in_specs/out_specs: P(('ep','fsdp'), None, None)"
        f" -- batch sharded over BOTH axes\\n"
        f"FSDP shards weight axis: {FSDP_LOGICAL_AXIS!r}"
        f" (rule {FSDP_LOGICAL_AXIS!r}->'fsdp')"
    )
    out = [
        "digraph MoE_A2A_EP {",
        "  graph [rankdir=TB, fontname=\"Helvetica\", labelloc=t,"
        f" label=\"{title}\"];",
        "  node [shape=box, style=\"rounded,filled\","
        " fontname=\"Helvetica\", fontsize=10];",
        "  edge [fontname=\"Helvetica\", fontsize=9];",
    ]

    # Group nodes by scope.
    inside = [s for s in stages if s.scope == "shard_map"]
    outside = [s for s in stages if s.scope == "outside"]
    bwd = [s for s in stages if s.scope == "bwd"]

    def _node_line(s: Stage, fill: str) -> str:
        extra = ""
        if s.dead:
            fill = "#e8e8e8"
            extra = ', style="rounded,filled,dashed", color="#888888"'
        return (
            f'    {s.id} [label="{s.label()}",'
            f' fillcolor="{fill}"{extra}];'
        )

    out.append("  subgraph cluster_outside {")
    out.append('    label="outside shard_map (per-device)"; color=gray70;')
    for s in outside:
        out.append(_node_line(s, "#f0f4ff"))
    out.append("  }")

    out.append("  subgraph cluster_inside {")
    out.append(
        '    label="forward: inside shard_map _a2a_fn (per-device view -- batch sharded over (ep, fsdp))";'
        ' color="#3366aa";'
    )
    for s in inside:
        fill = "#fff5e6" if s.id.startswith(("raa_", "ag_")) else "#f6fff0"
        out.append(_node_line(s, fill))
    out.append("  }")

    if bwd:
        out.append("  subgraph cluster_bwd {")
        out.append(
            '    label="backward: gradient flow + observed bwd collectives";'
            ' color="#aa3366";'
        )
        for s in bwd:
            # Highlight bwd RAA/AR/RS nodes the same way fwd collectives are.
            collective_node = s.id.startswith(
                ("d_raa_", "d_aux_rs", "d_weight_rs_fsdp",
                 "d_gate_ar", "loss")
            )
            fill = "#ffe8ef" if collective_node else "#fff0f5"
            out.append(_node_line(s, fill))
        out.append("  }")

    for e in edges:
        attrs = []
        if e.collective:
            color = {
                "ragged-all-to-all": "#cc3344",
                "all-to-all": "#cc3344",
                "all-gather": "#3388cc",
                "reduce-scatter": "#33aa55",
                "all-reduce": "#aa55cc",
            }.get(e.collective.split(" ")[0], "#888888")
            label_parts = [e.collective]
            if e.bytes_moved:
                label_parts.append(fmt_bytes(e.bytes_moved))
            if e.note:
                label_parts.append(e.note)
            label = "\\n".join(label_parts).replace('"', '\\"')
            attrs.append(f'label="{label}"')
            attrs.append(f'color="{color}"')
            attrs.append("style=bold")
            attrs.append(f'fontcolor="{color}"')
        attr_str = " [" + ", ".join(attrs) + "]" if attrs else ""
        out.append(f"  {e.src} -> {e.dst}{attr_str};")

    out.append("}")
    return "\n".join(out)


def main() -> int:
    base = Path(__file__).resolve().parent / "output"
    if DEMO_RUN_NAME:
        base = base / DEMO_RUN_NAME
    axis_dir = f"fsdp_{FSDP_LOGICAL_AXIS}"
    if QUANT_TAG != "bf16":
        axis_dir = f"{axis_dir}_{QUANT_TAG}"
    out_dir = base / axis_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    dot_path = out_dir / "moe_a2a_ep_dataflow.dot"
    svg_path = out_dir / "moe_a2a_ep_dataflow.svg"

    stages, edges = build_stages()
    dot_path.write_text(emit_dot(stages, edges) + "\n")
    print(f"DOT  -> {dot_path}")

    dot_bin = shutil.which("dot")
    if dot_bin is None:
        print(
            "(graphviz `dot` not on PATH; install with `apt-get install"
            " graphviz` to render SVG)"
        )
        return 0

    res = subprocess.run(
        [dot_bin, "-Tsvg", str(dot_path), "-o", str(svg_path)],
        capture_output=True,
        text=True,
    )
    if res.returncode != 0:
        print("dot failed:")
        print(res.stderr)
        return res.returncode
    print(f"SVG  -> {svg_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
