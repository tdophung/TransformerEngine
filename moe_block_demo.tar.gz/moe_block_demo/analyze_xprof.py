"""Programmatic kernel-time analyzer for the moeblock xprof traces.

Reads ``output/[<run_name>/]fsdp_<axis>/xprof/plugins/profile/<TS>/<host>.trace.json.gz``
(the chrome-trace format JAX's profiler emits) and produces:

  * a tally of every distinct kernel name with its invocation count,
    total duration, mean duration, and which device(s) it ran on;
  * a focused breakdown for the FSDP-AG fixup transposes
    (``loop_transpose_fusion*`` + ``input_transpose_fusion`` +
    ``wrapped_transpose``);
  * a side-by-side comparison between two axes (default: embed vs mlp);
  * per-instance timelines so you can see when each instance of a
    particular kernel ran.

Why this exists: tensorboard's UI deduplicates / renames kernels
(``.1`` -> ``_1``) and sometimes hides instances behind framework
scopes, which makes it hard to manually verify that all 3 weight
fixups are present and to sum their times. This script reads the raw
trace and gives you exact numbers.

Usage:

    # Default: dsv3_mini fsdp_embed vs fsdp_mlp, summary + transpose
    # focus + comparison.
    python3 moe_block_demo/analyze_xprof.py

    # Custom run name (toy demo: no run name at all).
    python3 moe_block_demo/analyze_xprof.py --run-name ""

    # Drill into one trace.
    python3 moe_block_demo/analyze_xprof.py --left-only --left fsdp_embed \
        --run-name dsv3_mini

    # Filter the per-kernel summary to just transpose-style ops.
    python3 moe_block_demo/analyze_xprof.py --filter transpose

    # Print every instance of one kernel name (timeline).
    python3 moe_block_demo/analyze_xprof.py --instances loop_transpose_fusion

    # Save to a file instead of (just) stdout.
    python3 moe_block_demo/analyze_xprof.py --out exp2_xprof_diff.txt
"""

from __future__ import annotations

import argparse
import gzip
import json
import re
import statistics
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

DEMO_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = DEMO_DIR / "output"

# Kernel names that are part of the FSDP-AG-fixup transpose family.
# These are the candidates for the "embed vs mlp" comparison.
TRANSPOSE_FAMILY_PREFIXES = (
    "loop_transpose_fusion",  # loop emitter (kInput) post-AG transpose
    "input_transpose_fusion",  # Triton emitter (kCustom) post-AG transpose
    "wrapped_transpose",       # XLA's wrap-around for some transposes
)


@dataclass
class KernelStat:
    name: str
    n_calls: int
    total_dur_us: float
    mean_dur_us: float
    devices: List[str]
    instances: List[Tuple[float, float, str]]  # (start_us, dur_us, device)


# ---------------------------------------------------------------------------
# trace loading
# ---------------------------------------------------------------------------


def find_trace(axis: str, run_name: str) -> Path:
    base = OUTPUT_DIR / run_name if run_name else OUTPUT_DIR
    xprof_dir = base / f"fsdp_{axis}" / "xprof" / "plugins" / "profile"
    if not xprof_dir.is_dir():
        raise FileNotFoundError(
            f"No profile dir at {xprof_dir}. "
            f"Run {'``run_realistic.sh``' if run_name else '``run.sh``'} first."
        )
    # Pick the most recent profile capture.
    captures = sorted([p for p in xprof_dir.iterdir() if p.is_dir()])
    if not captures:
        raise FileNotFoundError(f"No capture subdirs under {xprof_dir}")
    cap = captures[-1]
    traces = list(cap.glob("*.trace.json.gz"))
    if not traces:
        raise FileNotFoundError(f"No *.trace.json.gz under {cap}")
    if len(traces) > 1:
        # Multiple hosts -- pick the largest by file size as a heuristic.
        traces.sort(key=lambda p: p.stat().st_size, reverse=True)
    return traces[0]


def load_trace(path: Path) -> dict:
    with gzip.open(path, "rt") as f:
        return json.load(f)


# ---------------------------------------------------------------------------
# parsing
# ---------------------------------------------------------------------------


def _device_for_pid(metadata: List[dict], pid: int) -> str:
    for m in metadata:
        if (
            m.get("pid") == pid
            and m.get("name") == "process_name"
            and "args" in m
        ):
            return m["args"].get("name", f"pid={pid}")
    return f"pid={pid}"


def parse_trace(data: dict) -> Dict[str, KernelStat]:
    """Return ``{kernel_name: KernelStat}`` aggregated across all GPU streams.

    We only count "X" (complete) events that have an ``args`` dict (the
    actual GPU kernel records on compute streams), because tensorboard's
    framework-scope events also use "X" but lack ``args.device_id`` /
    ``correlation_id`` and would double-count if included.
    """
    metadata = [ev for ev in data.get("traceEvents", []) if ev.get("ph") == "M"]
    pid_device = {}
    for ev in metadata:
        if ev.get("name") == "process_name" and "args" in ev:
            pid_device[ev.get("pid")] = ev["args"].get("name", "")

    by_name: Dict[str, KernelStat] = {}
    for ev in data.get("traceEvents", []):
        if ev.get("ph") != "X":
            continue
        # Skip framework-scope events (no kernel ``args``).
        if not ev.get("args"):
            continue
        name = ev.get("name") or "<unnamed>"
        dur = float(ev.get("dur") or 0.0)
        ts = float(ev.get("ts") or 0.0)
        pid = ev.get("pid")
        device = pid_device.get(pid) or f"pid={pid}"

        if name not in by_name:
            by_name[name] = KernelStat(
                name=name,
                n_calls=0,
                total_dur_us=0.0,
                mean_dur_us=0.0,
                devices=[],
                instances=[],
            )
        ks = by_name[name]
        ks.n_calls += 1
        ks.total_dur_us += dur
        if device not in ks.devices:
            ks.devices.append(device)
        ks.instances.append((ts, dur, device))

    for ks in by_name.values():
        ks.mean_dur_us = ks.total_dur_us / max(ks.n_calls, 1)
    return by_name


# ---------------------------------------------------------------------------
# rendering helpers
# ---------------------------------------------------------------------------


def _fmt_us(us: float) -> str:
    if us < 1.0:
        return f"{us*1000:.1f}ns"
    if us < 1000.0:
        return f"{us:.2f}us"
    return f"{us/1000:.2f}ms"


def _is_transpose_family(name: str) -> bool:
    return any(name.startswith(p) for p in TRANSPOSE_FAMILY_PREFIXES)


def render_summary(
    label: str, stats: Dict[str, KernelStat], filter_substr: Optional[str] = None
) -> List[str]:
    out = [f"=== {label}: per-kernel summary ===",
           f"  {'kernel':<48} {'count':>7} {'total':>10} {'mean':>10} devices"]
    out.append(f"  {'-'*48} {'-'*7} {'-'*10} {'-'*10} -------")
    items = sorted(stats.values(), key=lambda k: -k.total_dur_us)
    if filter_substr:
        items = [k for k in items if filter_substr.lower() in k.name.lower()]
    for ks in items:
        out.append(
            f"  {ks.name[:48]:<48} {ks.n_calls:>7d} "
            f"{_fmt_us(ks.total_dur_us):>10} {_fmt_us(ks.mean_dur_us):>10} "
            f"{','.join(d.split(':')[-1] for d in ks.devices)}"
        )
    return out


def _is_gpu_device(dev: str) -> bool:
    # Devices reported as ``/device:GPU:N``; host events are ``/host:CPU``.
    return "GPU" in dev




def render_transpose_focus(
    label: str, stats: Dict[str, KernelStat]
) -> Tuple[List[str], float]:
    """Build the transpose-family table.

    We only sum GPU-stream durations (host-side launch records on
    ``/host:CPU`` are listed in the ``CPU`` column for transparency but
    excluded from the totals). For each kernel we also surface the
    timestamp of its first GPU event so you can manually correlate it
    with the iter timeline (fwd around T+0us, bwd weight fixups around
    T+62ms, late grad-AG fixups around T+125ms; iter period ~190ms in
    dsv3_mini).
    """
    out = [f"=== {label}: FSDP-AG-fixup transpose family (GPU stream time only) ==="]
    items = sorted(
        (k for k in stats.values() if _is_transpose_family(k.name)),
        key=lambda k: -k.total_dur_us,
    )
    if not items:
        out.append("  (no transpose-family kernels in this trace)")
        return out, 0.0
    total = 0.0
    out.append(
        f"  {'kernel':<32} {'#GPU':>5} {'#CPU':>5} {'gpu_total':>10} "
        f"{'gpu_mean':>9} {'first_GPU_t':>14}"
    )
    out.append(f"  {'-'*32} {'-'*5} {'-'*5} {'-'*10} {'-'*9} {'-'*14}")
    for ks in items:
        gpu_inst = [(ts, d, dev) for ts, d, dev in ks.instances if _is_gpu_device(dev)]
        first_t = min((ts for ts, _, _ in gpu_inst), default=0.0)
        n_gpu = len(gpu_inst)
        n_cpu = ks.n_calls - n_gpu
        gpu_total = sum(d for _, d, _ in gpu_inst)
        gpu_mean = gpu_total / max(n_gpu, 1)
        out.append(
            f"  {ks.name[:32]:<32} {n_gpu:>5d} {n_cpu:>5d} "
            f"{_fmt_us(gpu_total):>10} {_fmt_us(gpu_mean):>9} "
            f"{first_t:>13.1f}us"
        )
        total += gpu_total
    out.append(
        f"  {'TOTAL (GPU stream)':<32} {'':>5} {'':>5} {_fmt_us(total):>10}"
    )
    return out, total


def render_instances(label: str, stats: Dict[str, KernelStat], pattern: str) -> List[str]:
    rx = re.compile(pattern)
    out = [f"=== {label}: instances matching /{pattern}/ ==="]
    matches = [k for k in stats.values() if rx.search(k.name)]
    if not matches:
        out.append("  (no kernels match)")
        return out
    for ks in sorted(matches, key=lambda k: k.name):
        out.append(f"  {ks.name}: {ks.n_calls} calls, total={_fmt_us(ks.total_dur_us)}")
        for ts, dur, dev in sorted(ks.instances)[:20]:
            short_dev = dev.split(":")[-1]
            out.append(f"    @ {ts:>12.2f}us  dur={_fmt_us(dur):>9}  device={short_dev}")
        if ks.n_calls > 20:
            out.append(f"    ... ({ks.n_calls - 20} more instances)")
    return out


def render_diff(
    left_label: str,
    left_total: float,
    right_label: str,
    right_total: float,
) -> List[str]:
    delta = right_total - left_total
    rel = (delta / left_total * 100) if left_total > 0 else float("nan")
    return [
        "",
        "=== Transpose-family wall-time diff (GPU stream, all phases) ===",
        f"  {left_label:<32} total = {_fmt_us(left_total)}",
        f"  {right_label:<32} total = {_fmt_us(right_total)}",
        f"  delta ({right_label} - {left_label}) = {_fmt_us(delta)}  ({rel:+.1f}%)",
        "",
        "  Hint: pass --instances 'loop_transpose|input_transpose|wrapped' to",
        "  see per-instance timestamps and split fwd vs bwd manually.",
    ]


# ---------------------------------------------------------------------------
# entrypoint
# ---------------------------------------------------------------------------


def main() -> None:
    p = argparse.ArgumentParser(
        description=__doc__.split("\n", 1)[0],
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("--left", default="embed", help="left axis label (default: embed)")
    p.add_argument("--right", default="mlp", help="right axis label (default: mlp)")
    p.add_argument(
        "--run-name",
        default="dsv3_mini",
        help="DEMO_RUN_NAME prefix (default: dsv3_mini; pass empty string for toy demo)",
    )
    p.add_argument(
        "--left-file",
        default=None,
        help="explicit path to left .trace.json.gz",
    )
    p.add_argument(
        "--right-file",
        default=None,
        help="explicit path to right .trace.json.gz",
    )
    p.add_argument(
        "--left-only",
        action="store_true",
        help="only inspect the left trace (skip the right side and diff)",
    )
    p.add_argument(
        "--filter",
        default=None,
        help="substring filter for the per-kernel summary (case-insensitive)",
    )
    p.add_argument(
        "--instances",
        default=None,
        help="regex pattern; print every instance of matching kernels with timestamps",
    )
    p.add_argument(
        "--out",
        default=None,
        help="optional path to also write the report to (besides stdout)",
    )
    args = p.parse_args()

    left_path = (
        Path(args.left_file) if args.left_file else find_trace(args.left, args.run_name)
    )
    left_trace = load_trace(left_path)
    left_stats = parse_trace(left_trace)
    left_label = (
        f"{args.run_name}/fsdp_{args.left}" if args.run_name else f"fsdp_{args.left}"
    )

    out_lines: List[str] = []
    out_lines.append(f"left  trace: {left_path}")
    if not args.left_only:
        right_path = (
            Path(args.right_file)
            if args.right_file
            else find_trace(args.right, args.run_name)
        )
        right_trace = load_trace(right_path)
        right_stats = parse_trace(right_trace)
        right_label = (
            f"{args.run_name}/fsdp_{args.right}" if args.run_name else f"fsdp_{args.right}"
        )
        out_lines.append(f"right trace: {right_path}")

    out_lines.append("")

    # Summary tables
    out_lines.extend(render_summary(left_label, left_stats, filter_substr=args.filter))
    out_lines.append("")
    if not args.left_only:
        out_lines.extend(
            render_summary(right_label, right_stats, filter_substr=args.filter)
        )
        out_lines.append("")

    # Transpose focus
    left_lines, l_total = render_transpose_focus(left_label, left_stats)
    out_lines.extend(left_lines)
    out_lines.append("")
    if not args.left_only:
        right_lines, r_total = render_transpose_focus(right_label, right_stats)
        out_lines.extend(right_lines)
        out_lines.extend(render_diff(left_label, l_total, right_label, r_total))

    # Optional per-instance timeline
    if args.instances:
        out_lines.append("")
        out_lines.extend(render_instances(left_label, left_stats, args.instances))
        if not args.left_only:
            out_lines.append("")
            out_lines.extend(
                render_instances(right_label, right_stats, args.instances)
            )

    text = "\n".join(out_lines)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n")


if __name__ == "__main__":
    main()
