#!/usr/bin/env bash
# Run the MoEBlock demo at realistic DeepSeek-V3-style dims, suitable
# for capturing meaningful xprof/HLO traces. Default preset
# (``dsv3_mini``) mirrors Maxtext's ``profile_deepseek_te_4gpu.sh``
# scaled-down config:
#
#   per-device-batch=2 x ep=2 x fsdp=2 -> global batch B=8
#   sequence length S=4096
#   hidden H=2048 (Maxtext base_emb_dim scaled down)
#   intermediate I=2048 (Maxtext base_moe_mlp_dim scaled down)
#   experts E=64, topk K=8
#
# All numeric dims are env-var overridable. Output lands under
# ``moe_block_demo/output/<DEMO_RUN_NAME>/fsdp_<axis>/`` so it never
# collides with the toy ``output/fsdp_<axis>/`` artifacts that
# ``run.sh`` produces.
#
# Usage:
#
#   bash moe_block_demo/run_realistic.sh                  # both axes
#   bash moe_block_demo/run_realistic.sh embed            # one axis
#   FSDP_LOGICAL_AXIS=mlp bash moe_block_demo/run_realistic.sh
#   DEMO_BATCH_SIZE=4 DEMO_SEQUENCE_LENGTH=2048 \
#       bash moe_block_demo/run_realistic.sh              # custom dims
#   DEMO_RUN_NAME=ds671b DEMO_HIDDEN_SIZE=7168 \
#       DEMO_NUM_EXPERTS=256 \
#       bash moe_block_demo/run_realistic.sh              # closer to full
#   DEMO_USE_FP8=1 bash moe_block_demo/run_realistic.sh   # legacy alias
#                                                         # for fp8_cs
#   DEMO_QUANT_RECIPE=fp8_cs bash moe_block_demo/run_realistic.sh
#                            # Float8CurrentScaling (V1 grouped GEMM)
#   DEMO_QUANT_RECIPE=mxfp8  bash moe_block_demo/run_realistic.sh
#                            # MXFP8BlockScaling (V2 grouped GEMM on
#                            # SM100+); production target. Requires
#                            # H % 128 == 0 and I % 128 == 0; default
#                            # realistic preset (H=I=2048) satisfies
#                            # both. Falls back to V1 silently if any
#                            # constraint fails.
#
# DelayedScaling is intentionally not exposed -- GroupedQuantizer
# doesn't currently accept margin/amax_history kwargs from the
# QuantizerFactory. Pending TE-side fix.
#
# After:
#   python3 moe_block_demo/compare_hlo.py --run-name dsv3_mini
#   tensorboard --logdir moe_block_demo/output/dsv3_mini/  # xprof view
#
# Memory note: at the default preset, per-device peak memory is
# roughly:
#
#   weights (FSDP-AG'd, 3 kernels)    ~768 MB
#   activations (B*S*K rows of H, 2x) ~1 GB
#   transient transpose / GEMM work   ~variable
#
# Comfortably fits on H100/80GB; tight on A100/40GB for the default
# preset. Drop B or S if you OOM.

set -euo pipefail

DEMO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------------------------------------------------------------
# Default DeepSeek-V3-mini preset (overridable per env var)
# ---------------------------------------------------------------------
export DEMO_RUN_NAME="${DEMO_RUN_NAME:-dsv3_mini}"
export DEMO_BATCH_SIZE="${DEMO_BATCH_SIZE:-8}"
export DEMO_SEQUENCE_LENGTH="${DEMO_SEQUENCE_LENGTH:-4096}"
export DEMO_HIDDEN_SIZE="${DEMO_HIDDEN_SIZE:-2048}"
export DEMO_INTERMEDIATE_SIZE="${DEMO_INTERMEDIATE_SIZE:-2048}"
export DEMO_NUM_EXPERTS="${DEMO_NUM_EXPERTS:-64}"
export DEMO_NUM_EXPERTS_PER_TOK="${DEMO_NUM_EXPERTS_PER_TOK:-8}"
export DEMO_EP_SIZE="${DEMO_EP_SIZE:-2}"
export DEMO_FSDP_SIZE="${DEMO_FSDP_SIZE:-2}"
# More profile iters than the toy demo because each step is much
# longer; gives xprof a chance to amortize compile/dispatch noise.
export DEMO_NUM_PROFILE_ITERS="${DEMO_NUM_PROFILE_ITERS:-5}"
# Quantization knob; default is bf16 (legacy behavior). Users opt into
# a specific recipe by setting DEMO_QUANT_RECIPE. The legacy
# DEMO_USE_FP8=1 alias still maps to fp8_cs for backward compat.
export DEMO_QUANT_RECIPE="${DEMO_QUANT_RECIPE:-}"
export DEMO_USE_FP8="${DEMO_USE_FP8:-0}"

echo "================================================================="
echo "MoEBlock demo (realistic dims, run_name=${DEMO_RUN_NAME})"
echo "  B=${DEMO_BATCH_SIZE} S=${DEMO_SEQUENCE_LENGTH} H=${DEMO_HIDDEN_SIZE}"
echo "  I=${DEMO_INTERMEDIATE_SIZE} E=${DEMO_NUM_EXPERTS} K=${DEMO_NUM_EXPERTS_PER_TOK}"
echo "  ep=${DEMO_EP_SIZE} fsdp=${DEMO_FSDP_SIZE}  profile_iters=${DEMO_NUM_PROFILE_ITERS}"
echo "  artifacts -> output/${DEMO_RUN_NAME}/fsdp_<axis>/"
echo "================================================================="

# ---------------------------------------------------------------------
# Pick which axes to run. Default: both (so you can diff them after).
# ---------------------------------------------------------------------
AXES=()
if [[ $# -gt 0 ]]; then
    for arg in "$@"; do
        case "$arg" in
            embed|mlp) AXES+=("$arg") ;;
            *) echo "Unknown axis '$arg' (expected 'embed' or 'mlp')"; exit 2 ;;
        esac
    done
else
    AXES=(embed mlp)
fi

for axis in "${AXES[@]}"; do
    echo
    echo "----- FSDP axis: $axis -----"
    FSDP_LOGICAL_AXIS="$axis" bash "$DEMO_DIR/run.sh"
done

echo
echo "================================================================="
echo "Realistic run complete. Suggested next steps:"
echo
echo "  # Side-by-side HLO diff:"
echo "  python3 ${DEMO_DIR}/compare_hlo.py --run-name ${DEMO_RUN_NAME} \\"
echo "      --out ${DEMO_DIR}/output/${DEMO_RUN_NAME}/exp2_diff.txt"
echo
echo "  # xprof in TensorBoard:"
echo "  tensorboard --logdir ${DEMO_DIR}/output/${DEMO_RUN_NAME}/ --port 6006"
echo "================================================================="
