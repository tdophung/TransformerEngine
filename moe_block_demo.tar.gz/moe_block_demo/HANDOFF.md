# Handoff — Experiment 1 (Quantize-Before-FSDP-AG) for `MoEBlock`

This file is a **self-contained revival prompt** for a fresh AI agent on a
new system. Paired with the git branch and the JSONL transcript, it
should be enough to resume work without losing context. Read this top to
bottom; then read `EXPERIMENT_1_PLAN.md` for the full technical state.

## TL;DR

We are implementing **"quantize before FSDP all-gather" (QB4AG)** for the
3 `grouped_dense` calls inside
`transformer_engine.jax.flax.MoEBlock`. Goal: each FSDP peer quantizes
only its `1/num_fsdp` slice of each kernel, then the AG carries FP8
(or MXFP8) bytes instead of bf16 — halving fwd AG bandwidth and
reducing per-peer quantize compute by `num_fsdp`.

**Status: Stage 1–4 implementation is DONE on the
`experiment1_quantB4AG` branch of the user's TE fork. Final
`pytest -v tests/jax/test_distributed_moe_block.py` and
`bash moe_block_demo/run_realistic.sh` runs are PENDING USER
VERIFICATION on a 4-GPU box.**

The cluster the work was done on (`prenyx`, mounted at
`/lustre/fsw/coreai_dlfw_dev/tdophung`) is being decommissioned.
This handoff is so you can pick up on a new system.

## Repos and branches

* **TE fork**: <https://github.com/tdophung/TransformerEngine.git>
  branch `experiment1_quantB4AG`. The MoEBlock + dense.py + tests
  changes live here.
* **`moe_block_demo/`**: NOT a git repo. Standalone scripts that exercise
  `MoEBlock` end-to-end at toy and realistic dims, dump HLO + xprof,
  and produce comparison artifacts. Back this up as a tarball
  (see "Reviving on a new system" below).

## Architecture sketch

```
MoEBlock.__call__
  └─ _forward_a2a_ep                          (EP shard_map)
       ├─ in_specs for wi_*, wo: now KEEP fsdp dim when knob is on
       │  (legacy: stripped fsdp, JAX AG'd outside body in bf16)
       └─ _a2a_body
            └─ _expert_ffn
                 └─ grouped_dense(x, wi_0, ..., kernel_fsdp_info=(...))
                      └─ _grouped_dense_fwd_rule  (custom_vjp fwd)
                           ├─ if kernel_fsdp_enabled and not has_kernel_quantizer:
                           │     plain lax.all_gather(kernel) up front  (bf16 path)
                           │
                           ├─ tex.grouped_quantize(..., amax_scope=AmaxScope.FSDP)
                           │     (per-shard quantize; pmax of per-expert amax under FSDP)
                           │
                           ├─ if has_kernel_quantizer:
                           │     _all_gather_grouped_scaled_tensor_1x(grouped_gemm_kernel, ...)
                           │     (AG FP8 data + per-block scale_inv if MXFP8)
                           │
                           └─ tex.grouped_gemm(...)
                      └─ _grouped_dense_bwd_rule  (custom_vjp bwd)
                           ├─ if kernel_fsdp_enabled and isinstance(ctx_kernel, GroupedScaledTensor1x):
                           │     _all_gather_grouped_scaled_tensor_1x(ctx_kernel, ...)
                           │     (AG colwise/RHS_TRANS data for dgrad GEMM)
                           │
                           ├─ tex.grouped_gemm(dgrad_grad, dgrad_kernel_T, ...)
                           ├─ tex.grouped_gemm(wgrad_x_T, wgrad_grad, ...)  → full (G, K, N)
                           │
                           └─ if kernel_fsdp_enabled:
                                 wgrad = lax.psum_scatter(wgrad, fsdp, scatter_dimension=fsdp_axis_idx, tiled=True)
                                 (autodiff transpose of fwd all_gather)
```

## What's done (per-stage)

| Stage | What | Status |
|---|---|---|
| 0/0a | FP8 baseline + 2× C++ bug fixes (`multi_stream.cpp`, `quantization.cpp`, `gemm.cpp`) | DONE, committed upstream of `experiment1_quantB4AG` |
| 1 | MoEBlock plumbing: `quantize_before_fsdp_ag` knob, `_derive_kernel_fsdp_info`, `_build_kernel_in_spec`, threading `kernel_fsdp_info` through `_forward_*` → `_expert_ffn` → `grouped_dense` | DONE, committed (`da1bb395`) |
| 2 | `tex.grouped_quantize(..., amax_scope=AmaxScope.{LOCAL,FSDP})`. FSDP scope `pmax`s per-expert amax (CurrentScaling pre-FFI, DelayedScaling post-FFI). MXFP8 is a no-op (per-block amax is already local-correct). | DONE, committed (`b9ff28c9`) |
| 3 | `_grouped_dense_fwd_rule`: bf16 plain-AG short-circuit + FP8 path with `_all_gather_grouped_scaled_tensor_1x` (handles tensor scaling + MXFP8 K-side AND M-side) + MoEBlock alignment guard | DONE, **uncommitted** in working tree (only the older `b7687bea` "save state" commit captures an earlier in-progress version) |
| 4 | `_grouped_dense_bwd_rule`: AG ctx_kernel inside bwd; `lax.psum_scatter` wgrad along fsdp axis | DONE, **uncommitted** |
| 5 | Test: `test_quantize_before_fsdp_ag_matches_single_device` parametrized over bf16 + Float8CurrentScaling at H=I=256, full `value_and_grad` with grad-match against single-device | DONE, **uncommitted** |
| 6 | Demo knobs (`DEMO_QUANTIZE_BEFORE_FSDP_AG`, etc.) + HLO compare / xprof | partial — `DEMO_QUANTIZE_BEFORE_FSDP_AG` works, but extending `compare_hlo.py` with a third lane and updating `WIP_analysis.md` is TODO |

## Key technical decisions (don't relitigate)

These were settled with the user explicitly during this work; don't
change them without asking:

1. **Use the existing `kernel_fsdp_info: Tuple[str, int]` parameter** on
   `grouped_dense` rather than introducing a new API. Long-term TE may
   migrate to a different wire format (NamedSharding-derived); for now
   we land with the existing knob.

2. **Tensor scaling under FSDP**: per-expert amax means **AR (`pmax`)
   is always required**, regardless of whether FSDP shards M or K.
   `scale_inv` is never AG'd (peer-identical post-pmax). One amax per
   expert, not per row.

3. **MXFP8 + FSDP per-shard mult-of-128 guard** is symmetric:

   | Layout  | block_x | alignment_x | block_y | alignment_y | x×x | y×y |
   |---|---|---|---|---|---|---|
   | Rowwise | 1       | 128         | 32      | 4           | 128 | 128 |
   | Colwise | 32      | 4           | 1       | 128         | 128 | 128 |

   So a single `per_shard % 128 == 0` check covers M-side and K-side
   for both `is_colwise` values. M-side AG was implemented via reshape
   `(G, M_per_shard/block_x, n_block_y) → AG axis=1 → reflatten`, which
   only works for the single-non-G-M-dim layout `(G, M, K_dims...)`
   (the MoEBlock kernel layout). Multi-M-dim raises NotImplementedError.

4. **bf16 + QB4AG**: short-circuit at the start of `_grouped_dense_fwd_rule`
   with a plain `lax.all_gather` of the bf16 kernel; the rest of the
   rule then follows the legacy path. ctx_kernel ends up as a plain
   ndarray (full), so the bwd's `_all_gather_grouped_scaled_tensor_1x`
   call is gated by `isinstance(ctx_kernel, GroupedScaledTensor1x)`.
   Bwd's `psum_scatter` on wgrad still runs unconditionally under
   `kernel_fsdp_enabled` because the kernel input was per-shard.

5. **Same FSDP logical axis for wi and wo** (`embed -> fsdp` or
   `mlp -> fsdp`, not a dedicated `kernel_fsdp` axis). Reason:
   sharding wi and wo on different physical axes between layers
   forces a reshard. Under `embed -> fsdp`: wi axis 1 (M-side),
   wo axis 2 (K-side); under `mlp -> fsdp`: vice versa. Both work
   thanks to symmetric MXFP8 M+K-side support.

6. **`DelayedScaling` is excluded from `SUPPORTED_RECIPES`** in the
   tests because `GroupedQuantizer.__init__` doesn't accept the
   DelayedScaling-specific kwargs (`margin`, `amax_history`,
   `amax_compute_algo`) that `QuantizerFactory.create` forwards. This
   is a pre-existing TE bug; tracked as a follow-up.

7. **MXFP8 is excluded from the toy-shape distributed test** because
   the toy shapes don't satisfy MXFP8's strict end-to-end alignment
   (M % 32 == 0 per group + 128-aligned overall buffer). MXFP8
   coverage is provided by the realistic demo
   (`bash moe_block_demo/run_realistic.sh DEMO_QUANT_RECIPE=mxfp8`).

8. **Stage 3 fwd-only test scaffolding was deliberately reverted**:
   the `test_quantize_before_fsdp_ag_matches_single_device` Stage 4
   test (full fwd+bwd value_and_grad) subsumes it. There's no Stage 3
   fwd-only test in the tree; that's intentional.

## Pending verification (the new agent should ask the user to run these)

```bash
# 1. Distributed test (4 GPUs needed):
cd ~/TransformerEngine
pytest -m triton tests/jax/test_distributed_moe_block.py::TestDistributedMoEBlock -v
#   Expected: 4 cases pass (bf16 / Float8CurrentScaling × pure_jax / triton),
#   for both test_ep2_fsdp2_matches_single_device and
#   test_quantize_before_fsdp_ag_matches_single_device.

# 2. Realistic demo, all 3 recipes, both FSDP axes:
cd ~/moe_block_demo
DEMO_QUANTIZE_BEFORE_FSDP_AG=1 bash run_realistic.sh                       # bf16
DEMO_QUANTIZE_BEFORE_FSDP_AG=1 DEMO_QUANT_RECIPE=fp8_cs bash run_realistic.sh
DEMO_QUANTIZE_BEFORE_FSDP_AG=1 DEMO_QUANT_RECIPE=mxfp8  bash run_realistic.sh
#   Expected: all 6 invocations (3 recipes × 2 axes) complete fwd+grad
#   cleanly. HLO collective summary should show extra all_gather of
#   FP8 data (and f8e8m0fnu scale_inv for MXFP8) + a reduce_scatter
#   on wgrad per FSDP-sharded kernel.

# 3. Compare against the knob=False baseline:
DEMO_QUANTIZE_BEFORE_FSDP_AG=0 DEMO_QUANT_RECIPE=fp8_cs bash run_realistic.sh
#   Compare HLO + xprof to confirm: AG operands switched from bf16 to
#   f8e4m3fn, and per-shard quantize FFI input shape is 1/num_fsdp.
```

## Known follow-ups (not blocking Exp 1)

| Tag | Description |
|---|---|
| `te-grouped-quantizer-delayed-scaling` | Patch `QuantizerFactory.create` or `GroupedQuantizer` to accept `margin` / `amax_history` / `amax_compute_algo` kwargs. Currently raises TypeError. |
| `exp1-mxfp8-multi-m-dim` | Implement M-side MXFP8 AG for multi-M-dim layouts `(G, X, Y, K)`. Currently `_all_gather_grouped_scaled_tensor_1x` raises NotImplementedError. Reshape-AG-reshape pattern is described in the dense.py docstring. |
| `exp1-stage6-compare-hlo` | Extend `moe_block_demo/compare_hlo.py` with a third lane (knob=True vs knob=False); update `WIP_analysis.md` Exp 1 section with measurements. |

## Files changed (against `experiment1_quantB4AG` HEAD `b7687bea`)

* `transformer_engine/jax/dense.py` — Stage 3 + 4 implementation
  (`_all_gather_grouped_scaled_tensor_1x` with M-side support, fwd
  bf16 short-circuit + FP8 AG, bwd ctx_kernel AG + `psum_scatter`).
* `transformer_engine/jax/flax/moe.py` — `_assert_kernel_fsdp_alignment`
  docstring update (Stage 3+4 covers both M and K sides).
* `tests/jax/test_distributed_moe_block.py` — added
  `HIDDEN_SIZE_QB4AG` / `INTERMEDIATE_SIZE_QB4AG` constants,
  `_make_inputs_qb4ag` helper, and new
  `test_quantize_before_fsdp_ag_matches_single_device` method.
* (Outside TE git) `moe_block_demo/run_demo.py` — restored canonical
  uniform `FSDP_LOGICAL_AXIS` routing (no `kernel_fsdp` override).
* (Outside TE git) `moe_block_demo/run_realistic.sh` — Stage 3 docs
  removed; documents only the standard `DEMO_QUANT_RECIPE` knob.
* (Outside TE git) `moe_block_demo/EXPERIMENT_1_PLAN.md` — Stages 3+4
  marked DONE; symmetric M/K-side MXFP8 contract documented.

## Reviving on a new system

```bash
# 1. Clone TE fork and check out the branch.
git clone https://github.com/tdophung/TransformerEngine.git
cd TransformerEngine
git checkout experiment1_quantB4AG
# (optional) git pull if the user pushed the latest uncommitted changes
# from the old cluster before shutdown.

# 2. Restore moe_block_demo from the tarball backup
#    (instructed below).
tar xzf moe_block_demo_backup.tar.gz -C ~/

# 3. Restore the agent transcript to a portable location
#    (instructed below).
mkdir -p ~/handoff
cp transcript.jsonl ~/handoff/

# 4. Open a fresh chat with an AI coding agent. Paste this entire
#    HANDOFF.md as the first message. Then point it at the transcript
#    if it asks for more historical context.
```

## What to ask the new agent first

1. "Read `moe_block_demo/HANDOFF.md` and `moe_block_demo/EXPERIMENT_1_PLAN.md`."
2. "Run the verification commands in HANDOFF.md and report which pass."
3. "If any fail, debug and fix; don't introduce new architectural decisions
   without checking the 'Key technical decisions' section first."
4. After verification: pick from the "Known follow-ups" or move on to
   Experiment 2 (see `WIP_analysis.md` for that plan).
